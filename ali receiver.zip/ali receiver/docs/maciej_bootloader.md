# Applications for the original Opticum N2 bootloader

This workflow targets `dumps/dump_maciej.bin`, the Opticum STB HD N2 / ALi
M3801 dump supplied by maciej_333. It builds a small independent C application
and updates the application through the existing UART bootloader. The original
dump is never overwritten. The demonstration uses the DRAM and clock setup
already performed by the original loader; it is not a replacement reset ROM.

## Ready-to-use binaries

The latest application is the v4 demo (below): a command line, a TV picture,
the front panel, the remote control and the USB port. v3 is the small
application of the first software-restart tests; v2 files remain available
for reproducing the first hardware validation.

- [v4 UART payload](../firmware/maciej_app/bin/elektroda_ali_m3801_maciej_v4.maincode.bin):
  64 KiB application chunk for upload at `0x50000`.
- [v4 full flash image](../firmware/maciej_app/bin/elektroda_ali_m3801_maciej_v4.bin):
  complete 4 MiB image for the simulator or an external programmer.
- [v4 manifest](../firmware/maciej_app/bin/elektroda_ali_m3801_maciej_v4.json):
  sizes, addresses, commands, and SHA-256 checksums.
- [Portable v4 UART ZIP](../firmware/maciej_app/bin/maciej_uart_v4.zip):
  standalone `maciej_uart.py`, payload, and ASCII Polish instructions
  ([README_UART_v4.txt](../firmware/maciej_app/bin/README_UART_v4.txt)).
- The same four files exist for v3 (`..._v3.*`, `maciej_uart_v3.zip`).

```powershell
python tools/maciej_uart.py --port COM3 --capture-boot 60 flash firmware/maciej_app/bin/elektroda_ali_m3801_maciej_v4.maincode.bin --backup before-maciej-v4.bin
```

Replace `COM3` with the tuner adapter. For stock firmware or v1/v2, power the
tuner on after capture starts. When v3 is already running, leave it powered:
the first capture `c` requests a restart and subsequent `c` bytes interrupt
the original loader. A single `c` without continuing capture need not leave
the receiver in the loader. The unchanged Python and C# capture protocols
support this path. A new backup filename is required for every update.

From the extracted ZIP, install `pyserial` and use the same command with
`maciej_uart.py` and the payload filename in the current directory.
The image uses LZMA and CRC checks; no encryption or signing step is needed.
The updater preserves the loader and all bytes outside the maincode payload.

## UART restart in v3

The application accepts individual characters without Enter at 115200 8E1:

- `v`: print the banner and version.
- `p`: reply `pong v3`.
- `r`: restart through the original loader and boot the application again.
- `c`: restart for the updater's repeated-`c` bootloader capture.

The shipped v3's `platform_restart` follows the M3801/S3811 branch of this
dump's own `sys_watchdog_reboot` / `sys_ic_reboot`: set the warm-boot
marker, restore SPI controller mode, mask CPU interrupts, pulse the same
peripheral reset registers, and jump to `0xBFC00000`. The original loader
then reinitializes DRAM and caches and loads the application. The app waits
for UART transmit completion before restarting. It neither writes flash nor
replaces the bootloader. These register values apply to the exact supported
loader and board profile, not arbitrary ALi devices. Since the v4 demo
`start.S` resets the chip through the watchdog first and keeps this path
as the fallback (see the v4 demo below): the jump hung on a real box once
the display engine and VCAP were running.

`tests/run_dump_maciej_app_restart.py` builds the source. On C++ it exercises
two updates with different application bytes in one continuously running
simulator using the production Python CLI. It checks full backups/readbacks,
`r`, repeated-`c` capture, the original loader's verification, application
replies, and flash preservation. On Unicorn it checks native restarts,
software capture, and reboot without the long full-flash transfers. It is
included in the GitHub `--slow` suite; artifacts are under
`build/maciej_app/selftest/ENGINE/restart/`.

`tests/run_dump_maciej_ready_v3.py` also tests the exact shipped v3 binary and
ZIP on both engines: archive contents and hashes, native cold boot, three
`r` restarts, software capture, loader handshake/reboot, and unchanged flash.
This shorter regression runs in the default suite, with artifacts under
`build/maciej_app/selftest/ENGINE/ready_v3/`.

## The v4 demo

`firmware/maciej_app/demo/` is a larger freestanding application (about 180 KB,
most of it the four recorded display set-ups; no SDK, no RTOS, interrupts
masked, everything polled) for the same bootloader. It prints the same banner and `Version: v4`, then:

- **Command line** on the UART (115200 8E1): whole lines ended by Enter,
  echo, a line editor (Left / Right, Home / End, Ctrl- or Alt-arrows by a
  word, Backspace, Delete, Ctrl-W / Ctrl-U / Ctrl-K cut and Ctrl-Y puts
  back, Ctrl-L clears the screen, Ctrl-C drops the line; the TV's console
  follows the cursor through ESC [ n C / D), a history of 64 commands
  (repeats moved to its end, a line typed with a space first not kept;
  Up / Down recall the ones starting with what is typed, Ctrl-R searches,
  `!!`, `!n`, `!-n`, `!text`; `history [n | -c]`), Tab completion of a
  command's name, its first word's choices as its help names them
  (`rf <init|tune|...>`) and a disk's file or directory names (the
  candidates listed when several fit), prompt
  `m3801> ` (with a current directory: `m3801 3:/Docs> `). `help` lists the
  commands: `version`, `ping` (`pong v4`),
  `info` (chip ID 0x3811 = S3811 and its revision byte, CPU clock from the
  strap, memory layout, which of the two boards it found, the display
  layer's enable register as the demo found it at start and now),
  `uptime`, `echo`, `md <addr> [len]`, `mr <addr>`, `mw <addr> <value>`
  (RAM, the flash window and the device registers only; `mw` refuses the
  flash), `screen`, `testscreen`, `console`, `panel`, `keys`, `ir`, `usb`,
  `lsusb`, the disk commands below, `clear`, `history`,
  `video init [opticum|comsat] [rev0|rev1]`, `reboot` / `restart` and `bootloader`. Every command may
  also be written with `/` in front (`/restart`, `/lsusb`, `/testscreen`).
- **Console on the TV** (the view after start, `console.c`): what the UART
  shows -- the boot messages, the prompt and what is typed on the UART or a
  USB keyboard, the output, the events (`[usb] ...`, `[panel] ...`) -- as a
  text terminal like a Linux console: 105 x 42 characters of the demo's 5 x
  7 font at twice its size, a title bar (uptime, hints), prompts green,
  what is typed white, an event's tag cyan, a blinking block cursor; the
  lines scroll up and the last 512 are kept, PgUp / PgDn (a USB keyboard's,
  or ESC [ 5 ~ / ESC [ 6 ~ from a terminal) looking back half a screen at a
  time. `uart_putc` hands it every character, so the TV shows what a
  terminal on the UART does (CR, LF, backspace, tab, ESC [ K, ESC [ 2 J, ESC
  [ H); only the cells that changed are drawn, from the main loop and
  every 200 ms while a long output runs. It is a bitmap of its own
  (0x02200000) with a region head of its own (0x00F00800); `testscreen`
  points the layer's head register (0xB8006304) at the test screen's head
  instead, and a key on the USB keyboard -- it types too -- or `console`
  points it back. Both pictures stay drawn.
- **Test screen** (`testscreen`; what the TV showed before the console): a 1280 x 720 ARGB1555 bitmap on GMA layer 0 through one
  region head, the way the original application shows its OSD (head word
  0x`AA200B51`, pitch 2560). On a revision-1 S3811 -- a real box reads the
  chip word 0x38110001 -- the head is a 0x280-byte block whose +0x240 holds
  the matrix the layer's RGB colours are converted to YCbCr with; the demo
  puts the originals' BT.709 matrix there (on revision 0 too, where they
  leave it zero; no revision-0 chip was tried), enables the layer as they do (0x00040001
  on revision 1: bit 18 set, bit 19 clear; 1 on revision 0) and marks the
  region true-colour (0xB80063B8 = 1). The demo screen has live boxes for the system,
  the remote, the front panel, the command line and USB, and colour bars;
  `screen demo | bars | clear [rrggbb] | text <x> <y> <words> |
  rect <x> <y> <w> <h> <rrggbb> | on | off` draw on it and show it (a drawing command
  pauses the live boxes until `screen demo`). The font is the demo's own
  5 x 7 bitmap font (`gen_font.py`).
- **Front panel** (TM1650 on GPIO 31 / 9, bit-banged as the bootloader does):
  `panel <text>` shows four characters, `panel bright 0..7`; key presses
  are reported as they happen (`[panel] key 47 pressed: KI1/DIG4 UP`) and
  shown as `P xx`; `keys` reads the key register. A board without the
  chip -- the Comsat TE 1050 HD (dump.bin's board) has no display, and two
  buttons on the same two pins, each pulled up and shorted to ground when
  pressed -- gives no acknowledge at start. The demo then lets go of both
  pins for good (a pin driven high would be shorted by a pressed button),
  says so on the UART and reads them as two buttons, UP (GPIO 31) and DOWN
  (GPIO 9): `[panel] button UP (GPIO 31) pressed` / `released` (two reads
  100 ms apart must agree), the front panel box shows them, `keys` gives
  their state and `panel` text is refused.
- **Remote control**: the M6303 IR receiver set up as the SDK's driver does
  and read by polling; every NEC frame is printed with its 32-bit code (as
  the SDK's decoder shifts it in), the four bytes and the button name from
  the original firmware's own key table (`gen_ir_keys.py`), and shown on
  the screen and the panel. The remote's POWER is `023750af` -- exactly the
  wake code the bootloader's standby loop waits for. `ir raw on` prints the
  pulse timings of every frame.
- **USB**: `usb` reads the host controller's port (connected, speed,
  over-current, the PHY's settings) and enumerates a connected device over
  endpoint 0 (its VID:PID, strings, interfaces, endpoints; then sets its
  configuration); plugging a device in does the same by itself and shows it
  on the TV, and so does a device already plugged in when the demo starts.
  `lsusb` lists the controller and the device in one line each
  (`Bus 001 Device 001: ID 1209:0001 AliSimulator Virtual USB stick, high
  speed (480 Mbit/s)` in the emulator). `usb reset` drives a bus reset,
  `usb init` sets the controller up again, `usb reg <offset> [byte]` reads
  or writes one of its registers (byte-wide; not the PHY's), `usb ctl <type>
  <request> <value> <index> <length> [device]` sends a control request to
  the device with that address (1, the one on the box's port, when none is
  given) and prints what it answers.
- **USB hubs**: a hub on the port is set up with everything behind it --
  its ports powered, each port with a device reset in turn, the device given
  the next address and enumerated like the first; a hub behind a hub the
  same way -- up to fifteen devices in all. `usb` lists each with its hub and
  port, `lsusb` one line each (`Bus 001 Device 004: ID 1209:0002 ..., low
  speed (1.5 Mbit/s), hub 1 port 4`). A device that is not high speed behind
  a high-speed hub is reached through that hub's transaction translator
  (split transfers: the controller's split registers). One port of one hub
  is looked at every 100 ms, each in its turn, so a device plugged into a
  hub or pulled out is noticed within a second or so and said on the
  console (`[usb] hub 1 port 2: device connected`). The first keyboard
  found types; when it is unplugged the next one takes over. Limits:
  fifteen devices (the endpoints' address registers hold four bits of an
  address; the SDK's `set_ep_device_address` masks it so), a hub only at
  one of the first seven addresses and only its first seven ports (the
  split registers hold three bits of a hub's address and port); a
  low-speed device behind a full-speed (USB 1.1) hub does not answer and is
  left alone.
- **USB disks**: a stick, a card reader or a USB disk (mass storage with
  SCSI commands over the bulk-only transport) is found as it is set up --
  its name, size, partitions (MBR or GPT) and file systems -- and `disks`
  lists them. On FAT12, FAT16, FAT32 and NTFS (long file names too)
  `ls [n:][/path]` lists a directory -- dates, sizes, names -- and `cat
  [n:]/path` shows a text file (a binary one: its first 256 bytes in hex;
  Ctrl-C on the UART stops it); `sector [n:]<number>` shows any sector in
  hex. A disk is named by its USB device number as `lsusb` lists it (`ls
  3:/docs`, `n.p:` for its partition p); without one the current directory
  is used (`cd 3:`, `cd docs`, `cd ..`, `cd /`; `pwd`; `cd` alone forgets
  it, the prompt shows it), before any `cd` the first FAT volume's root;
  paths take any case and may be relative; `dir` is `ls`. `mkdir`,
  `rmdir` (an empty directory), `rm` (a file), `touch` (an empty file), `cp
  <from> <to>` (a file; into a directory when <to> is one; onto another
  disk too), `mv <from> <to>` (a rename, or a move into another directory
  of the same volume: the same clusters, its dates kept, a directory's `..`
  pointed at its new place) and `command > [n:]path` (what any command
  prints, into a file, with Linux line ends; `>>` adds it to the file's
  end) write the FAT volume; `"..."` or `'...'` keep spaces in a word.
  `rm -r` removes a directory and everything in it (deepest first, through
  rm's and rmdir's own code; never the current directory's tree, never a
  damaged entry whose cluster is 0, the root or a directory it is already
  in), `cp -r` copies a directory with everything in it, from FAT or NTFS
  onto FAT (into <to> when that is a directory; the directory it makes is
  never copied into itself: `cp -r A A/B` ends), 16 levels deep at most;
  `head [-n N]` / `tail [-n N]` show a text file's first / last lines
  (tail reads only its last 16 KB, from that cluster on), and `df [n:]`
  each volume's size, free and used space (FAT: free clusters counted in
  its FAT; NTFS: free bits in its $Bitmap, record 6). Checked in the
  emulator (a 52 KB file for tail, cp -r into an existing directory and
  into itself, rm -r of the current directory's tree refused) and on the
  box's card (cp -r of a tree, its copy's CRC, rm -r of both, df); df of
  an NTFS volume was not tried on the box (the stick was not plugged in).
  Writing goes by SCSI WRITE(10) through the bulk-only transport's
  data-out stage, every copy of the FAT written, long names with their 8.3
  aliases (`NEWFOL~1`; an 8.3 name in lower case gets Windows' lower-case
  flags instead), a new directory's cluster zeroed with its `.` and `..`
  before its entry links it in, a directory grown by a cluster when it is
  full, an entry deleted before its clusters are freed, FAT32's FSInfo
  counts made unknown; a write-protected disk (MODE SENSE) is not written.
  What is made is dated by the clock once NTP has set it (Polish time, as
  FAT keeps local time); before that, 2026-11-13 12:00. A path's directory
  part may be 95 characters and a name 127: longer ones are refused (they
  were cut, and the file went to another name or directory). NTFS is
  read: `ls`, `cd`, `cat`, `cp` onto a FAT disk, `sum
  [n:]path` (a file read to its end: size, CRC-32, speed) and the explorer
  go through its MFT -- records with their fixups, resident and
  non-resident attributes, data runs (sparse ones as zeros), attribute
  lists for files in many pieces, directories' B-tree indexes ($INDEX_ROOT
  and INDX blocks), names as ASCII ('?' for the rest), dates in Polish
  time; compressed and encrypted files are refused. NTFS is written too
  (`disk.c`, "NTFS, written"), by the same commands as FAT -- `mkdir`,
  `rmdir`, `rm [-r]`, `touch`, `cp [-r]`, `mv`, `> file`, the explorer's keys
  and FTP uploads -- but only a volume Windows closed cleanly: its journal
  ($LogFile) empty or clean, none of the volume's dirty / upgrade / chkdsk
  flags, NTFS 3.x, file records of 1 KB or more, $MFTMirr agreeing with
  $MFT, no hibernation file in use. `ntfs [n:]` shows the volume's geometry,
  its journal's state and that verdict; `ntfs n: reset-journal` empties the
  journal as ntfs-3g does (a volume Windows left mounted, e.g. fast start-up,
  is refused). Every NTFS write goes through one function: records and
  INDX blocks are written with their update-sequence fixups, $MFTMirr with
  record 0..3, clusters taken from $Bitmap, records from $MFT's bitmap
  ($MFT grown when it is full), a directory's index rebuilt into spare
  blocks and switched over by one record write; a move takes the entry out
  of the old directory first, a crash between writes leaves at worst a file
  in no directory (chkdsk puts it in found.000), never two entries. Names get
  a Win32 name (and a DOS one is kept with it), case-insensitive clashes
  are refused, as are hard links, files with $OBJECT_ID (rm), compressed,
  encrypted or sparse files. A write that fails makes the volume read-only
  until `ntfs n:` looks at it again; a card changed in its reader (sense
  6/28) is looked at anew before anything is written to it. exFAT is
  listed but not read; only a device's first logical unit is used, and up
  to four disks. The 64 GB stick (090c:2000) used to lose its first command
  after a pause: the cause was the controller (see "USB" below, devices at
  addresses 8 and up), not the stick.
- **USB serial ports**: a GSM / LTE module's ports (vendor-class interfaces
  with a bulk IN and a bulk OUT endpoint, of the module makers Linux's
  option driver knows: SIMCom, Quectel, Huawei, ZTE, Qualcomm, Telit,
  Sierra Wireless, Fibocom), CDC ACM devices and USB-serial chips -- WCH
  CH340 / CH341 in serial mode (1a86:7523, 5523), Silicon Labs CP210x,
  FTDI FT232R / FT-X / FT2232 / FT4232 / FT232H, Prolific PL2303 (HX) --
  become `ttyUSB<n>` / `ttyACM<n>` as they are set up (DTR and RTS on); a
  chip is set up as Linux's driver for it does (CH34x: version, SERIAL_INIT,
  divisor and prescaler registers; CP210x: IFC_ENABLE, SET_BAUDRATE,
  SET_LINE_CTL, SET_MHS; FTDI: RESET, the fractional baud divisor,
  SET_DATA, SET_MODEM_CTRL, its two status bytes stripped from every IN
  packet; PL2303: the vendor start-up sequence, then CDC's SET_LINE_CODING)
  at 115200 8N1, and `stty [n] [baud]` shows or sets the rate (CDC ACM gets
  SET_LINE_CODING). On the box a CH340 (1a86:7523) took 300 to 2000000
  baud; its data was not tried (nothing on its pins). A CH341A in its I2C /
  SPI mode (1a86:5512, a 24xx / 25xx programmer) is only named. Control
  transfers now carry OUT data too (written into the RTL8153's multicast
  register and read back on the box). `tty` lists the ports. `at
  <command>` sends one AT command to the first port named "... AT ..." --
  `AT` put in front when it is missing (`at +csq`, `at i`), the rest as
  typed, quotes kept (`at +cpin="1234"`) -- and shows the answer up to its
  final result (OK, ERROR, +CME / +CMS ERROR, NO CARRIER ..., or the `> `
  of AT+CMGS) and what follows it within 250 ms (AT+HTTPREAD's page, a
  long line whole); lines the module sent before the command (+HTTPACTION,
  RING, +CMTI) come first. A line typed as `AT...` goes there too, and `>
  file` works. `cu [n]` joins the terminal -- the UART and the USB
  keyboard -- to a port: what is typed goes out (Enter as CR, whatever the
  terminal sends), what comes in is shown, until `~.` at a line's start or
  Ctrl-] (as Linux's `cu`). An IN token spoilt on the bus (a UTMI, CRC or
  PID error) is tried again in usb.c, twice; `cu` goes on through a failed
  transfer while the device is still set up (it says so once); a module that
  lost its set-up (it restarted) is set up again by the `at` or `cu` that
  finds it so -- behind a hub only its port (`usb_set_up_again`), the other
  devices untouched; a device on the port that does not answer yet (a module
  starting, or one a set-up elsewhere left so) is tried again every 3 s, ten
  times. A web page
  through the module's own HTTP client: `at +cgact=1,1`, `at +httpinit`,
  `at +httppara="URL","http://example.com/"`, `at +httpaction=0` (its
  `+HTTPACTION: 0,200,<length>` comes seconds later: the next `at` shows
  it), `at +httpread=0,<length>`, `at +httpterm`.
- **Ethernet**: a USB Ethernet adapter with a CDC ECM function -- an
  RTL8153 (0bda:8153) in its second configuration, which the demo chooses
  when the first has no ECM -- becomes eth0: its MAC address from the
  Ethernet descriptor, frames over its bulk endpoints (read every 20 ms in
  the main loop), DHCP at once (`[eth] eth0: 192.168.0.161 (DHCP) ...`;
  with no answer it says so once and asks again every minute, and a lease
  is renewed at half its time),
  ARP and ICMP echo answered (the box can be pinged). `ifconfig` shows the
  port, `dhcp` asks again, `arp` lists the table, `ping [-c n] <host>`
  pings like Linux's ping: a name asked of the DHCP's DNS server, each
  reply's TTL and time, ICMP errors, Ctrl-C and the statistics with the
  loss (`ping` alone still answers pong). The keyboard is
  read through endpoint D, which polls by itself, and a mouse through
  endpoint B's turns: frames read through endpoint B every 20 ms lost a
  keyboard's reports there. While that mouse moves (a report in the last
  half second) the frames are read every 250 ms instead, and only between
  its reports, when its IN is not half way through the hub's split
  transaction: the adapter keeps them meanwhile.
- **The LTE module's network link (RNDIS)**: a GSM / LTE module's RNDIS
  function (the A7670E's interfaces 0 and 1: control e0/01/03 or 02/02/ff,
  data 0a with a bulk IN and OUT) is set up as Linux's rndis_host does --
  INITIALIZE (transfers of 1600 bytes, one frame each), QUERY of its MAC
  address, SET of the packet filter, each over endpoint 0
  (SEND_ENCAPSULATED_COMMAND, then GET_ENCAPSULATED_RESPONSE asked until
  the answer is there) -- and carries Ethernet frames in RNDIS packet
  messages. One link carries the network at a time: the Ethernet adapter's
  when there is one; the module's when there is none, when the adapter is
  unplugged, or when it gets no DHCP answer -- so `ping`, `wget`, NTP,
  telnet, FTP and netload go through whichever is there; `ifconfig` says
  which and names the other. Checked in the emulator (its VirtualModem's
  RNDIS function with a small network behind it: DHCP, ARP, ping); the real
  module was not plugged in.
- **TCP and what runs on it** (`tcp.c`, `net.c`): four connections, MSS
  1460, go-back-N retransmission (400 ms doubling to 3.2 s), FIN and RST
  both ways; while a connection is busy the frames are read every pass.
  `netstat` lists them. On it:
  - `wget [-O n:path] [--no-check-certificate] <http[s]://url>`: HTTP/1.0,
    the body on the console or saved to a disk (example.com in 0.08 s; 1 MB
    from the internet at 760 KB/s onto the card); a redirection (301, 302,
    303, 307, 308) is followed, up to 10. https:// goes over TLS 1.2
    (`tls.c`): BearSSL 0.6 (`firmware/maciej_app/bearssl`, MIT, the 86 of
    its 277 source files a full client needs; build.py compiles them into a
    library when `tls.c` is built), every cipher suite of its full client,
    SNI, the certificate chain checked against Mozilla's 118 roots
    (`tls_anchors.bin`, built in by `tls_anchors.S`; `tools/tls_anchors.py`
    makes it from curl's cacert.pem and lists the roots in
    `tls_anchors.txt`) and the NTP clock, the name checked against the
    host's; `--no-check-certificate` takes the server's key and checks
    nothing. The box has no random number generator: TLS's randomness is
    CP0 Count sampled as Ethernet frames arrive and around the handshake,
    hashed with the clock and the last seed -- unpredictable without
    cycle-exact sight of the box, not a hardware RNG. No TLS 1.3 (BearSSL
    has none). About 100 KB of code and 46 KB of buffers; to make room
    under the stack the Amiga player's four 512 KB memories moved out of
    the image to physical 0x00B00000 (`amiga.h`'s AMIGA_RAM_PHYS). The
    demo is 1.1 MB now (448 KB packed): the original bootloader's check of
    it before it starts takes 8.3 s of emulated time, against 4.7 s for
    the 588 KB demo, so the suite holds 'c' for 12 s (the box's own time
    not measured: it was netloaded, not flashed). On the
    box (2026-11-18): example.com, github.com (after its http:// 301),
    letsencrypt.org and www.google.com fetched with the certificate checked
    (handshakes 0.22 - 0.63 s, ECDHE with ChaCha20-Poly1305 or AES-GCM);
    badssl.com's self-signed, expired and wrong-host certificates each
    refused with its reason, the self-signed one taken with
    `--no-check-certificate`; 8 MB saved to the card at 320 - 350 KB/s
    (AES-128-GCM), byte for byte the file a PC downloaded.
  - A telnet console on port 23: the command line as on the UART (one
    client; what the box prints goes to both, what the client types is
    fed in as if typed, Ctrl-C included).
  - Netload on port 6464: `python tools/maciej_netload.py <box> [app.bin]`
    sends a build ("M4LD", length, CRC-32, the image); the box checks it,
    copies it over itself with a stub in uncached RAM (cache written back
    and invalidated, `jr.hb`) and runs it -- about a second from the
    command to the new banner, against 48 s for a flash; the flash keeps
    the old build. A wrong header, length, CRC or image is refused and the
    box goes on.
  - NTP: the clock set after DHCP (pool.ntp.org) and with `ntp [server]`;
    `date` shows UTC and Polish time (CET / CEST); the TV shows the date
    and time in the console's title bar after the uptime, and in the test
    screen's SYSTEM box.
  - An FTP server on port 21 (`ftp.c`), two clients (FileZilla opens a
    second connection for transfers; one transfer at a time, another gets
    450 and is tried again), no password: its root
    lists every disk's volumes as directories ("4 PHONE CARD", "9 Windows
    10": the number as `cd` takes it, and the label); files are read from
    FAT and NTFS, and written (STOR, APPE, DELE, MKD, RMD, RNFR / RNTO; NTFS
    when the demo writes it, see USB disks). PASV / EPSV (data ports 50021 and
    50022, a connection taken from its client's address only) and PORT /
    EPRT (to the client's address only; Windows' own firewall cuts a
    connection that uses them, so they were not tried on the box), LIST /
    NLST / MLSD / MLST, SIZE, MDTM, REST (for the command right after it
    only). A transfer that moves nothing for a minute ends and a client
    silent for five minutes is let go (tcp.c has no keepalive); a data
    connection's TIME_WAIT slot is taken again when every slot is in use
    (20 downloads in a row). Paths longer than disk.c takes (95
    characters, names 127) are refused, not cut. A transfer moves in the
    main loop, eight 4 KB pieces a pass, with
    a reader and a writer of its own in disk.c (its NTFS runs apart from
    `cat`'s), so the pointer and the console go on; on the box the card
    took uploads at 120 - 235 KB/s and sent at 970 KB/s, the slow NTFS stick
    sent at 30 - 85 KB/s, and every CRC matched `sum`'s. A directory is
    listed with its first 7000 entries (451 when cut); a STOR over a file
    empties it first (as most servers do); writing the same disk from the
    shell while an upload runs is not guarded. The explorer lists a
    directory again at most once a second while a disk is being written.
  - A web page on port 80 (`http.c`, the page itself `web.html`, built in
    by `web.S`'s `.incbin`), no password, for any browser on the network
    (a phone's too: the layout narrows to one column): the disks' files
    (listed, downloaded, uploaded by a button or by dropping files on the
    list, renamed, deleted, new folders; pictures and text files opened in
    the browser), the TV's picture (a BMP of what the display shows -- the
    test screen or the console -- 640 x 360 about once a second, or the
    whole 1280 x 720), a remote on the page (arrows, OK, Esc, Tab, Space,
    A / B for the games, Ctrl-C) and the command line (a small terminal fed
    from a 64 KB copy of everything printed -- `uart_putc` -> `http_putc`
    -- by a long poll, typed into through uart.c's injection queue as the
    telnet console is; a line box under it for phones' keyboards). Its API:
    `GET /api/info`, `/api/ls?p=`, `/api/get?p=[&inline=1]`,
    `PUT /api/put?p=` (Content-Length), `POST /api/rm|rmdir|mkdir?p=`,
    `/api/mv?p=&to=`, `GET /api/screen.bmp[?half=1]`, `/api/out?from=`
    (waits up to 15 s for new output), `POST /api/in` -- errors as JSON
    `{"error": ...}` with the disk.c message. HTTP/1.1 with keep-alive
    (a connection a request would leave tcp.c's connections in TIME_WAIT),
    six connections (a browser's per host; tcp.c has 14 now, with SMB's two, and 8
    listening ports). It runs in the main loop and, while a command runs,
    from `net_uart_poll` (as the telnet console's input), where everything
    but the disks goes on -- the picture, the keys, the output -- and the
    disks answer 503 ("a command is running") or, for a transfer under
    way, wait. One file moves at a time between it and FTP (disk.c's one
    reader and one writer): the other gets 503 / 450. An upload is written
    in whole 4 KB pieces (the bytes that came with the request's header
    put every piece after them across sectors: 0.08 MB/s, then 0.11 - 0.14
    as FTP's 0.13 - 0.16 on the card the same day); one cut short is
    deleted. On the box, from a PC (a Python test of every request, not in
    the repository): downloads 0.74 - 0.99 MB/s, the 640 x 360 picture in
    0.7 - 1.4 s, 1280 x 720 in 2.1 s; typed `version` answered through the
    page; a game started from the page's command line, its picture taken
    while it ran, the disks refused meanwhile, Ctrl-C from the page ended
    it. The emulator has no network adapter, so the suite does not reach
    it.
  - An SMB2 file server on port 445 (`smb.c`) for Windows' own client:
    `\\192.168.0.161\4` (or `\4 PHONE CARD`: the shares are the disks'
    volumes, named as FTP's root names them), `net view`, Explorer, `net
    use`, robocopy. Dialect 2.1 (2.0.2; an SMB1 NEGOTIATE gets SMB2's
    answer), SPNEGO / NTLMSSP with any user and password taken -- a guest
    session, so nothing is signed (Windows 10 Home and Pro allow guest
    logons; Enterprise / Education and Windows 11 24H2 Pro refuse them),
    the srvsvc pipe's NetShareEnum for the share list,
    FSCTL_VALIDATE_NEGOTIATE_INFO, compounded requests; files read and
    written through disk.c's reader and writer as FTP's are (reads anywhere;
    writes from the start or at the end -- what the writer can do; an
    allocation or end of 0 empties a file), rename / move, delete, mkdir /
    rmdir, the listing classes Explorer asks for, free space. Two clients,
    48 open files; one file written at a time; ASCII names. On the box from
    Windows 10 (2026-11-18): `net view`, `dir`, Copy-Item / robocopy of a
    3 MB file and of a folder tree both ways (byte for byte), Set-Content /
    Add-Content, rename, move, a copy within the share, delete, rmdir /s;
    3 MB up in 15.8 s and down in 3.5 s -- uploads as fast as FTP's (the
    card is what takes the time). Found on the way: Windows logs off when
    FSCTL_VALIDATE_NEGOTIATE_INFO's answer is unsigned (so the session is a
    guest's); PowerShell empties a file with an allocation size of 0, then
    writes after what it read of it.
  - SSDP, UPnP's discovery (`ssdp.c`, UDP 1900, group 239.255.255.250):
    the box is a basic UPnP root device (its UUID from the MAC) -- NOTIFY
    ssdp:alive three times 2 s apart once DHCP gave an address, then every
    10 minutes (max-age 30), an IGMPv2 report every minute (for switches
    that snoop IGMP); M-SEARCH for ssdp:all, upnp:rootdevice, its uuid or
    device type answered; its description at `/ssdp/device.xml` on the
    web page's server ("M3801 v4 demo (address)", the web page as its
    presentation URL). The Ethernet adapter's filter now takes all
    multicast (CDC ECM's ALL_MULTICAST, RNDIS's), eth.c hands over the
    group's datagrams and drops the rest. On the box: its NOTIFYs heard on
    the PC, every M-SEARCH answered, and Windows' UPnP device finder
    (UPnP.UPnPDeviceFinder, what the Network folder's "Other devices"
    uses) lists it by name; Explorer's view itself was not looked at.
  - More game players, each a machine in its own file that knows nothing of
    the box (play.c hosts them, as the NES and the Game Boy): `z80.c`, a Z80
    core (every opcode incl. the undocumented ones and MEMPTR; zexdoc and
    zexall pass completely on a PC, and Patrik Rak's z80test 1.2a z80full /
    z80doc / z80flags / z80docflags / z80ccf / z80memptr on the emulated
    Spectrum), shared by `sms.c` -- the Sega Master System and Game Gear
    (mode 4 picture chip, line interrupts, H / V counters, Sega and
    Codemasters mappers, cartridge RAM; FluBBa's VDPTEST: all data-port and
    misc tests, 18 of 20 sprite tests) -- and `zx.c`, the ZX Spectrum 48K
    (the ULA's picture with its border, contended memory, the keyboard
    matrix from a USB keyboard's held keys, Kempston joystick; .sna, .z80
    v1-3, .tap and .tzx loaded at once through a trap on the ROM's LD-BYTES
    with LOAD "" typed by itself; the ROM is the user's 48.rom file, not in
    the demo); `a26.c`, the Atari 2600 (6507 with decimal mode and the
    stable undocumented opcodes -- Klaus Dormann's functional and decimal
    tests pass --, the TIA per colour clock caught up lazily, the RIOT, the
    bank-switching boards 2K / 4K / F8 / F6 / F4 / Superchip / FE / E0 /
    3F / E7 / FA; pixel-exact against Stella 7.0 on 17 homebrew title
    screens and hand-made TIA timing / board carts). play.c gained separate
    horizontal and vertical enlargement (the 2600: 5 x 3), a picture whose
    size a game changes (the Master System's 224-line mode) and a computer's
    keyboard (every held key of the USB keyboard to the Spectrum,
    characters typed on the UART typed on it). On the box: a Master System
    or Game Gear frame 3.5 - 5.5 ms to run + 1 - 2 ms to draw, a Spectrum
    frame 4 ms + 2.5 ms (of 20 ms), a 2600 frame 3.5 - 5.5 ms + 1 ms. The
    suite checks each with a program made in the test (a stand-in for the
    Spectrum's ROM).
  - The RF front end of the Comsat TE 1050 HD (`rf.c`, command `rf`): the
    MaxLinear MxL603 tuner on SCB0 (I2C 0x60; found as MaxLinear's
    MxLWare603 compiled into dump.bin, its tables at 0x8073282C /
    0x80732908; 16 MHz crystal, IF 4.57 MHz) and the S3811's own COFDM
    demodulator at 0xB803E000 (about 20 writes, no firmware: the IF word
    frac(IF / 1.6875 MHz) x 2^24 at 0x14..0x16, the bandwidth in 0x13,
    acquisition through 0x00, lock bits in 0x1D, the IF AGC level at
    0x30 / 0x31, error counters 0x09..0x0D), the stream routed through the
    TSI into DMX0's ring -- all as dump.bin's own driver writes them, its
    I2C transactions and demodulator writes checked byte for byte against
    dump.bin's in the emulator. `rf scan`, `rf services` (PAT / SDT / PMT)
    and `rf ts` (a PID table, or a .ts file) work in the emulator. On the
    box the tuner answers (chip id 2, version 2) and locks, the demodulator
    searches -- but Poland's multiplexes are DVB-T2 now and the S3811 is
    DVB-T only, so nothing locks there. `rf spectrum` draws the aerial's
    level across 174 - 862 MHz on the TV (the tuner stepped every 4 MHz,
    the demodulator's IF AGC read after 160 ms; shorter waits read the AGC
    before it settles). On the box it shows three flat-topped blocks, each
    exactly 8 MHz wide with sharp edges, centred on 668.25, 742.5 and
    816.75 MHz: 9, 10 and 11 x 74.25 MHz (swept every 250 / 500 kHz, the
    centres to 0.25 MHz). That shape is one narrow carrier seen through the
    tuner's 8 MHz filter (a multiplex would ramp up and down over 8 MHz on
    each side), and 74.25 MHz is the box's own 720p pixel clock (the CPU's
    594 MHz is 8 x it): the box hears itself. Everywhere else the level
    stays at its floor (16 %, the IF AGC at full gain): no aerial was
    connected for these sweeps. An earlier reading of these blocks as two DVB-T2
    multiplexes and the LTE-800 band was wrong. `rf live [from to]` is that chart kept
    current: the band swept again and again, each bar drawn as it is
    measured, the highest level seen kept as a tick over it, a marker with
    its frequency / channel / level. Keys (USB keyboard, UART, remote):
    Left / Right the marker (past an edge the window moves), Up / Down
    halve / double the span around it (8 - 960 MHz), PgUp / PgDn move the
    window, F the whole band, + / - halve / double the settle time (160 ms
    at first, 40 - 640), Space pause, P peak hold, Enter a DVB-T lock tried
    on the marker's channel, Esc ends. A pass still takes its points times
    the settle time (the whole band in tens of seconds, a narrow window in
    a few). The level axis follows what is measured; when it changes only
    the bars and its labels are drawn again.
  - A Commodore 64 (PAL) player (`c64.c`, command `c64`, the explorer's .prg /
    .t64 / .d64 / .p00): the 6510 (a26.c's 6507 grown into it -- the $00/$01
    port, every undocumented opcode; Klaus Dormann's tests pass), the PLA's
    banking, the VIC-II line by line (bad lines taking 40 cycles, raster
    interrupts, every graphics mode, scrolling, 38 / 24 columns, the 8
    sprites with their collisions; a line drawn at cycle 36), both CIAs
    (timers worked out from elapsed cycles when the program touches them,
    TOD, keyboard, joysticks, the VIC bank, NMI / RESTORE), SID voice 3's
    oscillator and envelope (read for random numbers; no sound). LOAD is
    trapped in the KERNAL and done at once from the .t64 or .d64, with a
    simulated 1541 at the KERNAL's serial-bus routines (OPEN / CHKIN /
    CHRIN, channel 15); the traps only switch on for the three standard
    KERNAL revisions. A program is typed in as LOAD"*",8,1 and RUN (or
    SYS) once BASIC waits for keys. The ROMs are the user's files
    kernal.rom / basic.rom / chargen.rom, not in the demo. Wolfgang Lorenz's
    suite: 245 of 264 (the 19 failing test cycle-exact CIA and interrupt
    timing). On the box a frame takes 3 - 4 ms to run + 3 - 5 ms to draw
    (the 352 x 240 picture three times as large); Magicland Dizzy (a .t64)
    plays through its crack intro and trainer menu into the game, Hessian
    loads from its .d64. The suite checks it with stand-in ROMs made in the
    test.
  - An Amiga 500 (OCS, PAL) player (`amiga.c`, command `amiga`, the
    explorer's .adf): a 68000 interpreter (a 64K opcode table built at
    start, every instruction, exceptions, the 7 interrupt levels, the
    manual's cycle counts; all 260,664 SingleStepTests m68000 cases pass
    on a PC), 512 KB of chip RAM + 512 KB at 0xC00000, Agnus (copper
    interleaved with the 68000, blitter with every minterm, fill and line
    mode, bitplane and sprite DMA, beam counters), Denise (1 - 6 planes,
    low / high resolution, dual playfield, HAM, EHB, scroll, priorities, 8
    sprites; colour changes from the copper where they fall in the line),
    Paula (interrupts, floppy DMA from MFM tracks built from the .adf as
    AmigaDOS writes them, the sound's interrupts without the sound), both
    CIAs (timers, TOD, keyboard handshake, drive lines). The picture is
    352 x 272 (PAL's 320 x 256 with overscan) shown twice as large. The
    Kickstart is the user's kick.rom, or AROS's free aros-rom.bin +
    aros-ext.bin. On the box a frame takes 5.5 - 9 ms to run + 3 - 4 ms to
    draw; Magicland Dizzy (the TRSi crack) boots with AROS into the game.
    The suite checks it with a stand-in Kickstart made in the test.
  - A DOS PC player (`dos.c`, command `dos`, the explorer's .exe / .com): an
    80286 in real mode (lazy flags), 640 KB, the 8259, the 8253 (a new count
    in modes 2 / 3 taking effect at the period's end, as the chip does:
    Magicland Dizzy's sound driver times its delays with it), the keyboard
    controller and its interrupt, a VGA (text modes with a 5 x 7 font in 8 x 8
    cells, CGA 4 / 5 / 6, the planar EGA modes with latches and every write /
    read mode, 13h and mode X); the BIOS and DOS are C behind a stub per
    vector (so programs that chain to the old handler work): an MZ .exe
    loaded with its relocations and a PSP, memory blocks, file reads of its
    own file. 14.3 MHz worth of instructions, a 70 Hz frame, loops that only
    wait for an interrupt skipped. Magicland Dizzy (DOS, 1993: PKLITE-packed,
    EGA mode 0Dh in VGA colours, 50 Hz timer) plays on the box: a frame
    2.5 - 4 ms to run + 2 - 2.5 ms to draw (960 x 600). The suite checks it
    with a .com program made in the test.
  - A Sega Mega Drive / Genesis player (`md.c`, command `megadrive` -- `md` is
    the memory dump --, the explorer's .md / .gen / .smd, and a .bin whose
    first 2 KB say it is one). The 68000 is the Amiga's: moved into
    `m68k.inc`, included by `amiga.c` and `md.c` so memory access stays
    inlined, with hooks for the interrupt acknowledge (the VDP clears its
    pending interrupt), TAS and branch watching (waiting loops skipped); the
    Amiga is bit-identical (every frame's picture, registers and cycles
    over AROS and both Dizzy disks; SingleStepTests; the same -Os code). The
    Z80 is `z80.c` (a read hook added for the 68000's bank window). The VDP
    draws line by line: both planes with full / cell / line horizontal and
    full / 2-cell vertical scroll, the window, sprites (link list, per-line
    and dot limits, X = 0 masking, overflow and collision), shadow /
    highlight, H32 / H40, V28 / V30, HINT / VINT, DMA (68000 to VRAM / CRAM
    / VSRAM, fill, copy). Sound: the YM2612 (6 channels of 4 operators, 8
    algorithms, envelopes, LFO, channel 3's mode, the DAC, timers A / B)
    and the PSG, mixed to 48 kHz mono. Pads: 3 and 6 buttons (the player
    gives a 3-button pad: X = B, Z = A, Tab / Space = C). Cartridge RAM
    (.sav), Sega's mapper over 4 MB, Super Mario World (Taiwan)'s
    protection. .smd (interleaved, with or without its header) and a copier
    header on a plain image are found by their bytes; NTSC / PAL by the
    header's region, or `-r j|u|e`. On the box, with sound, at 60 frames a
    second: Super Mario World (Taiwan) 12.3 ms to run + 2.7 ms to draw,
    Super Mario Bros. (PD hack) 9.3 + 1.9, Snake 9.7 + 2.3. Two things made
    that fit: the sound chips' writes are logged through the frame and the
    sound made from the log at its end in one go (the same sound, sample
    for sample, as made after every line -- but its tables stay in the
    caches: 2.3 ms of the frame instead of 5.1), and the FM operators are
    worked out every second sample (26.6 kHz). Box and PC give the same
    picture CRCs. Raster demos that change every line (a-dietrich's wobble,
    scaling) do not fit in 16.7 ms. Not done: changes in the middle of a
    line, interlace mode 2 (its first field only), SSG-EG and CSM, the
    YM2612's busy flag. The suite checks it with a cartridge made in the
    test.
  - SG-1000 / SC-3000 (`sms.c`, command `sg`, the explorer's .sg / .sc): the
    TMS9918 modes in the Master System's VDP code -- Graphics I and II (with
    the pattern / colour table masks), Multicolour, Text (40 columns), the
    TMS sprites (8 x 8 / 16 x 16, magnified, 4 a line with the 5th sprite's
    flag and number, collision) -- also used when a Master System game
    leaves mode 4; 1 KB of RAM (2 KB on the SC-3000), cartridge RAM by size
    (8 KB at 0x8000 up to 32 KB, at 0x2000 for 33 - 48 KB images whose
    0x2000 - 0x3FFF is blank), the Sega mapper above 48 KB, Pause as the NMI.
    Master System and Game Gear pictures are bit-identical to before. On the
    box a frame takes 5 ms + 1.6 ms to draw. No SC-3000 keyboard, no sound.
  - C64 cartridges (`c64.c`, .crt, found by its "C64 CARTRIDGE" header):
    the PLA's 8K / 16K / Ultimax maps (the VIC seeing ROMH in Ultimax), and
    the boards normal, Ocean, Magic Desk, EasyFlash (with its 256 bytes of
    RAM; flash writes ignored), System 3, Dinamic, Fun Play, Super Games,
    RGCD, Simons' BASIC, Final Cartridge III (not its NMI). The machine
    starts in the cartridge; a reset brings it back to bank 0. A damaged
    file is refused, never followed (fuzzed: 400 damaged cartridges under
    AddressSanitizer). Without a cartridge every picture is as before. On
    the box a frame takes 3.3 ms + 2.7 ms.
  - Archives for every player (`zip.c`, `play.c`, the explorer): a game in a
    .zip (stored or deflated; the largest member that is no text, picture or
    folder) or a .gz (the Amiga's .adz too), unpacked with `image.c`'s
    inflate and its CRC-32 checked. The machine is told the member's own
    name beside the archive (the Spectrum, the C64 and the SC-3000 know a
    file by its extension); the .sav goes beside the archive; the explorer
    picks the player by the member. On the box an archived game gives the
    same picture CRCs as the file itself (the user's zipped Super Mario
    World and Super Mario Bros., Tobu Tobu Girl, a gzipped Dizzy disk).
  - Sound (a prototype nobody has heard yet: the user's HDMI-to-VGA converter
    drops it). `snd.c`, command `snd` (`init`, `beep [Hz] [ms]`, `vol`,
    `status`, `stop`): the S3811's sound engine at 0xB8002000 set up as
    dump.bin's "SND_S3601" driver does (ALi's snd_m36 with its S3811 branches,
    found byte for byte in dump.bin against libcore_hd.a's symbols): a PCM
    ring of 8 frames of 960 samples (16-byte units of two stereo 24-bit
    samples, a 2-unit header n / 2 + 2) read by DMA at 48 kHz, its I2S out
    taken by the HDMI transmitter (audio on, N 6144 / CTS from the hardware),
    the chip's own DAC on the SCART powered up and GPIO 14 (the Comsat's mute)
    raised. On the box its DMA index moves 48001 samples a second, a frame
    interrupt each 960, the HDMI transmitter measures CTS 74247. `play.c`
    feeds each frame's samples of a machine that makes sound (not in `-f`
    runs); the NES's sound chip is in `nes.c` (both pulses, triangle, noise,
    DMC, the standard mixer, the console's filters, all integer, made lazily;
    off it costs nothing and every test result is as before): a game's 994
    frames of sound in 19.8 s all played, none dropped, the game still 8.2 ms
    a frame.
  - Video files on the chip's own MPEG-2 and H.264 decoders (`av.c`,
    `avc.c`, `mp2.c`; commands `play [-n frames] [-x] [-k] [-v] [-1] <file>`
    and `av <status|shot|show|off|reset>`; Enter on a .ts / .mpg / .m2v /
    .vob / .264 / .h264 / .mp4 / .m4v / .mov in the explorer).
    dump.bin runs every A/V driver on the one MIPS (no second core on the
    S3811): DECV_S3601 for MPEG-1/2, DECV_AVC for H.264 (the same block's
    second engine, below), DECA = ALi's libmpg on the CPU, SND (`snd.c`). The
    decoder ("VE", 0xB8004200, interrupt 9, reset 0xB8000080 bit 1) decodes
    slices from a buffer at a bit offset / length the CPU gives it and stops
    at the first start code that is not a slice's; the CPU parses the
    sequence / picture headers and sets the per-picture registers as dump.bin
    does (0x803247BC, the S3811 branches of libcore_hd.a's
    vdec_config_hw_new_picture). Its frames (five buffers, luma in 32 x 16
    tiles of 512 bytes, chroma 16 Cb/Cr pairs x 16 lines) must lie in one
    32 MB window (+0x78). It reads ahead: given exactly one picture it stops
    one macroblock short, so 2 KB of zeros follow the data. The main picture
    layer of the display engine (0xB8006000: +0x164..+0x170 the frame's
    addresses, +0x178 / +0x17C source layout / size, +0x180 / +0x184 where
    on the screen, +0x190 bit 21 on) shows it under the OSD. Its scaler
    takes its filters from RAM: +0x1E4 holds the address of a parameter
    block the engine reads by itself (16-bit signed coefficients, a row of
    taps for each of 32 phases, a row's sum 256: +0x000 vertical luma, 4
    taps; +0x100 vertical chroma, 4; +0x200 horizontal luma, 8; +0x400
    horizontal chroma, 4; +0x500.. other tables). dump.bin computes them
    for each source / screen ratio (0x802D3B5C); `av.c` carries what that
    generator gives for seven ratios (run on the PC from dump.bin's RAM
    image) and picks the nearest. The demo's video set-up had left the
    pointer at dump.bin's own address, so the first version filtered the
    picture with whatever lay there: broken on the TV although every frame
    in RAM was right. With the block go the rest of what dump.bin's scale
    function (0x802C3D4C) writes: the steps (+0x110..+0x11C), where the
    picture starts (+0x100..+0x10C, +0x1C8 / +0x1CC), the last column
    (+0x134 / +0x138), +0x144 / +0x148 = 1. The layer's fetch mode
    (+0x190 bits 17-18) must be 1, the frame's lines in turn: as 0, one
    field, the screen showed the picture at half its height and below it
    what lies after the frame in RAM. Files are taken
    apart in software (transport streams via PAT / PMT, program streams,
    plain .m2v); MPEG audio Layer II is decoded in `mp2.c` (checked against
    ffmpeg on the PC: 65.8 dB) and mixed to mono for `snd`. On the box:
    a 720 x 576 25 frames/s 6 Mbit/s .ts plays in real time (500 pictures
    I / P / B in 20.31 s, 1 late, 0 errors, all its sound decoded and
    played); frames read back from RAM (`av shot`) match ffmpeg's to 70 -
    76 dB for I, P and B pictures, interlaced field-DCT, MPEG-1 and
    1920 x 1080 (11 ms a picture on average, 24 at most); Esc ends it in
    0.22 s and gives the OSD back. Not done: MPEG-2 field pictures (each
    field into its own frame). The box cannot read its own TV output back
    (VCAP at 0xB800E400 reads all zeros on the S3811), so what the TV shows
    is checked by eye: seen right (the whole 720 x 576 test picture, its
    colours, the time code readable) through a phone's camera after the two
    fixes above, each of which was needed (the old filter address again: a
    green mesh). The suite
    checks only how files are taken apart (the emulator has no decoder).
  - H.264 (`avc.c`: .264 / .h264 elementary streams, transport streams with
    stream type 0x1B) on the block's other engine, DECV_AVC: the "console"
    at 0xB8004000 picks it (+0 = 1), its registers are at 0xB8004200 too.
    The engine does everything below the slice header (CAVLC / CABAC, the
    predictions, the transforms, the deblocking filter, the implicit
    weights); the CPU parses the NAL units, the parameter sets and the
    slice headers, keeps the decoded picture buffer (picture order counts
    of types 0-2, the reference lists and their modification, the sliding
    window and MMCO 1-6, the output in display order) and gives the engine
    each slice as register words, its data from a 256-byte boundary at a
    bit offset counted in the stream's escaped bytes; its start code
    detector ends the slice. The register map, from ALi's libcore_hd.a
    (vdec_avc_hal.o) and dump.bin's newer build, is in `avc.c`'s head; on
    revision 1 control / start / status are at +0x80 / +0x84 / +0x88
    (revision 0: +0x20..). Found on the box: the "MB col" buffer (+0x50)
    holds a region for every frame buffer number k at +0x1000 + k x (32 x
    the picture's macroblocks + 0x3000, rounded up to 256) -- dump.bin's
    0x22000 bytes work only because its motion vectors follow; with the
    neighbour buffer there, the frame buffer whose region reached into it
    ended its pictures with the error bit (number 0 at 1080p, 5 at 352 x
    288); a picture's references are marked after its last slice (after
    its first, a four-slice picture became its own reference); the input
    registers are written once a slice (twice: time-outs). Frames are
    tiles one macroblock wide and 32 lines high, every four lines in the
    order 0, 2, 1, 3; the main picture layer reads that with +0x190 bit 1
    and the width in macroblocks in +0x178. 1080p takes 12 frame buffers
    (46 MB with the motion vectors and the "MB col" regions). While the
    engine decodes a slice the player reads the file and decodes the
    sound: one after the other, 7 frames of the 1080p trailer below were
    late. On the box (test code from RAM and the player, every frame read
    back with `av shot` and compared with ffmpeg's): identical, byte for
    byte, for Baseline / Main / High, CAVLC and CABAC, I / P / B pictures,
    up to 5 references, B pictures as references, temporal and spatial
    direct prediction, explicit and implicit weights, the 8x8 transform,
    four slices a picture, 352 x 288 to 1920 x 1080. In real time with all
    their sound: the Sintel trailer (1920 x 1080 High 5.0, 24 frames/s)
    1253 pictures in 52.6 s, 0 late, 24 ms a picture on average (29 at
    most); Big Buck Bunny 1280 x 720 High 4.0, 813 in 32.9 s, 0 late;
    Sintel 720 x 576 Main 3.0, 249 in 10.3 s, 0 late. On the TV a frame of
    the 1080p trailer was seen right (by eye). Not done: interlaced
    H.264 (field pictures, MBAFF: refused with a message), 4:2:2 / 4:4:4,
    more than 8 bits, slice groups, data partitioning, SP / SI slices,
    pictures over 1920 x 1088; custom scaling matrices are sent as the SDK
    sends them, not tried on the box; HEVC (stream type 0x24) is named, not
    played. The suite plays a 32 x 32 H.264 stream in a .ts: its parameter
    sets read and its picture set up ("video: H.264 Baseline 1.0, 32 x 32
    ..."), then the emulator's missing engine reported.
  - .mp4 / .m4v / .mov files (`av.c`'s MP4 reader): the H.264 track (avc1
    / avc3) given to `avc.c` as an elementary stream. The index (moov) is
    found by walking the top-level boxes (64-bit sizes too) and read whole
    into the stream buffer -- before or after the samples (mdat): ffmpeg
    and cameras put it after them, so the reader seeks there and back
    (`disk_stream_seek` now goes to any sector, forwards or back; on FAT a
    seek back walks the cluster chain again from the file's first cluster).
    The video track's stsc / stsz / stco (or co64) tables are kept as the
    file has them (2 MB at 0x05E00000: about 400000 samples), the samples
    are read in their order, each chunk from its place, the sound's chunks
    between them passed over; each NAL unit's 1, 2 or 4-byte length becomes
    a start code and the avcC box's SPS / PPS go first. The frame rate is
    the track's (the commonest stts step in mdhd's time scale). The sound
    is named (an mp4a's esds -- inside a wave box in a .mov -- says AAC,
    MPEG audio, AC-3) and not played. Refused with a message: other video
    (HEVC, MPEG-4 part 2, AV1, VP9), fragmented files (moof: no samples in
    the index), stz2 sizes. On the box: Sintel 720 x 576 as .mp4 and .mov,
    249 pictures in 10.19 s, 0 late; Big Buck Bunny 720p (its index after
    11.6 MB of samples) 813 in 32.88 s, 0 late, its frames read back
    identical to ffmpeg's; a 1080p trailer excerpt damaged by FTP uploads
    (below) 624 pictures in 26.4 s, 0 late, its damaged slices flagged, no
    hang. The suite plays a 80 KB .mp4 with 2-byte NAL lengths and co64,
    its index after its samples (seeks forward, back and over a 40 KB sound
    chunk), and refuses an HEVC one.
  - Found and fixed meanwhile (`usb.c`, `epb_end`): files uploaded by FTP
    to a USB disk sometimes came back with 66 to 250 wrong bytes from byte
    62 of a 4 KB block -- the controller's DMA receiver, left started by an
    IN that had received nothing (the network adapter's frames looked for,
    none waiting), woke with the next OUT's en_dma_transfer and wrote into
    its buffer, the bulk buffer that OUT was sending to the disk. Shown on
    the box with a debug build: the bytes FTP handed the disk writer had
    the file's CRC-32, while the bulk buffer changed under the transmitter
    (the receiver's index 32 after the 31-byte command block, about 400
    after the 4 KB of data). Each IN now ends with the receiver set back
    (+0x60 = 0x20, init_dma_rx_state), as the transmitter is after every
    OUT: three 15 MB uploads in a row came back identical, at 0.24 MB/s
    (the receiver also set back before every OUT, uploads ran at half
    that speed). The suite checks the order of those stores over every
    transfer of its run (the emulator's controller model writes nothing
    stray).
- **File explorer on the TV** (`explorer [n:][path]`, `explorer.c`): the
  current directory's entries (directories first) under a path bar that
  follows `cd` both ways -- a `cd` on the UART lists the new directory, a
  directory opened in the explorer becomes the prompt's. The path bar can
  be typed into (a click, '/' or Tab; Enter goes there with `cd`'s rules,
  an error stays in the status line). The USB keyboard's arrows, PgUp /
  PgDn, Home / End, Enter and Backspace move through it, the mouse clicks,
  double-clicks and scrolls with its wheel, and a file opened shows its
  first 2 KB (text or hex) on the TV -- a picture opens in the viewer, a
  `.nes` file in the NES player, and the explorer comes back after them.
  Without a current directory it lists the disks' volumes. Esc or `console`
  returns to the console. It writes too, with Norton Commander's keys (kbd.c now sends F1-F12, Delete
  and Insert as a VT220 does; the command line takes Delete as Backspace and
  passes the others over): F2 renames the selected entry (its new name typed
  in the path bar), F7 makes a directory, Delete or F8 deletes a file or an
  empty directory after "y", F5 / F6 mark a file to copy / to move and
  Insert (or Ctrl-V) pastes it into the directory shown -- copied onto any
  FAT or NTFS volume, moved on the same one. In the
  emulator 19 checks of these passed.
- **Picture viewer** (`view [-1] <file>`, `image.c`, `view.c`): JPEG
  (baseline and progressive, 4:4:4 / 4:2:2 / 4:2:0 / gray, restart
  intervals, the EXIF orientation), PNG (every colour type and bit depth,
  palette transparency, Adam7 interlacing; its own inflate), GIF (the first
  picture, interlaced or not, transparency) and BMP (1 / 4 / 8 / 16 / 24 /
  32 bits) decoded a row at a time into the picture as it is shown: made
  smaller by averaging, larger only by whole times, in the middle of the
  TV's 1280 x 720, turned as a phone photo says. A baseline JPEG of any size
  needs only a few rows of blocks; a progressive one keeps its coefficients
  (22 MB of work memory at 0x06900000: about 7 megapixels). Right / Space
  shows the next picture of the directory, Left the one before (the remote's
  arrows, PAGE+ / PAGE- too), `i` the details, Esc or `q` ends. The decoders
  were checked on a PC against Pillow (28 test pictures equal, a JPEG within
  1.6 of 255 on average), in the emulator and on the box: a 1999 x 1333 JPEG
  in 1.5 s (progressive 1.8 s), small files in 0.1 s. As soon as a picture or a game
  starts loading the TV says "Opening NAME ..." (the next picture in the viewer: a strip at the top
  over the one shown); one that cannot be opened says "Could not open NAME" and why (the last line
  printed) for 4 s or until a key.
  - A baseline JPEG goes to the video engine first (`jpeghw.c`): the JPEG
    mode of the MPEG-2 block (0xB8004200, "hardware version 1": its
    extension registers at 0xB8004100), driven as dump.bin's own MJPEG
    decoder drives it (0x800FEB48..) and as the SDK's picture decoder
    does (libplus_hd.a: imagedec_acc36's `jh_*`, `jh_m3602_hw_init`,
    imagedec_main's `buildhuff_hwtable` / `write_hufftable` and
    `decode_next_row_hw_vld`). The engine does the Huffman decoding, the
    dequantisation, the IDCT and the frames, an MCU a start, pre-scaled
    1/2 .. 1/8 when the picture is shown that much smaller; the CPU loads
    the tables, points it at each MCU's first bit (+0x24 / +0x28 / +0x2C),
    reads where it stopped, passes restart markers and stuffed bytes, and
    turns the tiled frames (the MPEG-2 decoder's: luma 32 x 16, Cb / Cr
    pairs) into rows of RGB for the viewer's fitting. It takes grey,
    4:2:0, 4:2:2 and 4:4:4 (shown 4:2:2: the engine halves 4:4:4's colour
    across) with quantisers up to 127 (quality 50 and better); anything
    else -- progressive, 4:1:1 / 4:4:0 (untried), low quality, a file over
    12 MB -- and an engine that does not finish goes to `image.c`, as does
    everything in the emulator (no JPEG engine there: jpeghw finds it read
    no bits at the first MCU). `view -s` decodes with the CPU only, `view -c`
    with both at full size and compares every value. On the box
    (2026-11-18): the engine's decoding of 1920 x 1080 4:2:0 took 56 ms
    against the CPU's 1030, 4000 x 2250 227 against 4075, 1280 x 720
    4:2:2 40 against 566; the largest difference 2 or 3 (the IDCTs'
    rounding), none above 8 -- grey, 1001 x 777 and a file of 67 restart
    markers too. In the viewer: 1080p 504 ms against 1221, the 4000 x 2250
    photo 689 against 4721, a 6000 x 4000 one (at 1/4) 985 against 14381;
    the rest of the time is the fitting to the screen (made quicker for
    both: a multiply instead of three divisions a pixel) and the conversion
    to RGB. The TV pictures were not looked at; the suite checks the
    fallback in the emulator.
- **NES player** (`nes [-f frames] [-k script] <file.nes>`, `nes.c`,
  `play.c`): a NES machine -- the 6502 with the unofficial instructions,
  the picture chip drawn a scanline at a time (the sprite-0 hit at its dot,
  8 sprites a line), controllers, the sound chip's length counters and frame
  / DMC interrupts (no sound) -- and the boards most games came on: mappers
  0, 1 (MMC1), 2, 3, 4 (MMC3, its scanline counter), 7, 11, 34, 66 and 71.
  The picture is shown three times as large (768 x 720) in the middle of the
  TV, only its changed lines drawn; frames come every 16.64 ms. Buttons: a
  USB keyboard's keys while held (arrows / W A S D, X = A, Z = B, Enter =
  Start, Tab = Select), the UART's and telnet's keys as short presses, the
  remote (arrows, OK = A, 0 = B, MENU = Start, INFO = Select, EXIT ends),
  the Comsat's two front buttons (Start, A); Ctrl-C or Esc ends. A game with
  a battery keeps its RAM beside it in a file named after the whole game
  file (`game.nes.sav`, so that `game.gb` there keeps its own; an older
  `game.sav` of the right size is still read, a save of another size is
  another machine's and left alone). `-f` runs that many
  frames as fast as they go and prints the picture's CRC-32 (`-k` gives
  their buttons: `frame:hex,...`). Checked on a PC: nestest's 8991
  instructions with their cycle counts as its log, every sprite-hit test,
  vbl / NMI tests 1, 3, 4, MMC3 tests 1, 2, 5 (the cycle-exact ones fail,
  as a scanline renderer must); four GPL homebrew games (Nova the Squirrel,
  Thwaite, Concentration Room, the 240p test suite) give on the box the
  same picture CRCs as on the PC, a scripted 900 frames too. On the box a
  frame takes 7.7 to 9.6 ms to run and 1.5 ms to draw: a full 60 frames a
  second. No commercial game is shipped with it. The 6502 runs whole
  instructions and the vertical blank flag rises between two of them, its
  NMI taken first: a game that waits for the flag with `LDA $2002 / BPL`
  while its NMI handler reads `$2002` too (Solomon's Key, black screen for
  ever) never saw it -- so with the NMI on, a `$2002` read in the last
  cycle of an instruction that began before the flag rose sees it set, as
  on the console; with the NMI off nothing changed (every test result above
  and the four games' pictures are as before).
- **Game Boy player** (`gb [-f frames] [-k script] <file.gb>`, `gb.c`,
  `play.c` -- the NES player's front end, shared): the first Game Boy (DMG)
  -- its CPU (Sharp SM83) a memory access per machine cycle with the timer,
  the link port and the picture chip moved on before each, the halt bug,
  the timer's reload corner cases, the sprite table's DMA a byte a cycle;
  the picture chip a line at a time (background, window, ten sprites a
  line in their order), its STAT interrupts; cartridges with plain ROM,
  MBC1, MBC2, MBC3 (its clock runs while the game does, from zero) and
  MBC5, battery RAM in a `.sav` file beside the game. No sound (its
  registers read as written). The picture is shown five times as large
  (800 x 720) in the middle of the TV; frames every 16.74 ms (59.7 a
  second); the buttons as the NES player's; Enter on a `.gb` / `.gbc` file
  in the explorer starts it. Checked on a PC (a harness that prints what
  the test cartridges send through the link port): Blargg's cpu_instrs (all
  eleven), instr_timing, mem_timing, mem_timing-2 and halt_bug pass;
  dmg-acid2's picture is its reference to the pixel; 84 of 94 mooneye tests
  for the first Game Boy pass (left: three on the picture chip's switch-on
  timing, four on its interrupt timing with sprites or SCX, the boot
  registers' exact values, the link port's clock at boot, the timer toggled
  fast, and an 8 Mbit MBC1 multicart). On the box six of those cartridges
  give the same picture CRC-32 after the same frames as on the PC
  (cpu_instrs after 3300: all passed); a frame takes 5.7 to 6.9 ms to run
  and 0.6 to 0.9 ms to draw. In the emulator suite a cartridge made by the
  test (a few bytes of program) is played from a stick: its picture's place
  and shade, its CRC-32 with and without A held.
- **Game Boy Color** (the same player): a cartridge whose header asks for
  the Color (0x143 bit 7) runs as on one -- the second bank of picture
  memory (each tile number's attributes: palette, bank, flips, priority
  over the sprites), work RAM in eight 4 KB banks, eight background and
  eight sprite palettes of four 15-bit colours (written through
  BCPS/BCPD, OCPS/OCPD), sprites in front of each other by their place in
  the sprite table, LCDC bit 0 as "sprites in front of everything", the
  copies into picture memory (HDMA: all at once with the CPU waiting, or
  16 bytes in each line's waiting time -- one at once when started in it or
  with the picture off, none while the CPU is halted, the addresses
  counting on from one copy to the next), the double speed (STOP with
  KEY1 bit 0: the CPU, the timer and the copies twice as fast, the picture
  chip not; DIV from 0, then the CPU halted for 0x20000 clock ticks), the
  link port's fast clock, the start-up registers the Color's own program
  leaves (A = 0x11). An older game still runs as on the first Game Boy, in
  its four shades. The picture is passed on as 15-bit colours (the
  Color's own, 0bbbbbgggggrrrrr) for both, not corrected for the Color's
  screen. Checked on a PC: cgb-acid2's picture is its reference to the
  pixel; SameSuite's four DMA tests (gbc_dma_cont, gdma_addr_mask,
  hdma_lcd_off, hdma_mode0), blocking_bgpi_increase and ei_delay_halt pass,
  AGE's spsw-div, spsw-stop-prefetch, ei-halt and halt-prefetch pass (10 of
  35 Color tests; the rest are the picture chip's modes to the machine
  cycle -- they fail run as first-Game-Boy cartridges too -- and the
  speed switch's sub-cycle details). Two fixes for both Game Boys came out
  of it: EI then HALT with an interrupt waiting takes the interrupt with
  the HALT as its return address (it runs again after), and a line ends
  when its dot count passes 456, not only on it (after a switch back from
  double speed it can be 2 off a multiple of 4: the frame never ended). On
  the box cgb-acid2 and the homebrew city builder uCity (MBC5, 128 KB RAM,
  double speed) give the PC's CRC-32: uCity scripted from its title into a
  new city's map, 2100 frames, 12.2 ms to run and 1.5 ms to draw a frame on
  average. A frame whose whole picture changed takes 9 to 10 ms to draw
  (800 x 720 written uncached; through the cache with its lines written
  back is no faster), so frames with fades and scrolling run long (131 of
  uCity's first 300, a few in play) and the next ones catch up. The
  summary line now names the slowest frame and how many ran long; the
  command line takes 159 characters (was 95), for such a test's script.
  The emulator suite's cartridge has a Color version: its palette 0 colour
  1 set to red, red on the TV, the PC's CRC-32.
- **Additional console players** (all sharing `play.c`'s TV scaler, USB/UART/IR
  pad, `.zip`/`.gz` unpacking, `.sav` persistence, 48 kHz HDMI/SCART sound via
  `snd.c`, clean-room built-in BIOS replacements with optional user BIOS files,
  and `explorer` integration; all verified on PC, in `AliSimulator`, and on the
  real S3811 box):
  - **PC Engine / TurboGrafx-16** (`pce`, `.pce`, `pce.c`): HuC6280 CPU
    (627,517/627,517 SingleStepTests), HuC6270 VDC + HuC6260 VCE (256/320/512
    wide), 6-channel PSG, Street Fighter II mapper, 2 KB BRAM `.sav` (4.4-10.4 ms/frame on the box).
  - **ColecoVision & MSX1** (`coleco` `.col`, `msx` `.rom`/`.mx1`, `col.c`,
    `msx.c`): Z80 + TMS9928A/9918A, SN76489 / AY-3-8910 + Konami SCC sound,
    MegaCart, Super Game Module, Konami/ASCII MegaROM mappers (2.5-4.8 ms/frame).
  - **WonderSwan & WonderSwan Color** (`ws`, `.ws`/`.wsc`, `ws.c`): NEC V30MZ,
    224 x 144 horizontal and auto-rotated 144 x 224 vertical LCD at 75.47 Hz,
    4-channel wavetable/HyperVoice/DMA sound, SRAM & EEPROM `.sav` (1.7-10.2 ms/frame).
  - **Super Nintendo / Super Famicom** (`snes`, `.sfc`/`.smc`, `snes.c`): WDC
    65C816 (LoROM/HiROM/ExHiROM, GPDMA/HDMA), S-PPU Modes 0-7, SPC700 + 8-voice
    S-DSP BRR sound, SRAM `.sav` (6.4-16.5 ms/frame).
  - **Neo Geo AES / MVS** (`neogeo`, `.neo`, `neo.c`): 68000 + Z80, LSPC2
    hardware-zoomed sprite strips + fix layer (320 x 224), YM2610 FM/SSG/ADPCM-A/B,
    64 KB `.sav` (2.5-14.3 ms/frame).
  - **Game Boy Advance** (`gba`, `.gba`, `gba.c`): ARM7TDMI (ARM + Thumb,
    12/12 `gba-tests`, 17/17 PeterLemon), PPU Modes 0-5, DirectSound FIFO + PSG,
    SRAM / Flash 64K & 128K / EEPROM `.sav` (5.2-17.1 ms/frame).
  - **Atari 7800 & Atari Lynx** (`a78` `.a78`, `lynx` `.lnx`/`.lyx`, `a78.c`,
    `lnx.c`): 6502C + MARIA DLL/DL + TIA/POKEY (`a78`), and 65SC02 + Suzy
    hardware sprite scaling/math + Mikey timers/sound (`lynx`) (4.3-8.2 ms/frame).
  - **Vectrex** (`vectrex`, `.vec` or no file for built-in *Vector Storm* /
    *Mine Storm*, `vec.c`): MC6809 + 6522 VIA + DAC integrator + 540 x 720
    anti-aliased phosphor vector buffer + AY-3-8912 sound (6.2-15.7 ms/frame).
  - **Famicom Disk System** (`fds`, `.fds`, `nes.c`): 1-8 disk sides, cycle-exact
    IRQ timer (21/21 `fdsirqtests`), RP2C33 wavetable + FM modulation sound,
    disk writes persisted in `.sav` (4.6-11.3 ms/frame).
  - **Neo Geo Pocket Color, Odyssey2 & Intellivision** (`ngp` `.ngp`/`.ngc`,
    `odyssey2` `.o2`, `intv` `.int`/`.rom`; `ngp.c`, `o2.c`, `intv.c`): TLCS-900/H
    + Z80 + K1GE/K2GE + T6W28/DAC + 64 KB Flash `.sav` (8.8-11.2 ms/frame);
    8048 + 8244 VDC (2.5 ms/frame); CP1610 + STIC + AY-3-8914 (4.4 ms/frame).
  - **Sony PlayStation 1** (`psx`, `.exe`/`.cue`/`.iso`, `psx.c`): MIPS R3000A +
    COP2 GTE 3D geometry, PS1 GPU (1024 x 512 BGR555 VRAM, shaded/textured
    polygons, 15/24bpp), DMA0..6, MDEC, 24-voice SPU XA-ADPCM, 128 KB Memory Card
    (`.sav`), streaming `.cue`/`.bin` & `.iso` CD-ROM reader, and `"PS-X EXE"` vs
    DOS `"MZ"` `.exe` disambiguation in `explorer` (1.4-14.7 ms/frame on 3D/2D
    homebrew & tests on the box).
  - **Capcom CPS-1, CPS-1.5 & CPS-2 Arcade** (`cps`, `.cps`/`.cps1`/`.cps2` and
    MAME `.zip` romsets, `cps.c`, `tools/cps_pack.py`): 10/12/16 MHz 68000 (`m68k.inc`
    with separate decrypted `fmap` vs data `rmap`) + 4/8 MHz Z80 (`z80.c` with
    Kabuki M1/data decryption), CPS-2 dual 4-round Feistel opcode decryption
    (20-byte `.key` + built-in key table + Phoenix XOR), CPS-A & CPS-B custom chips
    (16x16 hardware multiply, board IDs, GFX bank mappers), 384 x 224 4,096-color
    3-layer tilemaps (`SCROLL1` 8x8, `SCROLL2` 16x16 with per-scanline rowscroll,
    `SCROLL3` 32x32) + CPS-1 `BgHi` foreground pen masking + CPS-2 Z-buffered
    sprite priorities, YM2151 + OKIM6295 (CPS-1) and 16-voice DL-1425 QSound DSP
    (CPS-1.5 / CPS-2) mixed at 48 kHz, and 93C46 EEPROM (`.sav`).
  - **ZX Spectrum 128K + Pentagon BetaDisk 128** (`zx`, `.sna`/`.z80`/`.tap`/`.tzx`/`.trd`/`.scl`,
    `zx.c`): port `0x7FFD` 128 KB RAM banking (8 x 16 KB banks, Bank 7 shadow screen,
    dual ROMs), 128K `.sna` (131,103 B) & `.z80` v2/v3 snapshots, multi-block 128K
    `.tap`/`.tzx` loader, BetaDisk WD1793 FDC + `0x3D00..0x3DFF` trap for `.trd` &
    `.scl` floppies (with optional `128.rom`/`trdos.rom` or built-in clean-room
    loader), and 48 kHz ULA beeper + AY-3-8912 3-channel PSG audio.
  - **MSX2** (`msx2`, `.mx2`/`.dsk`/`.rom`, `msx.c`): Z80A + Yamaha V9938 (128 KB
    VRAM + 64 KB ExpVRAM, RGB333 palette, `SCREEN 0..8` including 512 px `G5`/`G6`
    and 256-color `SCREEN 8`, Sprite Mode 2 OR-color blending, `R#19` scanline IRQ,
    `R#23` vertical scroll, and full hardware blitter `HMMC`/`YMMM`/`HMMM`/`HMMV`/
    `LMMC`/`LMCM`/`LMMM`/`LMMV`/`LINE`/`SRCH`/`PSET`), 256 KB Memory Mapper, RP5C01
    RTC, FAT12 `.dsk` floppy support, C-BIOS MSX2 or built-in BIOS, and AY-3-8910 +
    Konami SCC + Yamaha YM2413 MSX-MUSIC FM sound.
  - **Atari 520ST / 1040STFM** (`atarist`, `.st`/`.msa`/`.prg`/`.tos`, `st.c`):
    8.021 MHz 68000 (`m68k.inc` with Bus Error `/BERR` & vectored MFP IPL 6 IRQs),
    2 MB ST-RAM, Atari Shifter (320x200 16c, 640x200 4c, 640x400 mono, per-scanline
    raster palettes) + STE Blitter (`$FF8A00`), MC68901 MFP Timers A/B/C/D, dual
    MC6850 ACIA + HD6301 IKBD, WD1772 FDC + DMA (`.st`, RLE `.msa`, and auto-boot
    FAT12 wrapper for bare `.prg`/`.tos` with `$601A` vs C64 `.prg` disambiguation
    in `explorer`), YM2149F 48 kHz PSG, and free GPLv2 EmuTOS (`etos192uk.img` /
    `etos256uk.img`) or built-in clean-room TOS.
  - **Sega System 16A, 16B & OutRun-Road Arcade** (`sys16`, `.s16` and MAME `.zip`,
    `s16.c`, `tools/s16_pack.py`): 10/12.5 MHz 68000 + Z80 (FD1089/FD1094 `fmap` &
    MC-8123 `op` support), Sega `315-5195` 8-region mapper, `315-5197` 3-layer
    tilemaps (Text + FG + BG with rowscroll & colscroll) + 16-bit zoomed sprites
    with Shadow/Highlight pens + dual-stripe perspective road generator (`S16R`),
    YM2151 FM + NEC uPD7759 ADPCM + Sega 16-channel PCM sound at 48 kHz, and 16 KB
    NVRAM (`.sav`).
  - **Atari 800XL / 130XE & Atari 5200 SuperSystem** (`atari8` `.atr`/`.xex`/`.obx`/`.com`/`.car`/`.rom`
    or bare BASIC, and `a5200` `.a52`/`.car`/`.bin`, `a8.c`, `a8_roms.inc`): 1.77/1.79 MHz SALLY
    6502C (with BCD & undocumented opcodes), ANTIC Display List co-processor (modes `2..F`,
    `LMS`, `HSCROL`, `VSCROL`, `DLI` + cycle-split `WSYNC`), GTIA (336 x 240, 256-color
    NTSC & PAL palettes, 4 Players + 4 Missiles, hardware collisions, `PRIOR` + modes 9/10/11),
    POKEY 4-channel 48 kHz polynomial/pure-tone/16-bit/digisound + timers + pots + high-speed
    `SIOV` & serial SIO (`.atr` `.sav` writeback, multi-segment `$FFFF` `.xex` `INITAD`/`RUNAD`
    loader, and `$FFFF` `.com` vs MS-DOS `.com` disambiguation in `explorer`), 130XE 128 KB
    `PORTB` CPU/ANTIC bank switching, XL/XE & 5200 cartridge mappers up to 1 MB, and built-in
    royalty-free AltirraOS XL/XE, Altirra BASIC & Altirra 5200 OS ROMs.
- **USB keyboard**: a keyboard (an interface of class HID, protocol
  keyboard) types into the same command line as the UART -- US layout,
  Enter, Backspace, the arrows, Home / End, Delete, Tab, Caps Lock, Escape (as Ctrl-C), Ctrl
  with a letter; a held key repeats after 500 ms -- and the line being typed
  shows on the TV too, in the command line box. Its reports are read from
  its interrupt endpoint, as a PC reads a keyboard: an IN transfer that
  stays pending on the controller's endpoint B and is asked again every
  millisecond until a key goes down or up. `usb kbd report` reads them with
  GET_REPORT over endpoint 0 every 16 ms instead and `usb kbd interrupt`
  switches back (the demo changes the way by itself, once, when the one in
  use is stalled three times) -- but not every keyboard answers GET_REPORT
  with its keys; `usb kbd` tells which way is in use. A keyboard that stops
  answering (three reads with no answer at all, not a stall -- a reset
  device, as after a display set-up) is set up again by itself, three
  times at most before a report comes. `ccc` typed on it is just
  text: the restart for the UART updater listens to the UART. `usb kbd raw
  on` prints every report that differs from the last. Known limits: the
  reports are taken only between commands, so a key pressed and released
  while a long command runs (`md` of 4 KB, `video init`) can arrive late or
  be lost; an unplug and replug within 100 ms is not noticed (`usb`
  enumerates again); and the keyboard's LEDs are not driven. See the USB
  section below.
- **USB mouse**: a mouse (HID, boot protocol mouse) moves a pointer -- a
  black and white arrow -- over the TV picture, starting in the middle;
  on the test screen, with the left button held, it paints a line (a 5-pixel brush; on the console the
  pointer only moves), the right
  button picks the next colour (yellow, red, green, blue, white, orange),
  and the buttons and the wheel are told on the UART with the pointer's
  place (`[usb] mouse: left down at 700,390`). Its interrupt endpoint is
  polled by the controller's endpoint D on its own, every 8 ms for the
  usual 10 ms mouse, so the keyboard keeps endpoint B and a disk's
  transfers disturb neither. `usb mouse` gives the pointer's place, the
  buttons, the wheel and the counts. Limits: one mouse (a second is listed
  and left alone); reports that come while a command runs wait in endpoint
  D's FIFO and their movement arrives in one step afterwards. When the
  keyboard has endpoint D the mouse is read through endpoint B, one IN at
  a time started no sooner than its interval (8 ms for the usual 10 ms):
  endpoint B asks again every millisecond while the device NAKs, and
  started again at once after each report it read a PixArt mouse 954
  times a second -- movements of a count or two that the pointer's
  acceleration never saw (a slow pointer) and 73 failed split
  transactions in 1929 reports; at the interval, 107 reports a second and
  no errors. A failed IN is tried again at once; only the third in a row
  pauses 200 ms. `usb mouse` also gives the gaps between reports, and
  `loop` how long the main loop's parts took.
- **`video init [opticum|comsat] [rev0|rev1]`**: the bootloader never
  touches the display, so on the box the TV stays dark until something
  programs it -- the demo runs its board's set-up by itself as it starts,
  before USB (the set-up's reset and clock stores knock a USB device out:
  on the box a keyboard answered nothing afterwards until a bus reset; the
  originals too start their USB only after their display), and `video
  init` sets a connected USB device up again afterwards. This replays the register stores with which a board's own
  original application brings up its 720p picture -- display engine, TV
  encoder (0xB8008000), VCAP, the HDMI transmitter (0xB802A000) and its
  PHY setting 0xB8000400, clock and reset bits, with the pauses of 2 ms or
  more between them (about 1.8 s in all) -- then drives GPIO 17 low (both
  originals do) and puts the demo's layer back. There are four tables,
  recorded in the emulator by `gen_video_init.py`: per board, `opticum`
  from dump_maciej.bin and `comsat` from dump.bin (without a name the
  board's own: the TM1650's answer tells them apart), and per chip
  revision, which both firmwares branch on -- the TV encoder's set-up and
  the moment the output is switched on differ (without `rev0` / `rev1` the
  chip's own). The boards' tables differ in the TV encoder's output set-up
  (0xB800808C; on revision 1 also 0xB800809B) and in the addresses of the
  display buffers (0xB80061E4, 0xB8006234, VCAP's 0xB800F010 / 0xB800F01C),
  which the demo keeps its own picture clear of (it is at 0x02000000). Each recording
  starts from the register values a real S3811 has after a reset
  (`s3811_rev1_reset_values.json`, read on the box below): the emulator's
  device registers start at 0 and the drivers change single bits of them.
  The HDMI driver (the SDK's libHDMI: `hdmi_ctrl_task`) keeps the
  transmitter in soft reset, bit 0 of 0xB802A007, until it sees a TV --
  hot plug and receiver sense, bits 0 and 1 of 0xB802A008 -- so the
  recording shows the firmware one. Then both set the PHY up, send their
  AVI / audio / MPEG / SPD infoframes, change a clock (bit 16 of
  0xB8000078), release the reset (0xB802A007 = 0x7C) and unmute three times
  (bit 3 of 0xB802A009); the tables end 1.5 s later, past the output's
  switch-on on both revisions. The TV's EDID makes no difference to what
  the drivers write (they keep their 720p 50 Hz). On the real box below it
  gives the TV its picture.
- **Watchdog**: the demo runs the chip's watchdog from its start, as both
  original applications run theirs (the SDK's `dog_m3327e` at 0xB8018500: a
  32-bit counter at +0 counting up at the memory clock / 2^(5+n), the
  control byte at +4 -- n in bits 0..1, bit 2 counting, 0x60 a chip reset at
  the overflow; in the emulator dump.bin and dump_maciej.bin write 0xFDC3CB9F,
  then 0x64, and the counter again about three times a second -- 8 s if it
  counted at 150 MHz / 32). The demo
  measures the counter's rate against CP0 Count over 20 ms (control 0x04:
  counting, no reset), starts it 8 s before the overflow with 0x64 and feeds
  it every 0.1 s from its time reads -- the main loop's, every delay's and
  every wait's. A demo that stops -- a bus access that never ends, as one with
  the USB PHY held in reset did on the box, or a loop that reads no time --
  restarts the box within 8 s through the original bootloader, where the
  updater can catch it without a power cycle. `watchdog` reports it, `watchdog
  test` stops feeding it on purpose, `watchdog off` / `on`. On the real box
  (revision 1) the counter measured 844,100 ticks/s with n = 0 -- 27 MHz /
  32, the crystal's clock, not the memory clock the SDK's driver computes
  with -- and `watchdog test` restarted the box 8.5 s after the demo stopped
  feeding it, straight back into the demo.
- **Updates keep working**: three `c` on an empty line (what
  `maciej_uart.py --capture-boot` sends) restart the box through the
  original bootloader, which the updater then captures, as with v3;
  `reboot` (or `restart`) restarts it into the demo. `bootloader` restarts
  it too and says how to stay in the original bootloader's shell: hold the
  c key (or start the updater). The bootloader keeps its shell only when
  'c' arrives while it starts (it has no other way in: the SDK's
  0xdead2bee "boot code" path is not reachable in this build); a held key
  works either way, because the demo restarts again on `ccc`. Every restart
  (`start.S`'s `platform_restart`, also in the small apps) first resets the
  chip through the watchdog, as the M3801 loaders' own `reboot` does
  (0xB8018500 = 0xFFFFF000, then 0x67 at +4: the SDK's `dog_m3327e`), so the
  bootloader starts as at power-on; only when no reset comes within about
  0.3 s -- in the emulator, which has no chip reset (`src/watchdog.py`, opt-in,
  counts and records the overflows only) -- does it stop the watchdog, switch
  the OSD layer off and jump into the loader's warm restart (`$s8` =
  0xdeadbead) as before.

Build and release (the release script makes the four files above and its
ZIP byte-for-byte reproducible):

```powershell
python firmware/maciej_app/build.py --version v4 --demo
python tools/maciej_release.py --version v4 --app build/maciej_app/v4/app.bin --readme firmware/maciej_app/bin/README_UART_v4.txt
```

`tests/run_dump_maciej_demo_v4.py` (default suite, about eight minutes with
the C++ engine) checks the
shipped files and, with a MIPS GCC, that the source rebuilds to the shipped
bytes; then it boots the shipped image through the original bootloader and
drives it only through its inputs: 233 checks over the commands (every one
listed by `help`; all but `uptime`, `ir raw` and `panel bright`
run), the line
editing, the console on the TV (read back cell by cell against the
demo's font: what the UART shows, the colours, its head beside the test
screen's, `clear`, PgUp / PgDn, `testscreen` / `console`, a USB keyboard's
key bringing it back and typing), the test screen pixel by pixel (banner, header colour, the eight colour
bars, clear / rect / text / off / demo, the ARGB1555 words in RAM), the
layer's head block (the head, the filter table zero, the BT.709 matrix at
+0x240) and enable registers, the panel's digits and both keys,
four buttons of the box's remote and an unknown remote, the emulator's
virtual remote by key name, USB plug-in / enumeration (descriptors,
strings, configuration, the exact SETUP packets) / speed / bus reset /
plug-out and the controller's set-up (the PHY as the box's firmware writes
it), `lsusb`, a USB keyboard (as the real one tried on a box: low speed,
two interfaces, GET_REPORT always empty; enumerated in 8-byte packets, the
boot protocol, the controller's endpoint D set polling its interrupt
endpoint as the SDK sets it up, both toggles DATA0 first, one IN token
every 8 ms while no key changes and none from endpoints B and C,
typing with Shift, punctuation, Backspace, Up, Caps Lock, Escape, a held key
repeating, `ccc` only text, the line on the TV; a control request while
endpoint D polls; nothing typed with `usb kbd report` on that keyboard, typing
again after `usb kbd interrupt`; enumerated again with no report lost to the
data toggle; unplugged without an error line; a full-speed keyboard, also
with GET_REPORT; keyboards that stall GET_REPORT, the interrupt endpoint, or
both), a USB hub (the tree tried on a real box: a high-speed hub with a
second hub, a stick and the low-speed keyboard behind it -- all enumerated,
the ports powered and reset one after the other, the keyboard addressed
and read (endpoint D's tokens) through the translator with the split registers, `lsusb`, the TV's
USB box, `usb ctl` to a device behind the hub; a second keyboard plugged
in, the first unplugged and the second taking over; the keyboard moved
behind the second hub; that hub unplugged with what is behind it; a
full-speed hub with a full-speed and a low-speed keyboard), USB disks (a
hub with a FAT32 stick -- one file in clusters that are not one after the
other -- a card reader's FAT16 card that first answers "the medium may
have changed", a full-speed FAT12 stick without a partition table, and the
keyboard: each found as it is set up, `disks`, `ls` in any case, `cat` of
text, of the scattered file and of a binary one, `sector`, the errors, the
keyboard typing between the disks' commands with no packet dropped and no
command broken; a card reader without a card; a stick that leaves the
first command after idling unanswered, sent again after 2 s; a stick pulled
out), a USB
mouse (as on the real box: low speed behind the second hub, the keyboard on
the first, a stick -- the keyboard has endpoint D, so the mouse's endpoint
is read through endpoint B's IN, through its hub's translator; the pointer
drawn and moved, a click, a
painted line in the framebuffer and on the captured screen, the right
button's colour, the wheel, `usb mouse`; the keyboard typing and `ls` /
`cat` on the stick while the mouse moves, nothing dropped; unplugged --
endpoint B's IN ended, endpoint D polling on -- and
plugged in again), more than seven USB devices (eight behind two hubs, the
mouse as device 8, read through endpoint B, and a third hub as the ninth refused: a hub needs one of
the first seven addresses), a shell on writable sticks (`cd` / `pwd` /
`dir` / `mkdir` / `rmdir` / `rm` / `touch` on FAT16 with a partition table,
FAT32 -- its root grown by a cluster -- and a full-speed FAT12 without one,
the prompt following `cd`; what the demo wrote read back by
`fat_image.Volume`: long names and their checksums, `.` and `..`, freed
clusters, both FATs alike, FSInfo's count unknown; the refusals; a
write-protected stick left alone; files' contents: `echo ... >` and `>>`,
`help > help.txt` over two clusters, `>>` onto a full cluster and into a
sector's middle, `>` over a longer file, `cp` to a new name, into a
directory and onto the FAT32 stick, onto itself refused, `mv` of a file
and of a directory -- its `..`, the prompt following a moved current
directory -- `ls > 4:/list.txt` onto FAT12, quotes; every volume then
checked whole: no lost cluster, every chain as long as its file, `.` and
`..` right), USB serial ports (an LTE module behind a hub, as the A7670E
shows itself -- `usb_host.VirtualModem` -- next to a writable stick: its
four ports in the descriptors' order with DTR and RTS on, `tty`, `at` with
the answers read a packet at a time through endpoint B's FIFO, the PIN,
`AT...` typed as a line, `> file`, AT+CMGS's `> ` and its text through
`cu`, `cu 2` ended by Ctrl-] with LF sent as CR, a web page through the
module's HTTP client -- its result shown by the next `at`, the page after
AT+HTTPREAD's OK --, `at` and `cu` through IN tokens spoilt on the bus
(UTMI errors), the module losing its configuration and its hub port alone
set up again by `at` (the stick next to it untouched), unplugged), the
watchdog (running in reset mode from the start, fed every
0.1 s, never overflowing through all of it; the model in `src/watchdog.py`),
`video init` (the Opticum's table: 720p timing, the HDMI
transmitter out of reset and unmuted, the board's own TV encoder values),
`reboot` / `/restart` (arming the watchdog first), `bootloader` with a held c key, the updater's
capture and handshake from the running demo, and that the flash never
changes. `tests/run_dump_maciej_demo_v4_comsat.py` (default suite, about
two minutes) runs the same image on the Comsat's board -- two buttons on GPIO 31
/ 9 (`gpio_keys.GpioKeys`), no TM1650 -- and, as the real box, on a
revision-1 chip, in 62 checks: button mode, both pins inputs after the
probe and never driven again, the buttons' events (a single low read is
not a press), `keys`, the front panel box, `info`, `panel` refused, the
layer enabled as the originals do on revision 1 with their matrix in its
head; what the real box showed -- the matrix zeroed by `mw`, every colour
black; bit 19 set, the dark background green -- and the colours back with
the matrix written again; `video init` picking the Comsat's revision-1
table and starting the HDMI transmitter, `video init opticum`, `video init
comsat rev0`; a low-speed USB keyboard typing (read from its interrupt
endpoint), with the controller's PHY set up with the revision-1 values, set
up again by itself when it stops answering (reset behind the demo's back)
and after `video init`; a restart that comes back the same way, the
keyboard, still plugged in, found before the first prompt; and `watchdog
test` stopping the feeding (the counter running on to its overflow).

### On a real box

The first v4 build was flashed on a Comsat TE 1050 HD on 2026-11-12 --
dump.bin's board, which has carried the Opticum's flash image since v3 --
by the transfer and burn of the main code chunk alone (41 s, no backup).
The original bootloader starts it and the command line works. USB works:
a CH341 adapter (1a86:5512 "USB UART-LPT", USB 1.10, full speed, vendor
class, three endpoints) plugged in was noticed, enumerated and configured,
and `lsusb` listed it. `keys` found no TM1650 (the board has none) and
`video init` ran to the end (720p timing set, the demo kept running) but
the TV stayed dark: that build's table left the HDMI transmitter in reset.
Then `ccc` (the updater's capture) printed its restart message and the box
went silent: the jump into the loader's warm restart, which v3 always
survived, hung with the display engine and VCAP running after `video init`
(and the USB controller set up) -- most likely the loader reinitializing
the DRAM under their transfers; the emulator models no bus, so it never
showed. The second build changed all three (button mode; the HDMI start in
the table; the restart through the watchdog). It went onto the box the same
way, except that the old build had to be caught at power-on (paced 'c'
while the box was switched on: its own restart hangs). It found no TM1650
there, both front buttons reported their presses and releases, each once
(UP on GPIO 31, DOWN on GPIO 9), and `restart` after `video init` came
back through the watchdog reset. But the TV still stayed dark after `video
init`, although the transmitter saw it (0xB802A008 read hot plug and
receiver sense) and the TV worked with a PC on the same cable. Writing
0x300 to 0xB8000400 by hand -- both applications do at their HDMI init,
outside that build's recorded ranges (the tables include it now), and it
read 0 -- before `video init`, and GPIO 17 low (both pull it low next to
their HDMI start; `video init` now does too) did not change that either.

It was not the box, the cable or the TV: the Opticum's original main code,
flashed back for a comparison, showed its language wizard over HDMI. (This
TV, with no signal, goes dark and says it enters power saving -- "black"
meant no signal at all, not black pixels.) Its console's REBOOT resets the
display engine, the TV encoder and the transmitter too, so its working
set-up could not simply be handed over to the demo. Two differences
between the emulator and the chip were behind the missing signal:

- **The chip's revision.** The box reads 0x38110001 at 0xB8000000 --
  revision 1 -- where the emulator answered 0x38110000, and both firmwares
  branch on it (`sys_ic_get_rev_id`): the TV encoder's set-up, the GMA
  layer's enable bits and, on the Comsat, when the output is switched on.
  `gen_video_init.py` now records each board at both revisions, and the
  demo replays the table of its chip's.
- **The reset values.** The emulator's device registers start at 0, the
  chip's do not -- the transmitter's PHY bytes +0x0A..+0x0F come up as 02
  92 24 49 82 21, the display engine with a PAL timing, the TV encoder with
  dozens of values, 0xB800006C / 0xB80000B0 as 0x80000000 / 0x00030100 --
  and the drivers change single bits of them, so a recording made from
  zeros wrote values the chip never gets from its own firmware. They were
  read on the box after a watchdog reset with the demo's `md`
  (`s3811_rev1_reset_values.json`), and the recordings start from them.

With both, `video init` gave the TV a signal, and a black picture. The
display engine's background colour (0xB8006188, YCbCr) set to red changed
nothing at first: the demo's opaque, black layer covered it. With the layer
switched to CLUT8 (the picture's own data as its palette) and its head
pointer 0xB8006304 written again, the whole screen turned red, and with the
layer off a green background (0x00913622) showed: the output reached the
TV. The layer itself showed its alpha -- a transparent palette entry let
the background through, an opaque one covered it in black -- but never a
colour, ARGB1555 and CLUT8 alike.

To watch the TV from the PC, a phone on USB pointed its camera at it: `adb
shell am start -a android.media.action.STILL_IMAGE_CAMERA`, then `adb
exec-out screencap -p` and the average colour of the middle of the view;
small scripts sent console commands (`mw`, `screen clear ...`) one by one
and looked after each. Setting the bits of the layer's enable register
0xB8006300 one at a time found bit 19: with it the colours came, but dark
ones green. The layer then takes a pixel's red, green and blue fields as
Cr, Y and Cb -- all zero, the demo's black, is green in YCbCr -- and
colours written that way (black as Cr 16 / Y 2 / Cb 16) were right.

The original applications' GMA driver (the same code in both, newer than
the SDK's) had the rest. On revision 1 a region head is a 0x280-byte block
whose +0x240 holds the matrix the layer's RGB is converted to YCbCr with,
copied into every head by `gma_m36f_sync_block_header`: BT.709's for an HD
output (x512, the rows Y, Cb, Cr of R, G, B and an offset: 93 314 32 0 /
-52 -173 225 0 / 225 -204 -21 0, then 45), BT.601's for SD. Their
`gma_m36f_open` also sets bit 18 of the enable register and clears bit 19
(set, the bit skips the matrix), and `gma_m36f_create_region` writes
0xB80063B8 = 1 for a true-colour region. The demo's 40-byte head left the
matrix zero: every colour black. Written into its head with `mw` (bit 19
clear), the originals' matrix ended the black: the picture came through it
-- the build then running still stored its colours as YCbCr words, so its
black showed purple, that word read as RGB. Bit 18 and 0xB80063B8 made no
visible difference. The final build does what the
originals do -- the 0x280-byte head with the matrix, 0x00040001,
0xB80063B8 = 1 -- and the demo's picture is on the TV in its colours: the
demo screen, the colour bars, black, greys, white and red, checked through
the camera.
`info` reads 0xB8006300 as 0 when the demo starts after a reset, so the
chip does not set bit 19 itself. The emulator now shows what the box
showed (`gma_capture.py`, `chips/m3801.py`): a revision-1 head's colours go
through its matrix -- all zero, black -- and bit 19 makes them YCbCr;
`run_dump_maciej_demo_v4_comsat.py` zeroes the matrix and sets the bit.

## USB

The S3811 has an ALi USB 2.0 host controller (the SDK's `hc_s3602` /
`hcd_s3602` driver, `refs/MainCode/ddk/libcore_hd.a` and, newer,
`libcore_v40b.a`). The original application attaches it at **0xB8032000**
(found by breaking on the driver's register accessors) on
interrupt-controller line **29** (the SDK's OS IRQ 0x25), after a reset
pulse on bit 28 of 0xB8000080. The accessors, the interrupt handlers and the
box's own firmware's driver (dump.bin and dump_maciej.bin, traced in the
emulator at both chip revisions) give the register map:

| Register | Meaning |
| --- | --- |
| +0x10 | port: bit 0 over-current, bit 1 device connected, bit 2 (revision 0: cleared and set after the PHY set-up and before a bus reset), bit 5 drive a bus reset (written as 0x20; the controller ends it), bit 6 suspend, bit 7 resume |
| +0x11 | endpoint 0: bits 0..1 token PID (0 SETUP, 1 OUT, 2 IN), bit 4 FIFO reset, bit 5 send the token; read: bit 7 FIFO empty |
| +0x12 | endpoint 0's FIFO port |
| +0x13 / +0x16 / +0x19 / +0x22 | endpoints A / B / C / D: bits 6..7 the transfer type (0x80 bulk, 0xC0 interrupt), bits 2..5 the device's endpoint |
| +0x14 / +0x17 / +0x1A / +0x23 | their FIFOs: bit 4 reset (endpoint B's also ends a pending IN), bit 0 pulsed: the data toggle back to DATA0 (`set_ep_data_toggle`; measured for B and D); read: bit 7 empty, bit 6 full. +0x1B / +0x24: endpoint C's / D's FIFO port |
| +0x1C | device address (before the new mode) |
| +0x1D | why the last token failed: 0x80 stall, 0x40 PID error, 0x20 no response, 0x10 unexpected, 0x08 data toggle, 0x04 UTMI, 0x02 CRC (`hcd_s3602_upt_parse_error`) |
| +0x1E / +0x1F | interrupt enables |
| +0x20 | interrupt flags 1 (read to clear): bit 0 connection changed, bit 1 bus reset done, bit 5 a token got no answer (seen with endpoint B's) |
| +0x21 | interrupt flags 2 (read to clear): bits 7 / 3 endpoint 0's token done / failed, 6 / 2 endpoint A, 5 / 1 B, 4 / 0 C |
| +0x2B | bit 5: endpoint C polls its endpoint every +0xA2 ms; bit 3: endpoint D every 2^(+0xA3 - 1) microframes (`en_int_interval_ctrl`) |
| +0x2C | 16 bits: the size of endpoint B's last packet |
| +0x2E / +0x2F | interrupt enable 3 (0x77: `en_host_int_flag3_all`) / interrupt flags 3 (read to clear): bit 4 endpoint D's packet came, bit 0 its token failed (`hcd_s3602_h2c_int`: `epD_finish_ok`, `ep_err_finish`) |
| +0x30 | packet sizes, 8 << n: endpoint A's in bits 0..2 (set with bit 3), endpoint B's in bits 4..6 (with bit 7) |
| +0x31 | packet sizes, 8 << n: endpoint C's in bits 0..2, endpoint D's in bits 4..6 |
| +0x32 | bits 5..6 the device's speed: 0x00 high, 0x20 full, 0x40 low (`hcd_ioctrl_get_speed_ex`; its high / full / low values are the hub code's, from the port status); bit 2 the controller sends the IN tokens of a DMA receive (`dma_host_in_token`), bit 3 the DMA transfer runs (`en_dma_transfer`) -- the controller clears both when the transfer ends |
| +0x34 / +0x3E | host mode (\|= 0x90), `en_epa_auto_force` (\|= 0x08) |
| +0x38 | 24 bits: the bytes a DMA receive takes (`set_dma_rx_cnt`) |
| +0x3D | revision 0: \|= 0x60 before every bus reset |
| +0x40 / +0x44 / +0x48 | DMA receive: the buffer's physical address (32-byte aligned), its index, the bytes received (24 bits; final only once +0x63 bit 2 is set -- read at endpoint B's done flag it can still be one short) |
| +0x50 / +0x54 / +0x58 / +0x5C | DMA transmit: the buffer's physical address (32-byte aligned), its index (0x20 after a 31-byte block), the bytes to send (24 bits), the bytes left; a transfer of several packets raises flags 2 bit 6 and +0x63 bits 0 and 3 after each packet, +0x63 bit 1 (the DMA transmit done) only after the last (measured) |
| +0x60 | DMA strobes (they read back 0): bit 5 / 4 the receiver's state set up / its transfer started, bit 1 / 0 the transmitter's, bits 7 / 6 the bulk-only command list's |
| +0x62 / +0x63 | interface interrupt mask / status (read to clear): bits 0 and 3 -- flags 1 / 2 are pending; 0 and 2 -- a DMA receive is done; 0 and 1 -- a DMA transmit is done (both measured); 0 and 4 a bulk-only command (the SDK's handler) |
| +0x68 | DMA options: 0x80 \| size code << 4 receive (`enable_dma_auto_rx`), 0x08 \| size code transmit |
| +0x80 / +0x82 / +0x84 / +0x86 / +0x88 | endpoint 0's / A's / B's / C's / D's device address << 1, once +0x8F = 0x80 (the per-endpoint addresses both firmwares switch on); bit 0: the device is reached through a high-speed hub's transaction translator (split transfers) |
| +0x81 / +0x83 / +0x85 / +0x87 / +0x89 | that translator, per endpoint (`set_ssplit_ctrl_info`): bits 0..2 the hub's address, bits 3..5 its port, bit 6 the device is low speed (the SDK never sets it; measured: a low-speed keyboard or mouse behind a hub answers with it). +0x89 bit 7 reads 1 while endpoint D's split transaction is under way (about 1 ms) |
| +0x90 | `set_plug_status`: the SDK writes 3 before a bulk transfer to a high-speed device and 1 to a full-speed one (2 and 1 before the first requests to a device behind a hub), dump.bin's driver 0 for a full-speed stick. Measured: with 2 or 3 the controller does not split, so a low-speed device behind a hub gets no answer; the demo leaves it at 0 |
| +0xA2 / +0xA3 | endpoint C's polling interval (the endpoint's bInterval) / endpoint D's: a token every 2^(n - 1) microframes (7: 8 ms, measured), 0 stops it |
| +0xA8 | NAK retry: 1 (the SDK's value) -- an IN the device answered with NAK goes out again in the next frame, 1 ms later; 2..15 that many times a frame; 0 at once; 0x10 and above never again (measured with endpoint B) |
| +0xF2, +0xF0 / +0xF4 | the PHY: its reset (7, 2 ms, 0; byte writes), then its 32-bit settings -- revision 0 read-modify-writes to 0x60007500 / 0x10000000, revision 1 0x6800355C / 0x09000FF0 (the box reads 0x0800F514 / 0x10000FF0 before) |

A register access while the PHY is held in reset hangs the box: a hand-made
pulse (`mw` putting 7 into +0xF2 with a 32-bit store) left it silent until it
was switched off, so `usb reg` refuses the PHY's registers and only `usb
init` touches them, the way the firmware does.

`src/usb_host.py` models the port, endpoint 0's control transfers,
endpoint B's IN with DMA -- one packet into RAM, the token again every
millisecond while the device answers NAK, the data toggle, "no response",
the FIFO reset that ends it: all as measured on the box, below --
endpoint C's interrupt polling (which, as on the box, sends a low-speed
device nothing) and endpoint D's (which does: a token every 2^(+0xA3 - 1)
microframes, the packet into its FIFO, flags 3 bit 4, its own data toggle),
with two built-in devices: a USB 2.0
mass-storage stick (pid.codes test IDs 1209:0001, "AliSimulator" / "Virtual
USB stick", one interface: class 08 / SCSI / bulk-only, bulk endpoints 0x81
and 0x02) and a keyboard (`VirtualKeyboard`, 1209:0002, endpoint
0 of 8 bytes, a HID boot keyboard with its interrupt endpoint 0x81:
SET_PROTOCOL / SET_IDLE / GET_REPORT, `.type(text)` presses the keys in
emulated time; `get_report="empty"` makes GET_REPORT always answer eight
zero bytes and `composite=True` adds a second HID interface, as the real
keyboard below has; `get_report=False` / `interrupt=False` make it stall
GET_REPORT / its interrupt endpoint). A third is a mouse (`VirtualMouse`,
1209:0004, low speed, a boot mouse with the A4Tech's report descriptor:
`.move(dx, dy, over)`, `.press` / `.release` / `.click`, `.wheel(n)` in
emulated time; a report only when something changed). A fourth is a hub
(`VirtualHub`, 1209:0003: the hub descriptor, a port's power / reset /
enable and change bits, GET_STATUS, its status-change endpoint;
`.plug(port, device, speed)` / `.unplug(port)`, hubs behind hubs too): a
device behind it answers only while its port is powered and enabled, a
device that is not high speed behind a high-speed hub only to a token with
the split flag and that hub's address, port and speed bit in the split
register -- and a silent port behind a translator comes back as a stall,
not as "no response", as on the box. Given a disk image the stick
(`VirtualStick(image)`; `src/fat_image.py` builds FAT12 / FAT16 / FAT32
images with long names, a label, an MBR or none, and files in scattered
clusters) answers the bulk-only transport -- endpoint A's OUT by DMA from
RAM a packet at a time with the flags the box raises after each, its
command block, the data and the status on endpoint B -- with the
SCSI commands a host reads a disk with; `full_speed=True` gives it 64-byte
packets, `unit_attention=True` a first "the medium may have changed",
`no_medium=True` makes it a card reader without a card,
`lose_after_idle=s` leaves the first command after s idle seconds
unanswered (as the 64 GB stick below), `writable=True` takes WRITE(10)'s
data into the image -- until all of it has come every packet is more of
it, a command block too, as on a real device (else it is write-protected: MODE SENSE says so,
WRITE fails with DATA PROTECT); `fat_image.Volume` reads an image back
(what the demo wrote is checked with it); like the real
stick below it ends a command whose bulk IN's halt is cleared after the
command block (the status stalls). Both endpoints keep their data toggles
per device endpoint, the controller's per endpoint A and B, and a packet
sent with the other toggle is dropped as on the bus. A token
reaches the device only at the address it carries (+0x80 in the new mode,
+0x1C before), and SET_ADDRESS takes effect after its status stage, as on a
real bus. It is opt-in: `sim.attach_usb_host()`, then `.attach(speed[,
device])` / `.detach()`.

Checked against the original firmware (`tests/run_dump_maciej_usb_attach.py`):
when the stick is plugged in, the original driver enables its interrupts,
debounces, drives a bus reset and enumerates the stick -- SET_ADDRESS(1),
GET_DESCRIPTOR(device) 8 and 18 bytes, GET_DESCRIPTOR(configuration) 9 and
32 bytes, SET_CONFIGURATION(1) -- then sends the mass-storage class's GET
MAX LUN and sets up its first bulk-only command (a 31-byte CBW through the
DMA engine). So the model's registers mean what the original driver
expects, up to the bulk transfers, which are not modelled.

The v4 demo does the same with its own polled code. It sets the controller
up as the box's firmware does for the chip's revision -- the block's reset
pulse, the PHY's reset and settings, host mode, the endpoints, NAK retry 1
-- and `usb` (and plugging a device in) resets the bus, switches the
per-endpoint addresses on and enumerates the device over endpoint 0 --
VID:PID, USB version, manufacturer / product / serial strings, interfaces
and endpoints -- sets its configuration and shows it on the TV
(`Device 1209:0001 Virtual USB stick` in the emulator). A SETUP goes out as
`hcd_s3602_issue_setup` sends it (the PID set to IN and back to SETUP, the
FIFO reset, the 8 bytes); a failed transfer is tried three times (not after
a stall), the enumeration's first request after three bus resets, and a
failure names the stage and the token error (`GET_DESCRIPTOR (device, 8
bytes), attempt 1 of 3: SETUP stage: no response (token error 0x20)`).
A keyboard among the interfaces is started (`kbd.c`): SET_PROTOCOL(boot),
SET_IDLE(0), endpoint B's data toggle reset (bit 0 of +0x17 pulsed), then
an IN on endpoint B aimed at its interrupt endpoint, set up as the SDK's
bulk IN (`hcd_s3602_bulkin_start`): the device's address at +0x84, the
endpoint at +0x16, the packet size at +0x30, one packet by DMA into RAM
(0x00F00400: +0x40, +0x38 = 8, +0x68 = 0x80, the +0x60 strobes), started
with +0x32 bits 2 and 3. When flags 2 bit 5 comes the report is read from
that RAM and the IN started again; bit 1 (a token nobody answered) counts
towards setting the keyboard up again. `usb kbd report` reads the reports
by GET_REPORT every 16 ms instead.

A disk (`disk.c`: an interface of class 8, subclass 6 -- SCSI -- protocol
0x50, bulk-only, with a bulk IN and a bulk OUT endpoint) is set up after its
configuration: GET MAX LUN, INQUIRY, TEST UNIT READY until it is ready
(REQUEST SENSE after each failure: 2/3A is "no medium", a unit attention
6/28 comes first from a card reader), READ CAPACITY(10), then sector 0: a
FAT, NTFS or exFAT boot sector without a partition table, else the MBR's
four primary entries (a protective 0xEE: the GPT's entries), and each
partition's first sector for its file system. A command is a 31-byte
command block wrapper sent from RAM by endpoint A's DMA (the SDK's
`hcd_s3602_bulkout_start`: +0x82 / +0x83 the device, +0x30 bits 0..2 the
packet size, +0x13 the endpoint, +0x50 / +0x58 the buffer and length, the
+0x60 bit 0 strobe, +0x32 bit 3; done at the DMA transmit's done, +0x63 bit
1, as the SDK's `hcd_s3602_dma_tx_done` -- flags 2 bit 6 comes after every
packet), and WRITE(10)'s data the same way; the data and the 13-byte status
wrapper received by endpoint B's
(several packets in one transfer: a 512-byte sector in eight from a
full-speed stick). A stalled data stage has its halt cleared and the status
read; a status that makes no sense, a command block the device does not
take, or no data or status within 2 s leads to the bulk-only reset recovery
(the class's reset, both halts cleared, 100 ms) and one more try, which may
take 10 s. FAT: the boot sector's geometry, the type
from the cluster count, a cached FAT sector, the root's label entry, long
names put together from their parts (checked against the 8.3 entry's
checksum), Windows' lower-case flags on 8.3 names.

Endpoint B now serves the keyboard's interrupt endpoint and every disk's
bulk IN, endpoint A every disk's bulk OUT, and there is one DMA engine (the
SDK takes a semaphore around it): the keyboard's pending IN is stopped
before a disk transfer and started again afterwards. The controller has one
data toggle per endpoint, a device one per endpoint of its own, so the demo
keeps every device's, counts the packets of each transfer, and before an
endpoint serves another device endpoint puts the controller's back to
DATA0 -- and the device's too, with CLEAR_FEATURE(ENDPOINT_HALT), when it is
DATA1. For a disk both happen before the command block: one in its middle
ends the command on a real stick.

A hub (device or interface class 9) is set up after its configuration: its
hub descriptor (GET_DESCRIPTOR 0x29) for the number of ports, SET_FEATURE
PORT_POWER on each, a wait of its power-on time plus 100 ms, then every
port whose GET_STATUS shows a device: SET_FEATURE PORT_RESET, GET_STATUS
until the reset's change bit comes (the hub ends the reset itself), the
change bits cleared, the speed read from the status (bit 9 low, bit 10
high), and the device enumerated at address 0 exactly like the one on the
box's port, with the next free address. Each device keeps how it is
reached -- its address, and for one that is not high speed behind a
high-speed hub the split flag and the hub's address and port -- and
endpoint 0's registers (+0x80, +0x81) are written from that before every
request; endpoint B's (+0x84, +0x85) before the keyboard's IN. A device
that does not answer has its port switched off again (it would answer at
address 0 together with the next one) and is left alone until it is
plugged in again. Afterwards one port is asked for its status every
100 ms.

On the real box the first v4 build's USB code (the controller set up from
a recording of the revision-0 path, no PHY settings, the old addressing)
enumerated a CH341 USB-serial adapter at full speed, but a keyboard
(1a2c:2d23 "USB Keyboard") never answered its first SETUP: token error
0x20, no response. That build read +0x32 = 0x20 for it -- full speed. With
the PHY reset and the revision-1 settings the box's own firmware writes,
the same keyboard reads 0x40 -- low speed, which it is -- and enumerates:
USB 1.10, endpoint 0 of 8 bytes, a boot keyboard on interface 0 (interrupt
endpoint 0x81) and a second HID interface (0x82). Without the PHY set-up
the controller took the low-speed device for a full-speed one and talked
to it at full speed, which a low-speed device cannot hear; the full-speed
CH341 never showed it. GET_REPORT then answers every 16 ms without errors.

But typing on it showed nothing. Its GET_REPORT answers every request with
an empty report -- 93 answers of eight zeros while a key was held, although
the HID specification makes the request mandatory: this keyboard puts its
keys only on its interrupt endpoint (its report descriptor, read with `usb
ctl 0x81 6 0x2200 0 255`, is a plain boot keyboard without report IDs), where
a PC reads them.

What the controller can do with that endpoint was measured on the box
itself, with small test programs run from its RAM over the demo's own
console: `mw` wrote a loader into free RAM and pointed the `ping` command's
handler at it; the loader took a compiled test as raw bytes and called it,
and a test, linked against the demo's symbols, used its control transfers
and its console and sampled the controller's registers every few
microseconds. What they showed:

- Endpoint C, the SDK's interrupt endpoint, set up as
  `hcd_s3602_IntInC_start` does it (the same code is in dump.bin), sends this
  low-speed keyboard nothing at all: no report in 10 s, and no error either
  when it is aimed at an address or an endpoint nobody has. (The SDK uses it
  for a hub's status endpoint, at full or high speed.)
- An IN on endpoint B -- the SDK's bulk IN with DMA -- does go out: aimed at
  an address or an endpoint nobody has, it reports "no response" (+0x1D =
  0x20) 0.09 ms after its start and fails (flags 2 bit 1) after a second
  token; aimed at one of the keyboard's interrupt endpoints it stays
  pending -- the keyboard answers NAK.
- Receiving works: the data stage of a GET_DESCRIPTOR sent on endpoint 0,
  read through endpoint B (its endpoint number set to 0), arrived packet by
  packet, eight bytes each and a last one of three, each about 0.1 ms after
  its start (flags 2 bit 5, +0x63 = 0x05, the byte count at +0x48, +0x17 =
  0x86, +0x32's two bits cleared).
- The data toggle lasts from one transfer to the next: the packets came in
  order. The first of that data stage (DATA1, against the DATA0 the endpoint
  expected) was acknowledged and dropped (+0x1D bit 3) and the next one
  taken, as the USB rules say. Bit 0 of +0x17 pulsed (`set_ep_data_toggle`)
  puts it back to DATA0: with the pulse before every IN, every second packet
  was dropped.
- A NAKed IN goes out again once per frame: with the address register
  changed to one nobody has, the "no response" came at the next millisecond
  boundary. That is +0xA8 = 1, the SDK's value; 2..15 gave that many tokens
  a frame, 0 one after the other, 0x10 and above none.
- Only the FIFO reset (+0x17 bit 4) ends a pending IN: clearing +0x32's two
  bits, +0x68 or the +0x60 strobe leaves the controller sending tokens.
- Control transfers on endpoint 0 run alongside a pending IN: 150 of 150
  GET_DESCRIPTORs, none slower.
- This keyboard resets itself when nothing asks it anything: with the bus
  left without transfers it dropped off the port about every 62 s and was
  back 35 ms later, at address 0 and unconfigured. With the IN pending on
  its interrupt endpoint it stayed for the four minutes watched. This --
  not data arriving -- is what an earlier build's endpoint C mode ran into:
  nothing was asking the keyboard, it reset itself, and the demo enumerated
  it again.

The demo reads a keyboard that way now, and on 2026-11-13 typing on that
keyboard reached the command line on the box: 43 reports, 23 keys, no
error, no drop-out. When an enumeration gets no answer after three bus
resets, the demo also sets the controller up again, its PHY included, and
tries once more: the box's port was found stuck once after a long time
without transfers (connected, but a SETUP neither done nor failed), and
only `usb init` brought it back. `usb ctl <type> <request> <value> <index>
<length>` sends any control request for such probing.

A hub went onto the same box the same day: a seven-port USB 2.0 hub made
of two Terminus chips (1a40:0101, high speed, one transaction translator
each; the second chip on the first one's port 1), with storage devices on
both chips and the low-speed keyboard on the first one's port 4. Driven
first by hand with `usb ctl` (PORT_POWER, GET_STATUS, PORT_RESET) and then
from RAM-loaded tests, it showed:

- High-speed transfers work on this box (the first high-speed device it
  saw): the hub's descriptors in 64-byte packets, and the high-speed
  devices behind it need nothing but their address.
- The low-speed keyboard behind it answers control transfers once endpoint
  0's split registers are set: +0x80 = address << 1 | 1, +0x81 = 0x61 (low
  speed, port 4, hub 1). With +0x90 = 2 or 3 it gets no answer.
- Endpoint B's IN goes through the translator the same way (+0x84, +0x85):
  aimed at the keyboard's interrupt endpoint it stays pending, aimed at an
  endpoint the keyboard does not have it fails with a stall after 0.24 ms
  -- the translator's answer for three tries nobody answered -- where the
  same without a hub is "no response".
- Endpoint B reads the hub's own status-change endpoint at high speed: the
  byte 0x10 (port 4 changed) 3 microseconds after the start.
- Endpoint C stays silent here too (the hub's status endpoint, an endpoint
  it does not have, the keyboard through the translator).

The demo's hub support then listed the whole tree on the box -- both hub
chips, three storage devices (two behind the second chip), the keyboard at
address 6 -- and the keyboard, read through the translator, stayed
connected for the 13 minutes watched (it resets itself within a minute
when nothing asks it, so the IN tokens reach it) and typed: 14 reports, 8
keys, no error.

The storage devices behind that hub were read next, first by RAM-loaded
tests. The bulk OUT works as the SDK sets it up: a 31-byte command block
goes out 5 microseconds after the start (flags 2 bit 6, +0x63 = 0x03), and
all three devices answered INQUIRY, TEST UNIT READY, READ CAPACITY and
READ(10) at high speed with +0x90 left at 0: a 64 GB stick (090c:2000,
"USB Disk 3.0", one NTFS partition made by Rufus), a 961 MB stick
(ffff:5678, FAT32 'SLITAZ CORE' and a small second partition of type 0xEA)
and a card reader (05e3:0751, "Generic STORAGE DEVICE") with a 942 MB
FAT16 card, whose first TEST UNIT READY failed with a unit attention
(6/28). One status wrapper arrived one byte short: the count at +0x48 was
read at endpoint B's done flag, before the DMA's (+0x63 bit 2).

A CLEAR_FEATURE(ENDPOINT_HALT) on the bulk IN endpoint between a command
block and its data broke the command: the 961 MB stick still sent the data,
then stalled the status; the card reader refused the request and timed out
(its next command block was not taken until the bulk-only reset). The
first disk build did exactly that when a stick's IN toggle had to be put
back to DATA0, and `ls` on that stick timed out; the toggles are now set
before the command block. After those experiments the 961 MB stick stopped
answering at all, even after its port's reset (its controller had hung;
the hub's PORT_POWER requests did not cut the power, the hub has no
switch) -- a stick to plug in again by hand.

With the disk build on the box `disks` listed the card (FAT16 'PHONE
CARD') and the 64 GB stick (NTFS, not read), and `ls` the card's root --
long names, dates, hidden entries, 20 of them -- `ls 3:/rtltest` a
directory, `cat` two of its text files and a 26 KB G-code file in full (903
lines: the FAT16 chain followed across its clusters).

A mouse came last: an A4Tech (09da:c10a, low speed, a boot mouse with its
interrupt endpoint 0x81 of 8 bytes every 10 ms; GET_REPORT answers the tail
of its report descriptor, and SET_IDLE is taken but gives no idle reports)
on the second hub chip's port 4, the keyboard staying on the first one's.
Read alone through endpoint B it was fine. The first mouse build shared
endpoint B between the two -- each device's IN pending in turns, the data
toggles kept as for the disks -- and on the box the pointer only moved a
little: the mouse's reads failed now and then, packets were dropped for
their toggle, and the keyboard got spurious empty reports. Ending a pending
IN (the FIFO reset) can throw away a packet that the hub's translator
already acknowledged to the device, and the toggles fall out of step; with
two devices behind translators taking turns, that happens all the time.
Endpoint C sends nothing to a low-speed device, also with interrupt enable
3 written as the SDK does (+0x2E = 0x77). Endpoint D, the SDK's second
interrupt engine (`hcd_s3602_IntInD_start`), does poll, and RAM-loaded tests
showed how:

- With +0xA3 = 7 a token goes out every 8 ms; behind the hub +0x89 bit 7
  reads 1 for about 1 ms each time (the split transaction), the first
  within a few ms of the start. Aimed at an endpoint the mouse does not
  have, each fails with token error 0x10 and flags 1 bit 4 (at the hub's own
  missing endpoint, without a translator: 0x20 and bit 5), flags 3 stays 0
  and the polling goes on.
- A packet goes into endpoint D's FIFO -- +0x24, read until +0x23 bit 7
  says it is empty -- with flags 3 bit 4 and +0x63 = 0x09. The SDK's
  `epD_finish_ok` stops the polling (+0xA3 = 0, +0x2B bit 3 cleared),
  empties the FIFO and the next request starts it again; read before the
  flag, the FIFO gave half a keyboard report.
- The hub's own status endpoint, read through endpoint D while one of its
  ports was suspended and resumed three times, answered each change (the
  byte 0x04: port 2) and nothing before; the data toggle lasted through the
  stops and starts. After a CLEAR_FEATURE(ENDPOINT_HALT) on the hub's
  endpoint (its toggle back to DATA0) the next packet was dropped for its
  toggle (+0x1D = 0x08; the hub sent its change again) unless bit 0 of
  +0x23 had been pulsed: that puts endpoint D's toggle back to DATA0.
- The low-speed keyboard behind the translator delivered its report
  through endpoint D as well.

So the demo reads the mouse with endpoint D, and the keyboard keeps
endpoint B to itself as before the mouse. On the box (2026-11-13) the
pointer then followed the A4Tech behind the second hub chip and the
keyboard typed alongside it: 641 mouse reports, none dropped for its
toggle, no error, the buttons told on the UART; 163 keyboard reports, 90
keys, no error. The keyboard's count of reports dropped for their toggle
read 6 -- a toggle error seen in +0x1D while its IN was pending, which with
endpoint D busy may not have been the keyboard's own (with the mouse
still, 20 s of endpoint D's polling never set +0x1D).

Then a CH341 (1a86:5512, "USB UART-LPT", full speed, a vendor interface with
two 32-byte bulk endpoints and an interrupt one) went into the second hub
chip's port 1: enumerated and configured through that chip's translator --
the first full-speed device behind the hub on this box (+0x81 bit 6 clear).
The demo has no driver for it; `lsusb` lists it. The disks showed two
quirks. The 64 GB stick (090c:2000) left the first command after a minute or
more without commands unanswered -- no data, no status, 5 times in 5 -- and
answered the next one at once; a RAM-loaded test showed that a plain
CLEAR_FEATURE(ENDPOINT_HALT) does put its toggles back to DATA0, so it is not
the toggles. A command now gets 2 s, then the reset recovery and a second
try: on the box, after 100 s idle, `sector 6:0` read in 2.4 s and `disks`
counted one command sent again. The failure was told with the stage name
of the recovery's own requests ("status (IN) stage: time-out"): the error
text now keeps the
failed transfer's stage. And the 961 MB stick (ffff:5678) stopped answering
after two restarts of the box and a `usb` (its port reset), as it had once
before: it needs to be plugged in again.

With a webcam (17a1:0118, full speed, behind the first hub chip) the box
then had nine devices; the demo kept seven and refused the mouse as the
eighth (its port switched off). The endpoints' address registers take four
bits of an address (`set_ep_device_address` masks it with 0xF), so the
demo now keeps fifteen, hubs among the first seven: on the box the mouse
became device 8 and moved the pointer (117 reports through endpoint D, none
dropped, no error), and the 64 GB stick device 9, enumerated at that
address and its partition table read through endpoints A and B.

The shell's first write on the box failed. `mkdir 4:/alitest` on the card
wrote the new cluster's FAT entries (a sector each, one packet), then the
zeroing of the cluster -- WRITE(10) of eight sectors, 4 KB -- timed out,
and the card reader answered nothing more until the bus was reset (`usb
reset`). A RAM-loaded test logged that transfer on a free cluster at the
card's end (its sectors read first and written back after): flags 2 bit 6
(endpoint A done) and +0x63 bits 0 and 3 come after every 512-byte packet,
the DMA's count of bytes left drops as the FIFO takes them, and +0x63 bit 1
-- the DMA transmit done, which the SDK's `hcd_s3602_dma_tx_done` waits for
-- only after the eighth (5.9 ms; the reader kept one packet waiting for
5.5 ms). The demo had taken the first bit 6 for the end: the reader got 512
of 4096 bytes and waited for the rest. Ended at bit 1, the write and its
read back matched; the emulator's endpoint A now sends packet by packet
with those flags (the old build's `mkdir` fails there too). With the new
build `mkdir 4:/alitest` made its entry (in a deleted entry's slot, with
Windows' lower-case flag; cluster 259, its `.` and `..`, the rest zero; both
FATs' entry 0xFFFF) and `rmdir` put both FATs back byte for byte. The
failed try had left its cluster (258) marked used in both FATs -- its undo
could not run with the reader stuck: a scan of the FAT and the directory
tree found it, and it was freed, both FAT sectors checked first and read
back after.

The TV console's drawing has to read the UART too. The chip's receive FIFO
holds 16 bytes (30 sent while nothing read it: 16 kept, the overrun bit
set), 1.4 ms at 115200 baud, and a whole console redraw takes 17.5 ms on
the box; installing the RAM loader -- 25-byte `mw` lines, each printing a
line -- once failed on a word that read back wrong. The console's and
`gfx_fill`'s loops now empty the FIFO every row: 40 lines of 70 bytes,
each sent the moment its prompt came, were all taken whole.

Then the shell went through on the card, checked from its sectors: `cd`
(any case, relative, `..`, `/`), `pwd`, `ls` / `dir`, `mkdir` and `touch`
with long names and spaces (8.3 aliases `LONGFI~1.TXT`, the long-name
checksums right, Windows' lower-case flags on `a.txt`), `.` and `..`, the
refusals, all removed again by any case -- both FATs back byte for byte.
After `cp`, `mv` and `>` / `>>` came: `echo ... > hello.txt` and `>>`,
`help > help.txt` (4053 bytes), `help >> big.txt` nine times (36477 bytes
over two 32 KB clusters), `cp` to a new name, into a directory, to the
root and of the two-cluster file, `mv` of a file into a directory and of a
directory (its `..` right) -- every file read back from the card's sectors
the same as what was written, and after `rm` / `rmdir` both FATs again as
before.

An LTE module (SIMCom A7670E, 1e0e:9011, high speed) on the port has RNDIS
(interfaces 0 and 1), two diagnostic ports (2, 3) and two AT ports (4, 5),
all but RNDIS of the vendor class, with 512-byte bulk packets. AT commands
sent to an AT port were taken, but the demo's bulk IN never got an answer.
An answer is a short packet: the echo comes first, then the answer (`ATI`:
145 bytes). RAM-loaded tests showed what endpoint B does with one. A packet
shorter than the DMA's count raises endpoint B's done (flags 2 bit 5) but
not the DMA's (+0x63 bit 2). The packet stays in endpoint B's FIFO, +0x2C
holds its size, and the controller goes on sending IN tokens, so the next
packet replaces it. With a count of 1 byte the first packet ends the
transfer: both flags are set and the tokens stop. By then the FIFO has
handed the packet's first two bytes to the DMA, since it gives the DMA
16 bits at a time. Started again (+0x38 = the size - 2, the +0x60
strobes, +0x32 bit 3 alone), the DMA moves the rest to the buffer's start.
The SDK's `epB_finish_ok` restarts it the same way, with +0x2C's size. The
demo's `usb_bulk_in_packet` reads a packet of any size this way, and `at i`
answers in 0.2 s. The emulator's endpoint B now takes the DMA's count of a
packet and keeps the rest in its FIFO for the restart. A short packet
before the count still ends the transfer there.

After `AT+CRESET` the module drops off the bus for a second. Then its
chip's boot port comes for 0.6 s (ASR, 2ecc:3004, CDC ACM), and the
module's own interfaces return about 8 s after the command. Once it went
and came back a second time, about 30 s after: it then answered at its
address but stalled requests to its endpoints (no configuration), though
the port's connection had not changed. It also restarted by itself once,
soon after a SIM was found. The demo sets up the boot port (`ttyACM0`) and
the module as they come. A device that does not answer when it comes is
tried again every 3 s. A change of the port's connection between two of
the main loop's looks (the controller keeps it: flags 1 bit 0) sets the
device up again if it lost its configuration (GET_CONFIGURATION 0), and
`at` / `cu` set the bus up again when a port fails that way. With a SIM in
(its PIN lock off) the module registered on its home network (GSM,
`+CREG: 0,1`), signal 25 to 27, and fetched http://example.com/ with its
own HTTP client: data context 1 activated (`AT+CGACT=1,1`; the APN was set
already), `+HTTPACTION: 0,200,577` a few seconds after the command's OK,
the 577 bytes after AT+HTTPREAD's OK. While it sent, one bulk IN failed
with a UTMI error (+0x1D = 0x04), the module still set up: `cu` ended
there, so `at` and `cu` now try again in that case. `at` read only up to
the OK, dropping AT+HTTPREAD's data and the `+HTTPACTION` line; it now
reads on for 250 ms after the final result and shows what was waiting
before the command: the page fetched with `at` alone took 0.55 s.

Profiled with RAM-loaded tests calling the demo's own SCSI routines, every
disk took about 5 ms a command: a 512-byte READ(10) 5.1 ms, 4 KB 5.7 to
6.0 ms (650 to 730 KB/s), a 1 MB file written through the FAT writer 246
KB/s. Timed stage by stage, the command block took 1.0 ms, the data 2.1 ms
and the status 2.0 ms. The NAK retry setting (+0xA8 = 0, 1 or 8) changed
nothing. The time was the demo's own: its FIFO reset (init_ep_fifo) waited
a millisecond, once for the command block and twice for each IN. The SDK's
waits OS_Delay(1). With 10 us a 512-byte read takes 0.96 ms, and 4 KB
reads run at 2000 KB/s on the card (FAT16) and 2752 KB/s on the 961 MB
stick (FAT32), with no command lost. A 1 MB file is written at 452 KB/s and
removed in 0.56 s. Bigger commands would go further: with the 1 ms resets,
16 KB READ(10)s ran at 2306 KB/s and 32 KB ones at 3555 KB/s. A 64 KB one
left the controller answering nothing until `usb` set it up again. The 64
GB stick (090c:2000, NTFS) lost no command in the first measurement; after
that 64 KB try it lost about a third of them, at any FIFO reset wait (10 us
to 1 ms), even after a bus reset, so it needs to be plugged in again.

On 2026-11-15 the real cause of such losses was found: devices at USB
addresses 8 and up. Forcing the RTL8153 to one address after another
(a test build choosing its address), at 8, 9, 10, 11, 12 and 13 about one
set-up in three lost bulk OUT data -- every DHCP frame (they go 2 s
apart), or the first ping after a pause -- while at 7 none did in 40
set-ups. The controller said each OUT was done (in 20 us, no token error,
endpoint A's FIFO empty: waiting for that, as the SDK's
hcd_make_txfifo_is_empty does, changed nothing), so the device must have
taken the packet as a repeat -- a data toggle out of step -- and dropped it.
The 64 GB stick, always at 9 or 10 then, lost its first command block after
a pause the same way. Now an OUT endpoint of a high-speed device at
address 8 or more that has been idle for 500 ms gets both its toggles
(OUT and IN: the RTL8153 still lost a ping reply now and then with the OUT
alone) put in step again -- CLEAR_FEATURE(ENDPOINT_HALT) and the
controller's toggle pulsed -- before its next transfer: 12 forced set-ups
at 8, 10, 11 and 13 all got their address and every ping through. It is
kept to those devices: the card reader (address 4) answered no command
after such clears, and WCH's chips ignore the toggle reset a clear
should do. Not tried yet on other high-speed devices at those
addresses (an LTE module behind a hub would get the same clears).

That did not cover everything. With a keyboard plugged in the 64 GB stick got address 10, lost 13
commands in 25 minutes and then, in a copy onto it, stopped answering for good: no SETUP at its address,
none after its hub port's reset either, while the hub still called the port connected and enabled, with
no over-current -- the stick's own controller hung, and only unplugging it brings it back. The write had
waited 2 s for the stick and then sent the reset recovery; whether that reset hung it or it had hung
already is not known. And an RTL8153 at address 8 dropped a third of its frames after six hours up. So
two things changed. When a high-speed device is about to get an address and the first seven are taken,
a low- or full-speed device among them (not a hub) is moved to the highest free address -- forgotten,
its port reset, set up again -- and the high-speed one takes its place (its own port is switched off
meanwhile and reset once more: its speed is known only after its reset, and two devices must not both
answer at address 0). Only a device that answers is worth a place: the first 8 bytes of its device
descriptor are read before anything is moved. That keeps hubs, disks and network adapters at 7 and
below while there are no more than seven of them. And a write's first try waits 10 s, not 2 s, before
the reset recovery. The fault at addresses 8 and up itself is not understood.

The stick came back replugged and still did not answer: its port's reset ends with the port enabled at
high speed (status 0x0503), and then no SETUP at address 0 gets a handshake -- not 20 ms after the
reset, not after 100, 200, 500, 1000 and 2000 ms more, not after a second reset, not after its hub
port's power was switched off and on (CLEAR_FEATURE / SET_FEATURE PORT_POWER: the hub reports the
disconnection and the connection, and the hot-plug poll sets the device up as if it had been
plugged in -- a way to test that without anyone at the box), not after the controller was set up from
scratch. Every other high-speed device behind the same hubs answers. So it is the stick, and it has to
be looked at in a PC. Moving a device for it at every start was pointless, hence the descriptor read
first; the move itself was then tried on the box with a disk that works (the keyboard's port switched
off and on so that it took address 4, then the card reader's: the CH341A went from 6 to 15, the reader
got 6, a file on its card read with the right CRC-32).

Three more things turned up while the box was tested alone for a few hours (2026-11-15):

- A '}' typed itself without end. Endpoint D's first packet after it is opened on the keyboard is now
  and then not a report: 4 bytes, 29 86 30 01 (the same ones after a cold start, after `usb`, after
  `usb kbd report` and back). Taken as a report they were Shift + ] held, and since a keyboard sends
  nothing until a key changes the repeat went on until somebody pressed a real key -- the command line
  was unusable over UART meanwhile. A report shorter than the endpoint's packets (8 bytes), or one with
  a key code of 1 to 3 (the error codes) in any place, is now counted as an error and ignored. Where
  the 4 bytes come from is not known: ordinary control transfers to a device behind the same
  translator, port resets and devices set up on the same hub did not produce them.
- A hub that stops answering stopped the hot-plug poll. The dock's 1a40:0801 hub sits at full speed
  behind the 05e3:0610 hub's translator and now and then answers long enough to be set up (two devices
  behind it never do) and then stalls every request, while its port still says connected and enabled.
  The poll, getting no port status from it, went back to that port ("unplugged?"), found nothing
  changed, came to the silent hub again, and so on: the hubs with lower addresses never had their turn
  and nothing plugged in or pulled out was noticed any more. Now the other hubs have their turn in
  between, and after three such rounds the silent hub is forgotten with what was behind it and its
  port switched off, with a line saying so; replugging it brings it back.
- Then an independent review of all that found, and these were fixed: the guard against moving a
  second device kept every device behind a new hub from the same rule (a disk behind it could land at 8
  and up); a full-speed hub (the dock's) never made room; a moved device that did not come back took the
  keyboard with it (now three tries, then the next keyboard or mouse takes over); one count of silent
  rounds for all hubs (two silent hubs kept resetting each other's -- now each hub has its own); a hub
  given up stayed so even when it had only been reset behind the demo's back (now it is set up once more
  from its port's reset first, and only switched off when silent a second time); the resync after an
  idle pause went to full-speed devices too (now high speed only); and the long wait after a write
  covered the WRITE alone -- SYNCHRONIZE CACHE and the next command's block (taken by a stick still
  writing its flash only after it) had 2 s, now 10. On the TV the "Could not open" message left the
  rest of an arrow key's bytes for the command line, and a reason starting with '.' was dropped.
- `battery.py` (not in the repository: a test from the PC over UART and FTP) -- nine files read with
  `sum` and fetched through FTP, the CRC-32s compared; 1.5 MB of random bytes stored through FTP, read
  back both ways, copied and moved on the card, the directory removed, the free space as before; ping
  both ways; 300 frames of two cartridges with the picture's CRC-32 compared; a picture decoded; the
  serial port's baud rate set; no key held -- is what the stability figures mean by a round. The flashed
  build of 2026-11-15 ran 14 rounds with 3 idle minutes between them, then the next one 15 (an hour):
  the first lost one ping of 140, the second's only failures came from one moment when the USB keyboard
  reported 8 keys and F2 held for some minutes, which nobody at the PC had typed (a person at the box,
  or reports that pass the junk filter: not known; raw reports are logged since).

A USB 3.0 hub with a network port (Genesys Logic 05e3:0610, behind it a
Realtek RTL8153 0bda:8153) put a third hub on the bus. The RTL8153 has two
configurations: Realtek's own, and CDC ECM (a communications interface with
the Ethernet descriptor -- MAC address in string 3, 1514-byte segments --
and interrupt endpoint 0x83; a data interface whose alternate setting 1 has
bulk endpoints 0x81 and 0x02, 512 bytes). Set to the second, with the data
setting chosen and the packet filter at directed + broadcast, its link came
up 1.6 s later, the home network's frames came in (about 70 a second, most
of them ARP) and a DHCP DISCOVER was answered by the router's offer. The
demo now does that by itself: DHCP gave it an address, `ping` to the router
took 0.6 to 0.9 ms, and a PC's ping of the box was answered (2 to 25 ms:
frames are read every 20 ms). On 2026-11-14 the Linux-like `ping` went out
through the router too: 8.8.8.8 at 14 ms (TTL 119), example.com asked of the
router's DNS and answered at 8.7 ms, a name that does not exist told, Ctrl-C
ending an endless one with its statistics. Reading frames takes endpoint B from the
keyboard every 20 ms; `usb_in_stop` used to drop a key report that had come
just then (and with it the next, its data toggle out of step: keys
repeated), and now keeps it -- but behind the hub's translator a report
caught between the split transaction's two halves is still lost: 26 of 150
reports, a key stuck. So the keyboard now has endpoint D, which polls by
itself and is never taken away, and a mouse reads through endpoint B.

## The flash procedure on every image

`tools/bootloader_flash_survey.py` runs the procedure of this page (capture,
handshake, backup dump, transfer + burn of a test application packed for
each image's own main code format, readback dump, reboot, cold boot) on
every firmware image in `dumps/` in the emulator and writes
[bootloader_flash_survey.md](bootloader_flash_survey.md).

Loaders built with the SDK's `TRANSFER_FORMAT3_ONLY` answer the classic
handshake bytes with 0xFF - byte: they speak only ALi's packet ("format 3")
protocol. `tools/ali_packet.py`, written from the SDK's own loader sources
(`refs/BootLoader/SRC/lib/libapplet/libbootupg3`), speaks it -- every
command, data block and status in a CRC-checked `HEAD` packet -- and the
survey runs the same procedure through it on those loaders
(`tests/test_ali_packet.py`, `tests/run_packet_protocol_amiko.py`).
`tools/maciej_uart.py` itself stays the classic client for dump_maciej.bin.

## Build the application

Use a little-endian MIPS GCC cross-compiler with its matching `objcopy` and
`objdump`. No vendor SDK, libc, or operating system is required. The sources
are in `firmware/maciej_app/`.

From the repository root, with the compiler installed on this workstation:

```powershell
$env:MIPS_CROSS_COMPILE = 'W:\TOOLS\g++-mipsel-none-elf-15.2.0\bin\mipsel-none-elf-'
python firmware/maciej_app/build.py --version v1
python firmware/maciej_app/build.py --version v2
python firmware/maciej_app/build.py --version v3
python firmware/maciej_app/build.py --version v4 --demo
```

On other machines, set `MIPS_CROSS_COMPILE` to the local prefix, pass
`--cross-prefix`, or put `mipsel-none-elf-gcc` / `mipsel-linux-gnu-gcc` and the
matching binutils on PATH. The build script uses argument arrays, so compiler
and output paths may contain spaces.

The result for each version is `build/maciej_app/VERSION/app.bin` plus an ELF,
link map, disassembly, and build manifest. The v3 application compiles
to 892 bytes with GCC 15.2.0; the archived v2 binary is 624 bytes. Each build
prints the exact UART banner `ELEKTRODA ALI M3801 TEST FOR MACIEJ`, followed by
its configured version on a separate line. Sending `p` returns `pong VERSION`,
and `v` prints the banner and version again. The application uses 115200 baud, 8 data bits,
even parity, 1 stop bit.

The essential build settings are MIPS32 (not MIPS32r2), little endian, o32 ABI,
soft float, no PIC/abicalls, and `-G0`. Linking explicitly uses `-static -no-pie`
so a Linux cross-compiler cannot introduce a dynamic loader. `link.ld` places `_start` at
`0x80000200`. `start.S` masks CPU interrupts, supplies its own stack, initializes
`$gp`, clears BSS, and calls C. It does not repeat the board's DRAM startup.

## Package for the loader

```powershell
python tools/maciej_image.py inspect dumps/dump_maciej.bin
python tools/maciej_image.py pack --app build/maciej_app/v1/app.bin --output build/maciej_app/v1/flash.bin
python tools/maciej_image.py pack --app build/maciej_app/v2/app.bin --output build/maciej_app/v2/flash.bin
```

Each packaging command writes:

- `flash.bin`: a complete 4 MiB flash image for a simulator or programmer.
- `flash.maincode.bin`: the application chunk to send through the bootloader.
- `flash.json`: addresses, lengths, checksums, and preservation hashes.

The UART payload begins at flash offset `0x50000`. It includes the ALi chunk
header and compressed application, rounded to a 64 KiB boundary using the
original bytes as padding. It is 64 KiB for this demo. The chunk's existing
`0x240000` allocation remains unchanged, so subsequent chunks stay at their
original addresses. Bytes beyond the new compressed stream are retained.

| Item | Value in this dump |
| --- | --- |
| Flash contents | `0x400000` bytes |
| UART dump trailer | 4-byte big-endian CRC, excluded from flash |
| Bootloader | Starts at `0x000000`; next chunk at `0x04FE00` |
| HDCP key chunk | `0x04FE00` |
| Maincode header | `0x050000`, chunk ID `0x01FE0101` |
| Maincode allocation | `0x240000` bytes; next chunk at `0x290000` |
| Header size | 128 bytes |
| Load and entry | `0x80000200` (original header uses default values) |
| Compression | LZMA-alone, `lc=0`, `lp=2`, `pb=2`, 8 MiB dictionary |
| LZMA decoded size | Explicit little-endian 64-bit size at stream bytes 5..12 |
| Chunk CRC | CRC-32/MPEG-2 over bytes `[header+16, header+16+length)` |

Chunk words are big endian, despite the CPU running little endian. The chunk
`length` is **128-byte header plus compressed stream minus 16**; it excludes
sector padding and the unused part of the allocation. The 128-byte header's
other fields, including its next-chunk span, are preserved. The old decoder
stops at the declared uncompressed size, so the packager writes that size
instead of Python's default unknown-size LZMA header.

Python's compressor also emits an end-of-stream marker, which the original
loader does not need after decoding the declared size. Python's generic
`lzma.decompress(..., format=lzma.FORMAT_ALONE)` rejects this generated
known-size/marker combination. To extract a packaged application, use
`tools.maciej_image.extract_application(flash_bytes)` with the complete flash
image: it validates the image and decodes the raw LZMA stream to the declared
size, matching the bootloader.

## Test repeated flashing in the simulator

The self-test builds both versions from source before running the update
checks. With the compiler selected as above:

```powershell
python tests/run_dump_maciej_custom_app.py --require-toolchain --engine cpp
```

This test is included in the repository's `--slow` suite and GitHub Actions.
GitHub installs `gcc-mipsel-linux-gnu` and its binutils, treats a missing
compiler as a failure, includes the test in its HTML report, and uploads the
builds, flash snapshots, and UART transcripts as `maciej-app-selftest-cpp`
(or the corresponding Unicorn artifact). Locally, a missing compiler is
reported as not applicable unless `--require-toolchain` is given. An explicitly
configured but incomplete toolchain always fails.

To run only this regression through the suite and generate its HTML report:

```powershell
python run_all_tests.py --slow -k maciej_custom_app --engine cpp
```

The distributed ZIP has a separate regression:

```powershell
python run_all_tests.py --slow -k maciej_uart_bundle --engine cpp
```

It checks the archive against the canonical files, extracts it, and runs the
updater's CLI against the original bootloader through an emulated pyserial
device. It installs the same v2 payload twice, checks both full backups and
UART readbacks, refuses reused backup filenames, and checks native reboot,
cold boot, and `p`/`v` responses after each installation. No physical serial
port is used. This complete CLI regression runs on C++ and keeps the updater's
hardware timeouts unchanged; the slower Unicorn engine reports it as not
applicable. Results are saved under `build/maciej_app/selftest/cpp/bundle/`
and included in the existing GitHub self-test artifact upload.

Validated locally on 2026-11-11: the packaged CLI completed both installations
in 941.536 seconds (943 seconds including the suite wrapper), with four full
UART dumps, preserved backups, native reboot/cold boot, and `p`/`v` checks.
The second backup exactly matched the flash produced by the first cycle.
The separate fresh-build original-to-v1-to-v2 test passed in 181.539 seconds,
and the distributed v2 image also passed a native Unicorn cold boot. These
are simulator results; the updated GitHub workflow still requires its own run.
Physical-board results are recorded below.

To test already-built applications directly:

```powershell
python tests/run_maciej_bootloader_update.py --engine cpp
```

The integration test starts from the original dump and sends UART bytes to
the running firmware. It interrupts boot, enters the bootloader protocol,
transfers and burns v1, compares the resulting flash, requests a bootloader
reboot, checks the application banner and ping, and checks a fresh cold boot.
It then starts from the persisted v1 image and repeats the sequence for v2.
The loader's own LZMA decoder runs with `lzma_hle=False` for both new
applications, including their cold boots. Entering recovery on the original
image uses the simulator's existing decompression shortcut for its large
stock application; the shortcut is disabled before testing the new apps.
The harness does not patch guest PC, RAM, or flash to perform an update.

The self-test writes results, UART transcripts, and flash contents actually
written by the guest under `build/maciej_app/selftest/cpp/integration/`.
The direct harness uses `build/maciej_app/integration/`. The test asserts the
bootloader and every byte outside the transferred region remain unchanged.
`--engine unicorn` selects the alternative emulator; it is slower.

Validated on 2026-11-11 after the banner update: the complete C++ self-test
built both versions from source and passed in 200.849 seconds of simulation checks,
including both updates, reboot and cold boot of each version, UART pings,
and the final 4 MiB UART dump with CRC verification. Separate Unicorn cold
boots of both versions also passed with native LZMA decoding. The five image
tests and thirteen protocol tests passed. An independent simulated bad-CRC
packet was rejected and successfully retried before programming and reboot.
No simulator core changes were needed. The complete UART update test was run
locally on C++; GitHub execution will occur when the workflow is triggered.

The test transport delivers 16-byte bursts paced for 115200 8E1. Injecting a
whole 1028-byte packet instantaneously overflowed the firmware's receive
buffer; baud pacing made the same protocol complete successfully.

For a graphical run of a packaged image:

```powershell
python src/gui_simulator.py build/maciej_app/v1/flash.bin
```

The v1..v3 applications use the UART only and draw no TV picture. The v4
demo is best tried in the interactive TV, which shows its screen live, has
a virtual remote (it finds the codes in the key table the demo carries)
and a UART console on F5 for the command line:

```powershell
python src/tv_gui.py firmware/maciej_app/bin/elektroda_ali_m3801_maciej_v4.bin
```

## Flash a board through its existing loader

`tools/maciej_uart.py` uses the same protocol client as the simulator test.
The serial adapter requires pyserial. Select the actual COM port explicitly;
the examples below use `COM3` only as a placeholder. Connect UART TX/RX and
ground with appropriate signal levels, and configure **115200 8E1**. Maciej's
post reports 3.3 V UART levels on this board.

```powershell
python tools/maciej_uart.py --port COM3 --capture-boot 60 probe
```

Power-cycle the box when the command prints its capture message. It sends
`c` during startup to hold the bootloader. It does not manipulate RTS/DTR to
reset the board. A successful `comtest` handshake confirms communication.

To install v1, run this and power-cycle when prompted:

```powershell
python tools/maciej_uart.py --port COM3 --capture-boot 60 flash build/maciej_app/v1/flash.maincode.bin --backup build/maciej_app/before-v1.bin
```

The command reads a full CRC-checked backup, checks the bootloader identity,
updates only the maincode, reads back the complete flash, compares it against
the expected result, and reboots. Full backups/readback take several minutes
at 115200 baud. An existing backup filename is refused so earlier recovery
copies remain available. `--stay` keeps the box in the loader after verifying.

Repeat with the second version and a fresh backup filename:

```powershell
python tools/maciej_uart.py --port COM3 --capture-boot 60 flash build/maciej_app/v2/flash.maincode.bin --backup build/maciej_app/before-v2.bin
```

Power-cycling re-enters the unchanged factory bootloader on every version.
The v3 application also supports software capture without cycling power. Use `flash.maincode.bin` as the UART
payload; `app.bin` lacks its chunk header and `flash.bin` is a full flash image.

## Wire protocol and the original investigation

The relevant public observations are Maciej's
[UART setup, post 7](https://www.elektroda.pl/rtvforum/topic4156384.html#21788762),
[update commands and dump, post 15](https://www.elektroda.pl/rtvforum/topic4156384.html#21794256),
[corrected packet length, post 21](https://www.elektroda.pl/rtvforum/topic4156384.html#21794965),
and [bootloader-preserving application question, post 32](https://www.elektroda.pl/rtvforum/topic4156384-30.html#21803726).
Local reference SDK code supplies the protocol structure; simulator execution
against this exact dump checks which variant it actually implements.

1. Send `c` during startup.
2. Send `comtest 2\r`, then two test bytes. The client uses `XX`; Maciej used
   two additional carriage returns. The command and test bytes are echoed.
3. Send `address 327680\r`. The reply after its echo is `O`.
4. Send `transfer LENGTH\r` using the decimal payload length. Wait for `O`.
5. Send blocks of 1024 data bytes plus a 4-byte big-endian CRC. Wait for `O`
   after each block; `E` requests a retry. CRC polynomial is `0x04C11DB7`,
   initial value `0xFFFFFFFF`, no reflection and no final XOR.
6. After a complete transfer, send `burn\r`. Read `O`, progress records,
   and final `F`. An acknowledged transfer alone has not programmed flash.
7. Read back with `dump\r`: BE32 flash size, host `O`, flash bytes, BE32 CRC.
8. Send `reboot\r`, receive `O`, and let the loader verify/decompress the app.

The numeric parser takes **decimal**. In particular, `address 0x50000` is
parsed as zero, which points at the bootloader. The supplied client fixes the
only writable start at `327680` and checks the chunk span before transmission.
This loader does not need a `go` command: a valid maincode chunk plus reboot
uses its normal application-loading path.

Physical validation on 2026-11-11 used a 3.3 V CH340 UART on COM46 at 115200
8E1. A complete CRC-checked backup matched the original dump byte for byte
(raw flash SHA-256 `fac12fb68bdd76a86c5f7ba0b8c1325ed9ee1e401daafb14529a35df6729dc44`).
The bootloader accepted the distributed 64 KiB v2 payload, reported `B0320K`
and completion, and returned a complete CRC-checked readback matching the
distributed v2 image (SHA-256
`0088537d657984b6e50d603d51cc08e64304b5c278a5d46191a7d3dbce827b15`).
Every byte outside the payload remained unchanged. A bootloader-requested
reboot printed the exact banner and v2 version; `p`, `v`, and three further
pings over 30 seconds passed. The original backup and UART logs are kept locally under ignored
`hardware_backups/`.

A second physical update on the same tuner used BK7231GUIFlashTool's shared
C# backend through its CLI to install v3. Its full backup matched the
previously verified v2 image. Complete readback matched the distributed v3
image (SHA-256
`3564d45b5354989f90f704c7bbf4ce1869182675a91bc3f158c6303da40c46c6`),
with every byte outside the payload unchanged. The v3 banner, version,
ping, and three further pings over 30 seconds passed.

The application's `r` command restarted through the original loader and
returned to v3. The Python client's existing repeated-`c` capture then
entered the bootloader without a power cycle; handshake, loader reboot,
and final v3 version/ping checks passed.

These results establish two physical updates and working software restart
and bootloader entry. A complete further update initiated from running v3,
and a power-off cold boot of v3, remain simulator validations.
