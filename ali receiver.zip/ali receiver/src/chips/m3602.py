"""
ALi M36xx generation (M3601E / M3602 / M3606: the Cabletech URZ0083 and
URZ0086, the Kruger&Matz KM0183 and KM0186, the Thomson THT501 and the
Ferguson Ariva T50 images), the SoCs before the M3801.  The CPU boots
straight from the flash window like the M3801's and the peripherals the
firmware uses first sit where the M3801's do (UART 0xB8018300, the I2C
masters 0xB8018200 / 0xB8018700 / 0xB8018B00, the GE 0xB800A000), and the
firmware wants an M36xx chip ID: the M3801's 0x3811 is not in its chip
tables, and an application that reads it starts over through the bootloader
(the URZ0083 every ~45 M instructions, the THT501 likewise).  The family's
own ID is 0x3602; a board whose SoC reads 0x3603 says so in its sidecar
(device.chipId, chips/base.py) -- the Opticum X110TS's application reboots
unless its chip code is 0x3603's, and the Cabletech, Kruger&Matz, Thomson
and Opticum S60 boxes read it too.  Their applications' USB host attach
gives the controller a base (0xB8032000 / 0xB8032400) only for 0x3603 or
0x3101: under 0x3602 the M3601E boxes' (URZ0083, KM0183, THT501) and the
S60's host start ran into its assertion (an SDBBP, then a jump to 0) right
after the boot logo, and the M3606 ones (URZ0086, KM0186) idled without
decoding theirs.  Under 0x3603 their bootloaders -- all but the X110TS's,
which reads with 0x03 -- read the flash with the quad I/O read 0xEB
(simulator._SPI_READS), which the simulator did not serve before: their
chunk headers read as zeros ("malloc size: 0") and 0x3602 had looked like
the only chip they booted on.

The Ferguson T50's bootloader probes its DDR at 0xA800AA68, 128 MB above the
first word: the RAM shows up again above its size here, as on a controller
that ignores the upper address bits.  It knows its 4 MB flash only by the
electronic ID of the 0xAB read (simulator._spi_command_response); with that
answered it starts its application, which draws with the M3602's own
graphics engine at 0xB800C000 (ge_m3602.py) and drives an HD and an SD video
output (video_m36.py) -- its first screen is its installation wizard.

The M3606 (URZ0086 / KM0186, the X110TS) has a SEE co-processor, which its
bootloader starts and waits for: see.py runs the SEE's boot code for that
handshake.  The application then starts the SEE's own program, which runs
on a second core (see.SeeCore) and answers the application's remote calls.

The M3601E boxes decode a boot logo from the flash before anything else and
wait until their MPEG decoder reports the first picture shown: the video
engine's completion and the video output's field interrupts are
video_m36.py's.

The chip ID 0x3603 is the SDK's C3603, whose product -- bits 8..11 of the
chip ID word -- picks a row of its feature table (product_feature); byte 4
of the row enables its DVB-S2 demodulator, which the Opticum X110TS's
application asks for by name (NIM_S3501_0) and by chip ID (S3501) once its
OSD is up, in a check of its own (0x801B994C).  With the product bits clear
(product 0, the one row without the demodulator) and no demodulator on the
I2C bus the check failed, and a task of the application cleared the OSD
layer's enable bit (0xB8006300 bit 0) about ten times a second: its screen
stayed black although it drew its channel banner.  A C3603 board therefore
reads C3603_PRODUCT in those bits and has its S3501 on the bus.

Recognised by the chunk chain: the HDCPKey chunk's version "Demo s3602"
(the M3801 images say "Demo M3801"), a maincode chunk named after the
SDK's M3602 / M3606 demo projects ("Demo M3602", "Demo M3606",
"M3606 2Tuner"), or a main-code chunk whose version names the chip (the
Opticum satellite updates: "M3601S", "M3606 2Tuner").
"""
import ctypes

from uc_const import UC_PROT_ALL, UC_MIPS_REG_FP

from demods import S3501
import tuners

from .base import ChipFamily, chunk_chain
from .see import SeeStart

RAM_WINDOW_END = 0x0F000000         # the flash window starts here (simulator.py)
C3603 = 0x3603                      # the chip ID of the twin-tuner satellite boards (the X110TS)
# (the SDK's sys_ic_get_c3603_product: bits 8..11 = 0xC -> product 0xE, 5 or 7 -> 0xB, others -> 0.
# Every product but 0 has the DVB-S2 demodulator; which one the X110TS's chip is, is not known.)
C3603_PRODUCT = 0x0500
# (the C3603's DVB-S2 demodulator is demods.S3501, at 0x33 on the first I2C master)


class M3602(ChipFamily):
    name = "M3602"
    chip_id = 0x3602
    # (its MPEG decoder, the SDK's vdec_s3601, keeps the VLD's bit offset at +0x28 of the
    # video engine: vdec_hal_vld_config_data writes the start, vdec_hal_vld_get_offset
    # reads it back.  Read as the M3801's status word, with bits 8..25 cleared, the
    # offset went back and the URZ0086 V1.1.1's SEE program stopped at its assertion
    # that the video buffer's read pointer only moves on, ~85 M instructions in.)
    ve_status = False

    @classmethod
    def matches(cls, image):
        raw = bytes(memoryview(image)[:0x100])
        if b"DVBS2---" in raw:
            return True
        for _offset, name, version in chunk_chain(image):
            if name == "HDCPKey" and version.startswith(("Demo s3602", "S3606")):
                return True
            if name == "maincode" and version.startswith(("Demo M3602", "Demo M3606", "M3606")):
                return True
            # the Opticum / Globo satellite updates name their main-code chunk by a number and
            # put the chip in its version ("M3601S", "M3606 2Tuner"; the Globo HD-XS2's M3503,
            # named in its bootloader's version, is m3503.py); Ferguson / Edision M3602 and M3606
            # bootloaders ("HS11" / "HS17" / "HS18" / "HS1C" / "HSJ2") start their version with
            # "350" or "370" ("35003-01047", "37017-01047").  ("M3612" / "Demo M3612" is NOT
            # M3602: its single-CPU silicon reads S3811 chip ID 0x3811 -> m3801.py.)
            if version.startswith(("M3601", "M3602", "M3606", "350", "370", "SMT---", "SMT ", "HACK S9")) or "HACK S9" in version:
                return True
        return False

    def default_chip_id(self):
        if self.sim.rom_image and b"DVBS2---" in bytes(self.sim.rom_image[:0x100]):
            return 0x3603
        return super().default_chip_id()

    def _ram_mirrors(self):
        """(address, size) of the RAM's mirrors above its size, up to the flash window."""
        sim = self.sim
        return [(seg + phys, min(sim.ram_size, RAM_WINDOW_END - phys))
                for phys in range(sim.ram_size, RAM_WINDOW_END, sim.ram_size)
                for seg in (0x00000000, 0x80000000, 0xA0000000)]

    def install(self):
        super().install()
        sim = self.sim
        # The RAM again above its size, up to the flash window (the T50's DDR probe)
        ptr = ctypes.addressof(sim.ram_buffer)
        for address, size in self._ram_mirrors():
            sim.mu.mem_map_ptr(address, size, UC_PROT_ALL, ptr)
        # the M3606's DMA engine at 0xB800F200, which the SEE's video decoder feeds, with its
        # start codes (m3821.DmaRings); the SEE core gets it too (core_devices, see.SeeStart._wire)
        from .m3821 import DmaRings
        self.dma = DmaRings(sim, base=0xF200, start_codes=True)
        # The M3606's SEE co-processor: its start handshake (see.py)
        self.see = SeeStart(sim)
        # the transport-stream demultiplexer DMX0 at 0xB8022000, as on the M3801 (dmx_m36.py)
        from dmx_m36 import Demux
        self.dmx = Demux(sim)
        # the video engine's completion and the HD and SD video outputs' field interrupts: a boot
        # logo gets decoded and shown (video_m36.py); on the M3606 the SEE drives them
        from video_m36 import DEO_FIELD_BIT, DEO_INT, DEO_LINE, VideoEngine, VideoOutput
        self.video_engine = VideoEngine(sim, reset=(0x80, 0x02))    # (0xB8000080 bit 1 resets it)
        self.video_output = VideoOutput(sim)
        self.sd_output = VideoOutput(sim, DEO_INT, DEO_LINE, DEO_FIELD_BIT)
        self.core_devices = (self.dma, self.video_engine, self.video_output, self.sd_output)
        # (The graphics engine most of these firmwares use is the M3801's: base
        # 0xB800A000 and interrupt-controller line 4.  The Thomson THT501's GE
        # attach pairs that base with "IRQ 12", which is the OS's interrupt
        # number -- the controller line plus 8, as the IR receiver's line 19 is
        # OS IRQ 27 -- so nothing differs; raising line 12 instead sends its
        # dispatcher to its fatal path at the first GE command.)  The T50's
        # driver is the older one of the M3602's own engine at 0xB800C000:
        from ge_m3602 import GeM3602
        self.ge = GeM3602(sim)

    def default_chip_id(self):
        # Dual-CPU M3606 / S3606 firmwares (8 MB flash builds such as Edision Argus
        # VIP3 "M3606c 1.1.3" and Openbox S16 EU "S3606H-1.0.0") compute a 4 MB
        # flash base (0xAFC00000) under 0x3602 and overflow past 0xB0000000 when
        # reading chunks above 4 MB; on M3606 / C3603 silicon (0x3603) they use
        # the 16 MB flash base 0xAF000000.
        if type(self) is M3602 and self.sim.rom_image:
            if any(version.startswith(("M3606", "S3606", "370"))
                   for _o, _n, version in chunk_chain(self.sim.rom_image)):
                return C3603
        return super().default_chip_id()

    def variant(self):
        return C3603_PRODUCT if self.chip_id == C3603 else self.chip_variant

    def write_chip_id(self):
        """The board's chip ID word, and on a C3603 (or M3602 'SMT' satellite
        builds) a fresh S3501 (plus the board's tuner model when its sidecar
        names one) on the I2C bus."""
        super().write_chip_id()
        self._remove_demod()
        has_smt = bool(self.sim.rom_image) and any(
            version.startswith(("SMT---", "SMT ")) for _o, _n, version in chunk_chain(self.sim.rom_image)
        )
        if self.chip_id == C3603 or has_smt:
            self._c3603_demod = self.demod = S3501(tuned=self.sim.tuned_to_signal)
            self.sim.i2c_devices[S3501.ADDRESS] = self._c3603_demod
            self.sim.attach_tuner()

    def _remove_demod(self):
        own = getattr(self, "_c3603_demod", None)
        if own is not None:
            if self.sim.i2c_devices.get(S3501.ADDRESS) is own:
                del self.sim.i2c_devices[S3501.ADDRESS]
            if self.demod is own:
                self.demod = None
            self._c3603_demod = None
            for addr in [a for a, d in self.sim.i2c_devices.items() if tuners.is_tuner(d)]:
                del self.sim.i2c_devices[addr]

    def start(self):
        """Bootloaders whose chunk header sets byte 0x43 = 0x80 (the Opticum
        X110p's EuP standby-on-AC-power-up flag) enter the flash standby loop
        unless $fp == 0xDEADBEAD (their wake-from-standby magic)."""
        super().start()
        eup_wake = 0xDEADBEAD if len(self.sim.rom_image) > 0x43 and self.sim.rom_image[0x43] == 0x80 else 0
        self.sim.mu.reg_write(UC_MIPS_REG_FP, eup_wake)

    def uninstall(self):
        for address, size in self._ram_mirrors():
            self.sim.mu.mem_unmap(address, size)
        self._remove_demod()
        super().uninstall()

