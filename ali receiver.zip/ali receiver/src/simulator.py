from uc_const import *
import sys
import os
import re
import struct
import threading
import time
import zlib
_np = False


def _get_np():
    global _np
    if _np is False:
        try:
            import numpy as np
            _np = np
        except ImportError:              # pragma: no cover
            _np = None
    return _np

from enum import Enum
from dataclasses import dataclass
from typing import Optional
from mips16_decoder import MIPS16Decoder
from tm1650_decoder import GPIO_DO_OFFSETS, GPIO_EXTRA_DO_OFFSETS
import chips

class ISAMode(Enum):
    """ISA mode enumeration"""
    MIPS32 = 'mips32'
    MIPS16 = 'mips16'


@dataclass
class StepResult:
    """Result of a single step execution"""
    address: int
    instruction: str
    operands: str
    next_pc: int
    mode_before: str
    mode_after: str
    is_branch: bool = False
    is_call: bool = False
    is_return: bool = False
    mode_switched: bool = False
    instruction_size: int = 4


ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # the repository
DUMPS_DIR = os.path.join(ROOT_DIR, "dumps")                               # the firmware images
_DUMP_INDEX = None


def resolve_dump(path):
    """The file a dump name refers to: the path as given when it exists, else
    the same name under dumps/ (directly or in one of its sub-folders), where
    the firmware images live.  Tests, tools and the GUIs name a dump by its
    file name ("dump.bin", "STRONG PRIMA VIII/GD25Q32B_20190128_141501.BIN")
    and run from any directory.  An unknown name comes back unchanged, so the
    open() error names it."""
    global _DUMP_INDEX
    if os.path.exists(path):
        return path
    candidate = os.path.join(DUMPS_DIR, path)
    if os.path.exists(candidate):
        return candidate
    base = os.path.basename(path)
    if _DUMP_INDEX is None:
        idx = {}
        for folder, _dirs, files in os.walk(DUMPS_DIR):
            for f in files:
                if f not in idx:
                    idx[f] = os.path.join(folder, f)
        _DUMP_INDEX = idx
    if base in _DUMP_INDEX:
        return _DUMP_INDEX[base]
    return path


def flash_size_for(path):
    """The rom_size a dump file needs: its size rounded up to a power of two,
    at least 4 MB.  A short tail is ignored (dump_maciej.bin is 4 MB plus the
    4-byte CRC its bootloader's 'dump' command appends), so 4 MB dumps stay
    4 MB and an 8 MB image (the Ferguson Ariva T650i's) gets 8 MB."""
    size = max(os.path.getsize(resolve_dump(path)) - 0x10000, 1)
    return max(0x400000, 1 << (size - 1).bit_length())


def default_engine():
    """The engine a simulator gets when none is asked for: ALISIM_ENGINE from the
    environment ('unicorn', the default, or 'cpp': the C++ core, simulator_cpp.py)
    or --engine <name> on the command line."""
    if "--engine" in sys.argv:
        try:
            return sys.argv[sys.argv.index("--engine") + 1].strip().lower()
        except IndexError:
            pass
    return (os.environ.get("ALISIM_ENGINE") or os.environ.get("ALI_EMU_BACKEND") or "unicorn").strip().lower() or "unicorn"


class AliMipsSimulator:
    engine = "unicorn"
    # C++ engine only, opt-in: the UART transmit holding register's bytes are
    # collected in the core and handed to the UART handler in bulk (before any
    # other call into Python and when a run returns) instead of one Python call
    # per byte.  The emulation time each store costs is unchanged; only the
    # moment the handler sees a byte moves to the end of its slice.  For long
    # transfers (the bootloader's 4-16 MB 'dump'); False keeps every byte
    # synchronous, as handlers that stop the run on a string expect.
    uart_tx_native = False
    # With uart_tx_native: a callable that gets those bytes as one bytes object
    # per hand-over instead of the UART handler one character at a time.
    uart_bulk_callback = None
    # The C3505 model rewrites the main code chunk's CRC field to 'NCRC' (no
    # CRC) when the machine starts; True keeps the image's own CRC, so the
    # loader checks it (chips/c3505.py; set before loadFile).
    keep_main_crc = False

    def __new__(cls, *args, engine=None, **kwargs):
        """AliMipsSimulator(..., engine='cpp') -- or ALISIM_ENGINE=cpp -- is the
        simulator on the C++ core (simulator_cpp.CppAliMipsSimulator); a second
        core (share_memory_with) runs on its first core's engine."""
        if cls is AliMipsSimulator:
            shared = kwargs.get("share_memory_with")
            if engine is None:
                engine = shared.engine if shared is not None else default_engine()
            if engine == "cpp":
                from simulator_cpp import CppAliMipsSimulator
                return super().__new__(CppAliMipsSimulator)
            if engine != "unicorn":
                raise ValueError(f"unknown engine {engine!r} (unicorn, cpp)")
        return super().__new__(cls)

    def __init__(self, rom_size=4*1024*1024, ram_size=128*1024*1024, log_handler=None,
                 share_memory_with=None, cpu_num=0, ic_base=0x30, engine=None):
        """A simulated ALi chip with one MIPS core.  The second core of a
        dual-CPU chip (the SEE, chips/see.py) is another instance made with
        share_memory_with=<the first>: the same RAM, flash and device-register
        buffers seen by its own Unicorn CPU, with its own CP0 state, timer and
        interrupt controller -- cpu_num, its CP0 EBase CPU number (the shared
        exception vector tells the cores apart by it), and ic_base, the offset
        of its interrupt controller's status / enable words in the device
        window (the first core's at 0xB8000030, the SEE's at 0xB8040030)."""
        if share_memory_with is not None:
            rom_size, ram_size = share_memory_with.rom_size, share_memory_with.ram_size
        # The flash is mirrored inside the 16MB windows (see _flash_offset): a
        # power of two up to 16 MB (a 4 MB or smaller part repeats every
        # rom_size bytes, a larger one is laid out in 4 MB segments).
        if rom_size <= 0 or (rom_size & (rom_size - 1)) or rom_size > 0x01000000:
            raise ValueError(f"rom_size must be a power of two of at most 16 MB, got {rom_size:#x}")
        self.rom_size = rom_size
        self.ram_size = ram_size
        self._shared = share_memory_with
        self._upper_ram_mapped = bool(share_memory_with._upper_ram_mapped) if share_memory_with is not None else False
        self._upper_ram_pending = None
        self._mapped_ram_size = self.ram_size if self._upper_ram_mapped else min(self.ram_size, 0x0F000000)
        self.ic_base = ic_base
        self._ic = 0xB8000000 + ic_base     # its status words (+0 / +4) and enables (+8 / +0xC), no side effects
        self._ic_en = self._ic + 8          # (the enables: elsewhere on older chips, set_ic_layout)
        self.base_addr = 0xAFC00000
        self.mu = None
        self._md = None
        self.uart_callback = None
        self.spi_callback = None
        self.gpio_callback = None
        self.gpio_devices = []          # the board's other chips on GPIO pins (attach_gpio_devices)
        self._gpio_dbg_seen = set()
        self._spi_dump_enabled = True
        self.log_callback = log_handler

        self.instruction_count = 0
        self.visit_counts = {}
        self.instruction_sizes = {}
        self.instruction_isa = {}        # address -> True if executed as MIPS16 (exact mode only)
        self.trace_instructions = False
        self._stop_instr = None
        self.break_on_printf = False
        self.max_instructions = 10000000
        self.is_syncing = False
        self.prev_executed_pc = None
        self.current_executed_pc = None
        
        # ISA mode (MIPS32 / MIPS16e).  Unicorn executes MIPS16e natively; the
        # mode is tracked exactly, see the "ISA mode tracking" section below.
        self._isa_mode_fallback = ISAMode.MIPS32
        
        # Call stack tracking for step_out
        self.call_stack = []
        
        # Debug flag - only log after MIPS16 mode entered
        self.debug_enabled = False
        
        # Breakpoints
        self.breakpoints = set()
        self.is_stepping = False
        self.pc_history = []
        self.history_size = 50

        # Simulated CP0 registers — Unicorn doesn't reliably expose these.
        # Count (reg 9): hardware cycle counter, incremented every instruction
        # Status (reg 12): IE, EXL, IM bits — controls interrupt enable
        # Cause (reg 13): IP bits — pending interrupt lines
        # EPC (reg 14): saved PC on exception entry
        self.cp0_count = 0
        self.cp0_compare = 0
        self.cp0_status = 0x10400000  # Must match Unicorn's initial CP0 Status
        self.cp0_cause = 0            # stored Cause bits; MFC0 reads _cause_value() (adds TI/IP7, IP3)
        self.cp0_epc = 0
        self.cp0_ebase = 0x80000000 | (cpu_num & 0x3FF)   # EBase (reg 15 sel 1): the exception vectors
                                                            # while Status.BEV = 0, and the CPU number

        # CP0 timer (Count == Compare -> Cause.TI / IP7), see "CP0 timer" below.
        self._timer_enabled = True    # property timer_enabled
        self.timer_irq_count = 0      # timer interrupts delivered
        self._ti = False              # Cause.TI latched (IP7 pending) until Compare is written
        self._timer_armed = False     # no timer events before the first MTC0 Compare
        self._timer_anchor = 0        # Count value up to which Compare crossings were checked
        self._timer_next_icount = 0   # exact mode: instruction_count of the next crossing check
        self._count_observed = None   # last Count value the guest read or wrote
        self._uart_ip3 = False        # IP3 asserted by a delivered UART interrupt until ERET
        self._ic_lines = 0            # interrupt-controller inputs driven by modelled devices (see _ic_set_line)
        self.doorbell_in = None       # where the other CPU of a dual-CPU chip rings this one (see _doorbell_ip3)
        self.ic_irq_count = 0         # IP3 interrupts taken for those lines and doorbells
        self._ge_status = 0           # graphics engine interrupt status (+8, see _hook_ge_write)
        self.ge_ops = 0               # graphics engine commands completed
        self.ge_render = True         # execute GE commands (draw into RAM) with the ge_m36f model
        self.ge = None                # ge_m36f.GeM36F instance (created on the first command)
        from collections import deque
        self._irc_fifo = deque()      # IR controller run-length FIFO (see ir_send_nec)
        self._irc_status = 0          # IR controller interrupt status (+7)
        self.irc_base = 0x18100       # its registers (device-window offset) and interrupt line:
        self.irc_line = self._IC_IRC  # the M3329 has the same controller at 0x1100 on line 7
        self._irc_frames = deque()    # NEC frames waiting to be received (any thread may append)
        self.slice_services = []      # called between slices (emulation thread): device models that feed data
        self.signal_frequencies = None  # set_signal(frequencies=...): where a signal is (None: everywhere)
        self._irc_last_vt = -1e9      # emulation time the last frame was received
        self._ir_key_table = None     # {vkey: ir16} found in RAM by press_key()
        self.ir_coding = "nec"        # how that table maps to NEC frames (ir_remote.IR_CODINGS)
        self.ir_keys_sent = 0         # IR frames delivered to the firmware
        self._in_run = False          # inside run(): hooks may stop the slice to deliver an IRQ
        self._run_tid = None          # thread running run()
        self._external_stop = False   # emu_stop() from another thread during run(): return
        self._eret_logged = 0
        self._dev_last = None         # last non-idempotent device access in this emu_start (see _dev_note)
        self._dev_cb_depth = 0        # > 0 while a device access callback runs
        self._dev_replays = {}        # (pc, sp) -> access a stop left the PC on (its re-execution is a replay)
        self._ds_dev_warned = set()   # PCs of device accesses in delay slots already warned about
        self._ds_flags_stale = False  # such an access left the branch flags set (_device_access)
        self.ds_flag_fixes = 0        # ... cleared that many times

        # UART Receive simulation
        from collections import deque
        self._uart_rx_queue = deque()  # Queued bytes for UART receive
        self._pending_uart_irq = False
        self._uart_irq_delivered = False
        self._uart_irq_arm_after = 0  # Deliver IRQ only after this icount
        self._uart_irq_retries = 0
        self._step_count = 0  # Hook-based step counter for precise single-stepping

        # ---- ISA mode tracking state (see _hook_code / is_mips16_mode) ----
        self._hflags_off = None      # byte offset of CPUMIPSState.hflags in a saved context
        self._ctx = None             # reusable UcContext for fast hflags reads
        self._hflags_view = None     # ctypes view onto hflags inside self._ctx
        self._live_env = False       # True when views point directly to live CPUMIPSState
        self._cur_m16 = False        # ISA mode of the instruction currently executing
        self._mode_resync_in = 0     # re-read exact mode from hflags after N more instructions
        self._next_in_delay_slot = False  # next hooked instruction is a branch delay slot
        self._stop_reason = None     # why _hook_code called emu_stop() (None = external stop)
        self.verify_isa_mode = False # debug: cross-check tracked mode against hflags every insn
        self.isa_mode_mismatches = 0
        self._delay_slot_skips = 0   # CP0 emulations skipped because insn sat in a delay slot

        # ---- Execution modes ----
        # Fast mode (default): Unicorn runs natively in batches of `batch_size`
        # instructions; Python is only involved through small ranged hooks:
        #   * CP0 instruction sites (MFC0/MTC0/ERET of Count, Compare, Status,
        #     Cause, EPC) found by scanning memory for their encodings,
        #   * breakpoints / stop address,
        #   * "virgin" RAM chunks executed for the first time (trigger a rescan
        #     for new CP0 sites, e.g. after the bootloader copied code to RAM).
        # Full-hook mode (hook_every_instruction=True, or when tracing /
        # verifying): the exact per-instruction _hook_code hook is installed
        # instead; used by the GUI for instruction history and by tests.
        self.hook_every_instruction = False
        # Fast mode runs Unicorn in wall-clock slices (batch_timeout_us) without
        # an instruction count: Unicorn's count mechanism calls a helper on
        # every instruction that walks the whole hook list, which with a few
        # hundred site hooks costs more than the instruction itself.  The
        # instruction count is then *estimated* from the measured rate; exact
        # (count-based) slices are used only close to an instruction limit or
        # an interrupt arming point, and for single steps.
        # Counted slices are only used before the first wall-clock slice of a
        # simulator instance (small exact budgets such as run(60000), and the
        # initial rate calibration): Unicorn flushes its whole translation
        # cache whenever the count hook is added or removed, and counted
        # slices with hundreds of site hooks have been observed to stall for
        # minutes in later phases of the firmware.
        self.batch_size = 200_000            # instructions per exact slice
        self.batch_timeout_us = 100_000      # wall time per estimated slice
        self.exact_count_threshold = 300_000
        self.calibration_slices = 2          # counted slices used to measure the rate at start
        self._insn_rate = 1e6                # instructions / second (measured by the first counted slices)
        self._counted_slices = 0
        self._timeout_slices = 0
        self.count_hz = 100_000_000          # CP0 Count rate in fast mode (emulation time based)
        # Fast-mode Count follows "emulation time": wall time spent inside
        # emu_start() only, so host work between slices (rescans, hook syncs,
        # TB flushes) does not make Count jump past the firmware's deadlines.
        # The clock is the emulation thread's CPU time ('thread', see
        # thread_clock.py): a host stall (the thread preempted) does not
        # advance Count.  'wall' uses time.perf_counter().
        self.count_clock = 'thread'
        self._clk = time.perf_counter        # clock of the current emulation thread
        self._clk_key = None                 # (native thread id, count_clock) it was made for
        self._clk_cache = None               # one clock reading per CP0 hook
        self._in_cp0_hook = False            # (taken at the hook's first use of the time)
        self._vt_accum = 0.0                 # emulation seconds of finished emu_start() calls
        self._vt_slice_t0 = None             # clock at the start of the running call
        self._vt_stop_t = None               # clock when a stop was requested in this call
        self._count_t0 = 0.0                 # emulation time at which Count was cp0_count
        # Fast-mode slices end at a deadline set by a re-armable stopper (see
        # slice_stopper.py): 'auto' (native on 64-bit Windows, else a Python
        # thread), 'native', 'python', or 'unicorn' (emu_start(timeout=), whose
        # granularity on Windows is 15-150 ms).
        self.slice_stopper = 'auto'
        self._stopper = None
        self._stopper_made = None            # slice_stopper value the current _stopper was made for
        self.min_slice_us = 200              # shortest fast-mode slice
        # Slice deadlines are enforced synchronously by every hooked CP0
        # instruction; the asynchronous stopper only fires this much later, as
        # a backstop for code without CP0 instructions (an idle `b .` loop).
        # Unicorn skips all code hooks while an asynchronous stop is pending
        # (and in a delay slot does not even exit first), so a CP0 instruction
        # reached then would run natively (mfc0 Count -> 0, eret -> ErrorEPC).
        self.async_stop_margin_us = 1000
        # While EXL is set (exception entry / exit, context switches: CP0-dense
        # code where a native ERET / MFC0 EPC would be fatal) the backstop
        # waits much longer; that code ends in a hooked ERET within ~1 ms.
        self.async_stop_margin_exl_us = 50_000
        self._slice_armed_exl = False
        self._slice_deadline = None          # perf_counter() at which hooked CP0 code ends the slice
        self.native_cp0_repairs = 0          # native MTC0 Status seen after an asynchronous stop
        # Fast mode: a hooked CP0 instruction costs ~10 us of host time (~50 us
        # before), which Count sees.  A tick handler can take longer than a short
        # timer period, and every ERET would find the next tick due: the
        # interrupted code would never run again.  After an ERET the guest runs
        # at least this long before the next timer/software interrupt.
        self.irq_min_gap_us = 200
        self._last_eret_vt = -1e9            # emulation time of the last ERET
        self._slice_cap_end = None           # emulation time at which the running slice must end
        self._slice_planned_end = None       # ... and at which it is planned to end (timer)
        self._slice_armed_end = None         # ... and at which the stopper is armed now
        self._slice_uses_stopper = False
        self._step_full_hook = False         # _exec_one(): force the exact hook for one step
        self.rescan_interval = 1_000_000     # periodic RAM rescan for new CP0 sites (instructions)
        self._rom_sites = set()
        self._rom_sites_dirty = True
        self._rom_sites_hooked = False       # the flash's sites are in _cp0_site_hooks
        self._vector_page = None             # (page, its bytes) when the tick's vector page was last scanned
        self._scanned_ram_chunks = {}        # (phys, length) -> bytes when last scanned for CP0 sites
        self._delay_slot_words = {None: False}  # word before a CP0 site -> it has a delay slot
        self._code_hook_h = None
        self._cp0_site_hooks = {}            # address -> hook handle
        self._bp_hooks = {}                  # address -> hook handle
        self._virgin_hooks = {}              # chunk base -> hook handle
        self._idle_loops = {}                # idle loop address -> hook handle (idle_skip)
        self._poll_loops = {}                # mailbox poll address -> hook handle (poll_skip)
        self._irq_enable_sites = set()       # CP0 sites hooked by _hook_irq_enable
        self.poll_skipped = 0.0              # emulation time mailbox polls skipped (seconds)
        self.idle_skipped = 0.0              # emulation time idle_skip moved on (seconds)
        self.busy_pending = 0.0              # emulation time still owed for work done in Python
        self._lzma_hooks = {}                # LzmaDecode() entry -> hook handle (_hook_lzma)
        self.lzma_decodes = []               # (entry, input, output address, output size) per decode
        self._delay_hooks = {}               # the RTOS's delay() entry -> its hooks (_hook_delay, _hook_delay_loop)
        self._delay_routines = {}            # ... -> (its code, the clock's gp offset, its get_count(), its build)
        self._delay_code_views = {}          # ... -> RAM memoryview slice of its code (when in RAM)
        self._delay_loops = {}               # its loop's get_count() call -> its entry
        self._sflash_read_hooks = {}         # sflash_read() entry -> hook handle (_hook_sflash_read)
        self._sflash_read_views = {}         # ... -> RAM memoryview slice of its prologue
        self.delay_calls = 0                 # delay() calls returned from at their entry
        self.delay_jumps = 0                 # time moves in their loops (longer waits)
        self.delay_skipped = 0.0             # the emulation time both moved on (seconds)
        self._slice_jumped = 0.0             # emulation time those moved on since the slice's deadline was armed
        self._slice_delayed = 0.0            # ... and in the last slice
        self._run_max_vtime = None           # run()'s max_vtime, for _hook_idle_loop
        self._rescan_due = False
        self._last_rescan_icount = -1
        self._tb_flush_needed = False
        # CP0 Count: value `cp0_count` as of instruction `_count_icount`, plus
        # 2 ticks per instruction since then (real MIPS: Count += 1 every 2 cycles)
        # and a small step per read so polling loops progress inside a batch.
        self._count_icount = 0
        self._count_reads = 0

        # SPI Flash Controller emulation (matches flash_raw_sl_c.c)
        # Hardware registers:
        #   SF_INS (+0x98) = command/instruction register
        #   SF_FMT (+0x99) = format register (which SPI bus phases are active)
        #   SF_DUM (+0x9A) = dummy/data register
        #   SF_CFG (+0x9B) = configuration register
        # SF_FMT bit flags:
        #   0x01 SF_HIT_DATA  - data phase active
        #   0x02 SF_HIT_DUMM  - dummy cycle active
        #   0x04 SF_HIT_ADDR  - address phase active
        #   0x08 SF_HIT_CODE  - command/opcode phase active
        #   0x40 SF_CONT_RD   - continuous read mode
        #   0x80 SF_CONT_WR   - continuous write mode
        # Winbond W25Qxx; the capacity byte follows the flash size (0x16 = 4 MB W25Q32,
        # 0x17 = 8 MB W25Q64), both in the drivers' device tables
        self._spi_jedec_id = [0xEF, 0x40, self.rom_size.bit_length() - 1]
        self._spi_ins = 0x03       # SF_INS: current SPI command (default: normal read)
        self._spi_fmt = 0x0D       # SF_FMT: default = HIT_CODE|HIT_ADDR|HIT_DATA (normal read)
        self._spi_dum = 0x00       # SF_DUM: dummy/data register
        self._spi_cfg = 0x00       # SF_CFG: config register
        self._spi_stream = None    # a chip family's byte-stream mode of the flash window (chips/m3821.py)
        self._spi_status = 0x00    # Flash status register (bit0=WIP, bits[5:2]=BP)
        self._spi_wel = False      # Write Enable Latch
        self._spi_response = []    # queued response bytes for memory-mapped reads
        self._spi_resp_idx = 0     # current read index into response
        self._last_flash_read_page = -1  # for throttled flash read logging

        # Pristine flash contents.  Guest stores into the memory-mapped flash
        # window (SPI command triggers, page-program data) and the SPI response
        # bytes injected by the read hooks all land in the ROM buffer; they are
        # undone by _rom_restore() right after the access, so the ROM image only
        # changes through emulated flash program/erase commands.
        self.rom_image = bytearray(self.rom_size)
        self._rom_dirty = []       # [(offset, size)] ROM ranges to restore

        # Last hooked instruction (size / address), kept for diagnostics.
        self._last_hook_size = 0
        self._last_hook_addr = 0

        self._init_unicorn()
        self._init_capstone()
        # The chip family (chips/): its chip ID, boot flow and devices on top of
        # the common ones; loadFile() switches to the family of the image it
        # loads (_switch_family), which starts again from the common devices.
        # A second core is no chip of its own: the first core's flash image and
        # family devices stay theirs (its stub family only names its code).
        self._common_devices = self._device_tables()
        if self._shared is not None:
            self.rom_image = self._shared.rom_image
            self.chip = chips.see.SeeCoreFamily(self)
        else:
            self.chip = chips.M3801(self)
            self.chip.install()


        self.gpr_map = [
            UC_MIPS_REG_ZERO, UC_MIPS_REG_AT, UC_MIPS_REG_V0, UC_MIPS_REG_V1,
            UC_MIPS_REG_A0, UC_MIPS_REG_A1, UC_MIPS_REG_A2, UC_MIPS_REG_A3,
            UC_MIPS_REG_T0, UC_MIPS_REG_T1, UC_MIPS_REG_T2, UC_MIPS_REG_T3,
            UC_MIPS_REG_T4, UC_MIPS_REG_T5, UC_MIPS_REG_T6, UC_MIPS_REG_T7,
            UC_MIPS_REG_S0, UC_MIPS_REG_S1, UC_MIPS_REG_S2, UC_MIPS_REG_S3,
            UC_MIPS_REG_S4, UC_MIPS_REG_S5, UC_MIPS_REG_S6, UC_MIPS_REG_S7,
            UC_MIPS_REG_T8, UC_MIPS_REG_T9, UC_MIPS_REG_K0, UC_MIPS_REG_K1,
            UC_MIPS_REG_GP, UC_MIPS_REG_SP, UC_MIPS_REG_FP, UC_MIPS_REG_RA
        ]
        self._calibrate_gpr_view()

    @staticmethod
    def _new_mips_uc():
        import faulthandler
        mu = Uc(UC_ARCH_MIPS, UC_MODE_MIPS32 + UC_MODE_LITTLE_ENDIAN)
        mu.ctl_set_cpu_model(UC_CPU_MIPS32_74KF)
        fh = faulthandler.is_enabled()
        if fh:
            faulthandler.disable()
        try:
            mu.reg_read(UC_MIPS_REG_PC)
        finally:
            if fh:
                faulthandler.enable()
        return mu

    def _init_unicorn(self):
        import gc
        gc.collect()
        # Initialize Unicorn (MIPS32 + Little Endian, 24Kf CPU model)
        self.mu = self._new_mips_uc()
        
        import ctypes
        
        # No UC_HOOK_MEM_READ / UC_HOOK_MEM_WRITE hooks in normal operation:
        # while one such hook exists, whatever its range, Unicorn translates
        # every load (store) to its slow path, which scans the whole hook list
        # per access (decided per translation block when it is translated).
        # With the ~60 device hooks this used to have, RAM loads / stores ran
        # ~3x slower (dump_maciej's LZMA bootloader: ~200 s of emulation
        # instead of ~64 s).  Instead the device registers are an mmio_map
        # region (Python is called only for accesses to it), the flash window
        # is write-protected (stores to it fault into a hook), and the flash
        # read hook exists only around SPI command mode (see
        # _update_flash_read_hooks).
        # Memory hooks and protection faults report physical addresses, and
        # the guest only ever reaches the physical mappings (kseg0 / kseg1
        # translate to physical; kuseg is mapped 1:1 under the forced ERL),
        # so the 0x8.../0x9.../0xA.../0xB... mappings below are views for
        # Python (mem_read(0xB8000030), mem_write(base_addr, ...)).

        # Shared ROM Buffer (Usually 4MB dumped flash)
        self.rom_buffer = self._buffer('rom_buffer', self.rom_size)
        self._rom_view = memoryview(self.rom_buffer).cast('B')
        self._spi_status_injected = False

        # Map ROM aliases to the same buffer
        # Ali SoCs commonly map flash repeatedly within a 16MB window
        self.log(f"Mapping Shared ROM mirrors in 16MB window for Phys, KSEG0, KSEG1")
        # 0x0F000000 is the ALi flash window (KSEG0 0x8F..., KSEG1 0xAF...).
        # 0x1F000000 (KSEG1 0xBF...) holds the MIPS reset/BEV exception vectors
        # (0xBFC00000 / 0xBFC00380) which the chip also decodes to the flash.
        # The physical windows the guest uses are read-only: a store to them
        # (an SPI command trigger / page program data) faults into
        # _hook_flash_write_prot, which emulates it and lets it land.
        # A flash larger than 4 MB shows its 4 MB segments below the
        # 0x..C00000 slot (see _flash_offset), so each slot maps its segment.
        slot = min(self.rom_size, 0x400000)
        flash_phys = (0x1F000000,) if self._upper_ram_mapped else (0x0F000000, 0x1F000000)
        for offset in range(0, 0x01000000, slot):
            for phys in flash_phys:
                for seg in (0x00000000, 0x80000000, 0xA0000000):
                    base = seg + phys + offset
                    try:
                        self._map_flash_mirror(base, slot)
                    except Exception as e:
                        self.log(f"Warning: Failed to map ROM mirror at {hex(base)}: {e}")
        self._map_flash_linear_tail()

        # Shared RAM Buffer (128MB default, up to 256MB on C3505 boards)
        self.ram_buffer = self._buffer('ram_buffer', self.ram_size)
        ram_ptr = ctypes.addressof(self.ram_buffer)
        low_ram = min(self.ram_size, 0x0F000000)
        
        # Map RAM aliases to same buffer
        self.log(f"Mapping Shared RAM at 0x80000000, 0xA0000000, 0x00000000")
        self.mu.mem_map_ptr(0x80000000, low_ram, UC_PROT_ALL, ram_ptr)
        self.mu.mem_map_ptr(0xA0000000, low_ram, UC_PROT_ALL, ram_ptr)
        self.mu.mem_map_ptr(0x00000000, low_ram, UC_PROT_ALL, ram_ptr)
        if self._upper_ram_mapped and self.ram_size > 0x0F000000:
            upper_sz = min(self.ram_size, 0x10000000) - 0x0F000000
            for seg in (0x80000000, 0xA0000000, 0x00000000):
                self.mu.mem_map_ptr(seg + 0x0F000000, upper_sz, UC_PROT_ALL, ram_ptr + 0x0F000000)
        self._init_fast_access()
        # kuseg 1:1 through a wired TLB entry and the guest's own native Status,
        # or (without it) the forced ERL (see native_status)
        self.force_erl = not (self.native_status and self._setup_kuseg_tlb())
        self._site_words = self._CP0_WORDS - ({0x40006000} if not self.force_erl else set())
        self._site_word_array = None

        # Map MMIO: one shared register buffer.  The guest reaches it at the
        # physical 0x18000000 (from any segment), an mmio_map region whose
        # callbacks dispatch to the device handlers registered with _mmio_on
        # and otherwise read / write the buffer like RAM.  0x98000000 /
        # 0xB8000000 map the same buffer for Python (no side effects).
        MMIO_SIZE = 0x01000000
        self.mmio_buffer = self._buffer('mmio_buffer', MMIO_SIZE)
        self._mmio_view = memoryview(self.mmio_buffer).cast('B')    # (handlers read it in place: _mmio_word)
        self._mmio_words = self._mmio_view.cast('I') if sys.byteorder == 'little' else None
        self._mmio_halfwords = self._mmio_view.cast('H') if sys.byteorder == 'little' else None
        mmio_ptr = ctypes.addressof(self.mmio_buffer)
        self._mmio_rd = {}          # offset -> [handler]: reads starting at that offset
        self._mmio_wr = {}          # offset -> [handler]: writes starting at that offset
        self._mmio_observers = []   # add_mmio_hook() callbacks
        for base, name in [(0x98000000, "KSEG0 view"), (0xB8000000, "KSEG1 view")]:
            try:
                self.mu.mem_map_ptr(base, MMIO_SIZE, UC_PROT_ALL, mmio_ptr)
                self.log(f"Mapped {name} of the peripherals at {hex(base)} (shared)")
            except UcError as e:
                self.log(f"Warning: {name} at {hex(base)} - {e}")
        self.mu.mmio_map(0x18000000, MMIO_SIZE, self._mmio_read, None, self._mmio_write, None)

        # TX is synchronous: both the holding and shift registers are empty.
        self.mu.mem_write(0xB8018305, b'\x60')
        # (the chip ID at 0xB8000002 is the chip family's: chips/)

        # Hooks
        self.mu.hook_add(UC_HOOK_MEM_UNMAPPED | UC_HOOK_MEM_FETCH_PROT | UC_HOOK_MEM_READ_PROT,
                         self._hook_mem_invalid)
        self.mu.hook_add(UC_HOOK_MEM_WRITE_PROT, self._hook_flash_write_prot)

        # Device registers (offsets in the 0x18000000 window, any segment)
        # UART: THR writes (TX), LSR / URBR / UIIR / URFC reads (RX simulation)
        self._mmio_on('w', self._hook_uart_write, 0x18300, 0x18305)
        self._mmio_on('r', self._hook_uart_read, 0x18300, 0x18312)
        # GPIO DO and DIR writes for I2C / panel decoding, DI reads loop DO back
        for gpio_off in self._GPIO_DO_OFFSETS:  # 0x054, 0x0D4, 0x0F4, 0x354, 0x454 and 0x0E8
            self._mmio_on('w', self._hook_gpio_write, gpio_off, gpio_off + 7)
        for di_off in self._GPIO_DI_TO_DO:      # DO - 4
            self._mmio_on('r', self._hook_gpio_di_read, di_off, di_off + 3)
        # Device operations the applications start and then poll for completion
        # (see _hook_selfcomplete_read): PMU 0x18018D02, VCAP 0x1800F04B
        for reg in self._SELF_COMPLETING:
            self._mmio_on('r', self._hook_selfcomplete_read, reg & ~3, reg)
        # Video engine status words the decoder driver checks after a VE reset
        for reg in self._VE_STATUS_REGS:
            self._mmio_on('r', self._hook_ve_status_read, reg, reg + 3)
        # The chip ID word (0xB8000000, ChipFamily.write_chip_id) is read-only
        self._mmio_on('w', self._hook_chip_id_store, 0x0000, 0x0003)
        # Graphics engine command / interrupt status (_hook_ge_write) and the
        # interrupt controller status the modelled lines show up in
        self._mmio_on('w', self._hook_ge_write, 0xA004, 0xA00B)
        self._mmio_on('r', self._hook_ge_read, 0xA008, 0xA00B)
        self._mmio_on('r', self._hook_ic_status_read, self.ic_base, self.ic_base + 7)
        # Ethernet MAC ("ETHERNET_MAC_0", 0xB802C000; the Ferguson Ariva T650i's
        # network driver): bit 3 of +0 is a software reset the driver sets and
        # polls until the MAC clears it (_hook_mac_reset_read); +0x7C starts an
        # MDIO (PHY management) access and +0x82 returns its data
        # (_hook_mac_mdio_read)
        self._mmio_on('r', self._hook_mac_reset_read, 0x2C000, 0x2C000)
        self._mmio_on('r', self._hook_mac_mdio_read, 0x2C07C, 0x2C07F)
        # IR receiver controller: FIFO count +1, interrupt status +7, RLC data +8
        self._mmio_on('r', self._hook_irc_read, 0x18101, 0x18101)
        self._mmio_on('r', self._hook_irc_read, 0x18107, 0x18108)
        self._mmio_on('w', self._hook_irc_write, 0x18107, 0x18107)
        # SPI flash controller: both register bases, 0xB8000098 (default) and
        # 0xB802E098 (M3329E rev>=5), each SF_INS(+0x98), SF_FMT(+0x99),
        # SF_DUM(+0x9A), SF_CFG(+0x9B).  Reads return the bytes stored in
        # _mmio_view directly (initialised here and kept in sync on writes).
        for base in (0x00098, 0x2E098):
            self._mmio_on('w', self._hook_spi_write, base, base + 3)
            self._mmio_view[base:base + 4] = b'\x03\x0d\x00\x00'
        # The hardware I2C masters the tuner / EEPROM drivers use (i2c_scb.py):
        # the slaves are sim.i2c_devices, none answers unless sim.i2c_ack_all
        # (a second core's are the first one's: one bus, the board's chips on it)
        import i2c_scb
        import smc_m36
        self.i2c_devices = self._shared.i2c_devices if self._shared else {}
        self.i2c_ack_all = False
        self._demod_address = None          # where attach_demod put the loaded board's demodulator
        self._demod_device = None
        self.i2c_masters = [i2c_scb.I2cMaster(self, base, f"SCB{i}") for i, base in enumerate(self.I2C_SCB_BASES)]
        self.smc = smc_m36.SmartCard(self)

        # SPI flash memory-mapped data (SYS_FLASH_BASE_ADDR, the physical
        # 0x0F000000 / 0x1F000000 windows; the firmware uses both 0xAFC00000
        # and 0x0FC00000).  Stores fault into _hook_flash_write_prot; the read
        # hook is only installed around SPI command mode (or with
        # setSPIDump(True, flash_reads=True)), see _update_flash_read_hooks.
        self._flash_windows = [0x1F000000] if self._upper_ram_mapped else [0x0F000000, 0x1F000000]
        # A chip family's own flash device takes the stores to them instead (a
        # parallel flash: parallel_flash.py)
        self.flash_device = None
        self._flash_read_hooks = []
        self._flash_hooks_pending = False
        self._spi_cmd_vt = -1e9               # emulation time of the last SPI command mode
        self._spi_dump_flash_reads = False
        self.flash_hook_changes = 0           # flash read hook installs / removals (each flushes the TBs)
        self._update_flash_read_hooks()

        # Jumps to address 0 (NULL function pointers, end of a test program)
        # stop emulation instead of executing RAM as code.
        self.mu.hook_add(UC_HOOK_CODE, self._hook_null_jump, begin=0, end=3)
        # 0x80000200..0x80000FFF: a code hook while it holds the SDK's zero
        # padding (_update_short_block_hook), plus any 350+ instruction
        # branchless code blocks in RAM (_find_long_blocks)
        self._short_block_hook = None
        self._short_block_hooks = {}
        self._long_block_hooks = {}

        # The per-instruction hook (_hook_code) and the fast-mode hooks are
        # installed on demand by _sync_hooks() (see run()).
        # Intercept emu_stop() so run() can tell a stop requested by user code
        # or the GUI from a batch that simply ran its instruction count.
        raw_emu_stop = self.mu.emu_stop
        def _timed_emu_stop():
            # Emulation time (Count) ends when a stop is requested: what follows
            # (the requesting hook's rescan, Unicorn's shutdown) is host work.
            # Only on the emulation thread: another thread's reading of its clock
            # would be stale (and could even belong to the previous slice).
            if self._vt_slice_t0 is not None and self._vt_stop_t is None and                     self._clk_key is not None and threading.get_native_id() == self._clk_key[0]:
                self._vt_stop_t = self._clk()
            raw_emu_stop()
        self._orig_emu_stop = _timed_emu_stop
        def _emu_stop_wrapper():
            if self._stop_reason is None:
                self._stop_reason = 'external'
            if self._in_run and threading.get_ident() != self._run_tid:
                self._external_stop = True  # a pause from another thread (GUI): run() returns
            elif self._dev_cb_depth == 0 and self._vt_slice_t0 is not None and \
                    self._clk_key is not None and threading.get_native_id() == self._clk_key[0]:
                # Requested on the emulation thread outside a device access (a
                # code hook: breakpoint, GUI / user pause): the CPU stops before
                # the next instruction, nothing is rewound (see _dev_note).
                self._dev_last = None
            self._orig_emu_stop()
        self.mu.emu_stop = _emu_stop_wrapper
        # Account the time spent inside every emu_start() (run(), single steps
        # and test scripts that call it directly) as emulation time for Count.
        self._orig_emu_start = self.mu.emu_start
        def _emu_start_wrapper(*args, **kwargs):
            # Memory remaps and flash read hook changes happen here, never while the CPU runs
            if self._upper_ram_pending is not None:
                self._apply_upper_ram_map(self._upper_ram_pending)
            if self._flash_hooks_pending or (self._flash_read_hooks and not self._flash_hooks_wanted()):
                self._apply_flash_hooks()
            self._setup_clock()
            self._vt_stop_t = None
            self._dev_last = None
            self._vt_slice_t0 = self._clk()
            try:
                return self._orig_emu_start(*args, **kwargs)
            finally:
                if self._ds_flags_stale:
                    self._clear_branch_flags()
                end = self._clk()
                if self._vt_stop_t is not None:
                    end = min(end, self._vt_stop_t)
                self._vt_accum += max(0.0, end - self._vt_slice_t0)
                self._vt_slice_t0 = self._vt_stop_t = None
                # An asynchronous stop (stopper, timeout, GUI pause; not a counted
                # run or a hook's own stop) that left the PC on the last device
                # access: that instruction runs again on resume (see _dev_note).
                # (A counted run that simply ran out stops before an instruction:
                # no replay.  An explicit emu_stop() is 'external' in any run.)
                # ('flashhooks': requested inside an SF_INS store, which then
                # re-executes like after an asynchronous stop)
                count = kwargs.get('count', args[3] if len(args) > 3 else 0)
                last = self._dev_last
                if last is not None and (self._stop_reason in ('external', 'flashhooks') or
                                         (self._stop_reason is None and not count)):
                    try:
                        # Rewound onto the access, not stopped before a later pass
                        # of it: the instruction at the (exact) stop PC is a load /
                        # store of that address, it lies in the translation block
                        # the access ran in, and the registers are unchanged (a
                        # load's destination is written only after the exit
                        # check).  The access itself cannot tell its PC: in an
                        # mmio_map callback Unicorn's PC is the start of the
                        # translation block (last[4]).
                        pc = self._reg_read(UC_MIPS_REG_PC)
                        if (last[3] is None or self._gpr_snapshot() == last[3]) and \
                                self._phys(self._insn_mem_address(pc)) == self._phys(last[1]) and \
                                (pc == last[4] if last[5] else self._same_block(last[4], pc)):
                            if len(self._dev_replays) >= 16:      # stale entries: drop the oldest
                                self._dev_replays.pop(next(iter(self._dev_replays)))
                            # keyed by (PC, SP): an interrupt handler or another task
                            # running the same code must not take this entry.  On
                            # resume the rewound instruction starts a translation
                            # block, so its access sees this PC (_dev_replay_of).
                            key = (pc, self._reg_read(UC_MIPS_REG_SP))
                            self._dev_replays[key] = last[0:3]
                    except UcError:
                        pass
                if self._upper_ram_pending is not None:
                    self._apply_upper_ram_map(self._upper_ram_pending)
        self.mu.emu_start = _emu_start_wrapper

        # CP0 Status configuration
        try:
            status = 0x10400000 # CU0=1, BEV=1
            self._write_native_status(self.mu, status)
            self.log(f"Set CP0 Status = 0x{status:08X}")
        except Exception as e:
            self.log(f"Warning: Could not set CP0 Status: {e}")

        self._calibrate_hflags()

    # The firmwares address peripherals and the flash window through kuseg
    # (0x18000058, 0x0FC00000) as if it were identity mapped.  QEMU maps kuseg
    # 1:1 only while Status.ERL is set, so the simulator forced ERL into the
    # native Status (force_erl) -- and had to emulate every MFC0 / MTC0 Status,
    # whose native result would show it: in the RTOS's interrupt disable and
    # enable alone, half of all the hooked CP0 instructions.  With native_status
    # a wired TLB entry -- two 256 MB pages, physical 0x00000000 and
    # 0x10000000, uncached, global -- maps kuseg's lower 512 MB 1:1 instead
    # (none of the firmwares writes the TLB) and the native Status is the
    # guest's own: MFC0 Status runs natively (it is not a CP0 site), the hook
    # of MTC0 Status only follows the write unless the slice must end there
    # (_emulate_cop0), and the run loop takes the native Status over at each
    # slice boundary.  An ERET that runs natively (its hook skipped under an
    # asynchronous stop) goes to the native EPC, which nothing writes, 0:
    # run() redoes it (as it did with ErrorEPC under the forced ERL).
    native_status = True

    def _setup_kuseg_tlb(self):
        """Install the wired TLB entry that maps kuseg 1:1 (a stub run once on
        a scratch page) and check it: a kuseg load with ERL clear reads RAM.
        False if that cannot be done (the forced ERL stays)."""
        import struct
        page = 0x0EFFF000                   # (physical; below the 0x0F000000 flash window)
        in_ram = self._mapped_ram_size > page
        mu = self.mu

        def li(v):
            return [0x3C080000 | (v >> 16), 0x35080000 | (v & 0xFFFF)]        # lui / ori t0

        def mtc0(rd):
            return 0x40880000 | rd << 11                                     # mtc0 t0, rd

        def entry_lo(pa):
            return ((pa >> 12) << 6) | (2 << 3) | 0x7                        # PFN, uncached, D, V, G

        install = (li(0x1FFFE000) + [mtc0(5)] + li(0) + [mtc0(10)] + li(entry_lo(0)) + [mtc0(2)] +
                   li(entry_lo(0x10000000)) + [mtc0(3)] + li(0) + [mtc0(0)] + li(1) + [mtc0(6)] +
                   [0x42000002, 0])                                          # tlbwi
        check = [0x3C090000, 0x8D2A0000, 0]                                  # lui t1, 0; lw t2, 0(t1)
        saved = [mu.reg_read(r) for r in (UC_MIPS_REG_T0, UC_MIPS_REG_T1, UC_MIPS_REG_T2, UC_MIPS_REG_PC)]
        saved_ram = bytes(self._ram_view[page:page + 64]) if in_ram else None
        ok = False
        try:
            if not in_ram:
                mu.mem_map(page, 0x1000)
            for code, status in ((install, 0x10400004), (check, 0x10400000)):
                mu.mem_write(page, struct.pack(f"<{len(code)}I", *code))
                mu.ctl_flush_tb()
                mu.reg_write(UC_MIPS_REG_CP0_STATUS, status)
                mu.emu_start(0x80000000 | page, (0x80000000 | page) + 4 * len(code), count=len(code))
            ok = mu.reg_read(UC_MIPS_REG_T2) == int.from_bytes(self._ram_view[0:4], 'little')
        except UcError as e:
            self.log(f"Warning: the kuseg TLB entry could not be set up ({e}); forcing Status.ERL")
        finally:
            if in_ram:
                self._ram_view[page:page + 64] = saved_ram
            else:
                try:
                    mu.mem_unmap(page, 0x1000)
                except UcError:
                    pass
            mu.ctl_flush_tb()
            for r, v in zip((UC_MIPS_REG_T0, UC_MIPS_REG_T1, UC_MIPS_REG_T2, UC_MIPS_REG_PC), saved):
                mu.reg_write(r, v)
        return ok

    def _buffer(self, name, size):
        """A memory buffer the Unicorn mappings point into: a second core's is the
        first core's (share_memory_with)."""
        import ctypes
        return getattr(self._shared, name) if self._shared else ctypes.create_string_buffer(size)

    def _init_fast_access(self):
        """What the fast-mode CP0 hooks read and write many times a second goes
        around the Unicorn binding, whose reg_read / reg_write / mem_read build
        ctypes objects per call (2.6-3.5 us each, against ~1 us for the C call):
        _reg_read / _reg_write call uc_reg_read / uc_reg_write with one
        preallocated value (GPRs, PC and CP0 Status: 32-bit registers), and
        _ram_words views the RAM buffer that kuseg, KSEG0 and KSEG1 map, as
        little-endian words (None on a big-endian host)."""
        import ctypes
        mu = self.mu
        try:
            u_mod = sys.modules[type(mu).__module__]
            lib = u_mod.uclib
            uch, val = mu._uch, ctypes.c_uint64()
            ref, c_write, c_read = ctypes.byref(val), lib.uc_reg_write, lib.uc_reg_read

            def reg_write(reg, value):
                if reg == UC_MIPS_REG_ZERO:
                    return          # $zero stays 0: Unicorn lets a write land in QEMU's
                                    # gpr[0], which nothing resets (the live-env path
                                    # skips it too; the hooked `mfc0 $zero, Count` hit this)
                val.value = value
                err = c_write(uch, reg, ref)
                if err:
                    raise UcError(err)

            def write_pc(value, _uch=uch, _val=val, _ref=ref, _cw=c_write):
                _val.value = value
                err = _cw(_uch, 1, _ref)
                if err:
                    raise UcError(err)

            def reg_read(reg):
                err = c_read(uch, reg, ref)
                if err:
                    raise UcError(err)
                return val.value & 0xFFFFFFFF

            self._c_reg_io = (uch, val, ref, c_read, c_write)
            self._reg_write, self._reg_read = reg_write, reg_read
            self._write_pc = write_pc

            HOOK_CODE_CFUNC = u_mod.HOOK_CODE_CFUNC
            MMIO_READ_CFUNC = u_mod.MMIO_READ_CFUNC
            MMIO_WRITE_CFUNC = u_mod.MMIO_WRITE_CFUNC
            do_hook_add = mu._Uc__do_hook_add
            orig_hook_add = mu.hook_add
            orig_mmio_map = mu.mmio_map
            cfunc_cache = {}
            noop_fn = self._hook_short_blocks
            irq_en_fn = self._hook_irq_enable
            cp0_fn = self._hook_cp0_site
            direct_fns = {
                cp0_fn,
                self._hook_code,
                self._hook_delay,
                self._hook_delay_loop,
                self._hook_idle_loop,
                self._hook_poll_loop,
            }

            def fast_hook_add(htype, callback, user_data=None, begin=1, end=0, *args, **kwargs):
                if htype == UC_HOOK_CODE and user_data is None and not args and not kwargs:
                    fptr = cfunc_cache.get(callback)
                    if fptr is None:
                        if callback == noop_fn:
                            def cb(handle, address, size, key):
                                pass
                            fptr = ctypes.cast(HOOK_CODE_CFUNC(cb), HOOK_CODE_CFUNC)
                        elif callback == irq_en_fn:
                            def cb(handle, address, size, key, _self=self, _mu=mu,
                                   _perf=time.perf_counter, _cp0=cp0_fn):
                                if (_self.cp0_status & 0x7) == 0x1 and not _self.breakpoints \
                                        and _self._stop_instr is None and not _self._rom_dirty:
                                    dl = _self._slice_deadline
                                    if dl is None or _perf() < dl:
                                        return
                                _cp0(_mu, address, size, None)
                            fptr = ctypes.cast(HOOK_CODE_CFUNC(cb), HOOK_CODE_CFUNC)
                        elif callback in direct_fns:
                            fptr = ctypes.cast(HOOK_CODE_CFUNC(callback), HOOK_CODE_CFUNC)
                        else:
                            def cb(handle, address, size, key, _fn=callback, _mu=mu):
                                try:
                                    _fn(_mu, address, size, None)
                                except BaseException as e:
                                    if _mu._hook_exception is None:
                                        _mu._hook_exception = e
                                    _mu.emu_stop()
                            fptr = ctypes.cast(HOOK_CODE_CFUNC(cb), HOOK_CODE_CFUNC)
                        cfunc_cache[callback] = fptr
                    return do_hook_add(htype, fptr, begin, end)
                return orig_hook_add(htype, callback, user_data, begin, end, *args, **kwargs)

            def fast_mmio_map(address, size, read_cb, read_ud, write_cb, write_ud):
                if read_cb is not None and write_cb is not None and read_ud is None and write_ud is None:
                    if read_cb == self._mmio_read and write_cb == self._mmio_write and self._mmio_words is not None:
                        _rd = self._mmio_rd
                        _wr = self._mmio_wr
                        _obs = self._mmio_observers
                        _v1 = self._mmio_view
                        _v2 = self._mmio_halfwords
                        _v4 = self._mmio_words
                        def r_cb(handle, offset, sz, key, _self=self, _fn=read_cb, _mu=mu,
                                 _rd=_rd, _obs=_obs, _v1=_v1, _v2=_v2, _v4=_v4):
                            if not _obs:
                                _self._dev_last = None
                                if offset in _rd:
                                    _self._dev_cb_depth += 1
                                    try:
                                        addr = 0xB8000000 | offset
                                        for h in _rd[offset]:
                                            h(_mu, UC_MEM_READ, addr, sz, 0, None)
                                    except BaseException as e:
                                        if _mu._hook_exception is None:
                                            _mu._hook_exception = e
                                        _mu.emu_stop()
                                        return 0
                                    finally:
                                        _self._dev_cb_depth -= 1
                                if sz == 1:
                                    return _v1[offset]
                                if sz == 4 and not (offset & 3):
                                    return _v4[offset >> 2]
                                if sz == 2 and not (offset & 1):
                                    return _v2[offset >> 1]
                                return int.from_bytes(_v1[offset:offset + sz], 'little')
                            try:
                                return _fn(_mu, offset, sz, None)
                            except BaseException as e:
                                if _mu._hook_exception is None:
                                    _mu._hook_exception = e
                                _mu.emu_stop()
                                return 0
                        def w_cb(handle, offset, sz, value, key, _self=self, _fn=write_cb, _mu=mu,
                                 _wr=_wr, _obs=_obs, _v1=_v1, _v2=_v2, _v4=_v4):
                            if not _obs:
                                _self._dev_last = None
                                if offset in _wr:
                                    value &= (1 << (8 * sz)) - 1
                                    _self._dev_cb_depth += 1
                                    try:
                                        addr = 0xB8000000 | offset
                                        for h in _wr[offset]:
                                            stored = h(_mu, UC_MEM_WRITE, addr, sz, value, None)
                                            if stored is not None:
                                                value = stored
                                    except BaseException as e:
                                        if _mu._hook_exception is None:
                                            _mu._hook_exception = e
                                        _mu.emu_stop()
                                        return
                                    finally:
                                        _self._dev_cb_depth -= 1
                                if sz == 1:
                                    _v1[offset] = value & 0xFF
                                    return
                                if sz == 4 and not (offset & 3):
                                    _v4[offset >> 2] = value & 0xFFFFFFFF
                                    return
                                if sz == 2 and not (offset & 1):
                                    _v2[offset >> 1] = value & 0xFFFF
                                    return
                                mask = (1 << (8 * sz)) - 1
                                _v1[offset:offset + sz] = (value & mask).to_bytes(sz, 'little')
                                return
                            try:
                                _fn(_mu, offset, sz, value, None)
                            except BaseException as e:
                                if _mu._hook_exception is None:
                                    _mu._hook_exception = e
                                _mu.emu_stop()
                    else:
                        def r_cb(handle, offset, sz, key, _fn=read_cb, _mu=mu):
                            try:
                                return _fn(_mu, offset, sz, None)
                            except BaseException as e:
                                if _mu._hook_exception is None:
                                    _mu._hook_exception = e
                                _mu.emu_stop()
                                return 0
                        def w_cb(handle, offset, sz, value, key, _fn=write_cb, _mu=mu):
                            try:
                                _fn(_mu, offset, sz, value, None)
                            except BaseException as e:
                                if _mu._hook_exception is None:
                                    _mu._hook_exception = e
                                _mu.emu_stop()
                    r_fptr = ctypes.cast(MMIO_READ_CFUNC(r_cb), MMIO_READ_CFUNC)
                    w_fptr = ctypes.cast(MMIO_WRITE_CFUNC(w_cb), MMIO_WRITE_CFUNC)
                    err = lib.uc_mmio_map(uch, address, size, r_fptr, 0, w_fptr, 0)
                    if err:
                        raise UcError(err)
                    mu._mmio_callbacks[(address, address + size)] = (r_fptr, w_fptr)
                    return
                return orig_mmio_map(address, size, read_cb, read_ud, write_cb, write_ud)

            mu.hook_add = fast_hook_add
            mu.mmio_map = fast_mmio_map
        except Exception:                    # another binding: its own calls
            self._reg_write = lambda reg, value, _rw=mu.reg_write: None if reg == UC_MIPS_REG_ZERO else _rw(reg, value)
            self._reg_read = mu.reg_read
            self._write_pc = lambda v, _rw=mu.reg_write: _rw(UC_MIPS_REG_PC, v)
        self._ram_view = memoryview(self.ram_buffer).cast('B')
        self._ram_words = self._ram_view.cast('I') if sys.byteorder == 'little' else None
        self._ram_halfwords = self._ram_view.cast('H') if sys.byteorder == 'little' else None
        self._ram_words_len = (self._mapped_ram_size >> 2) if self._ram_words is not None else 0
        self._rom_words = self._rom_view.cast('I') if sys.byteorder == 'little' else None
        self._rom_halfwords = self._rom_view.cast('H') if sys.byteorder == 'little' else None
        self._m32_traits = {}
        self._m16_traits = {}

    def _mmio_word(self, address):
        """The device register word at address (any view of the window, word
        aligned down) from its buffer: no device side effect, no binding call."""
        if self._mmio_words is not None:
            return self._mmio_words[(address & 0xFFFFFF) >> 2]
        off = address & 0xFFFFFC
        return int.from_bytes(self._mmio_view[off:off + 4], 'little')

    def _mmio_write_word(self, address, value):
        """Write a 32-bit word into the device register buffer at address (word
        aligned down) without a Unicorn C-API call."""
        if self._mmio_words is not None:
            self._mmio_words[(address & 0xFFFFFF) >> 2] = value & 0xFFFFFFFF
        else:
            off = address & 0xFFFFFC
            self._mmio_view[off:off + 4] = (value & 0xFFFFFFFF).to_bytes(4, 'little')

    def _init_capstone(self):
        self._md = None

    @property
    def md(self):
        md = self._md
        if md is None:
            from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN
            md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 + CS_MODE_LITTLE_ENDIAN)
            self._md = md
        return md

    @md.setter
    def md(self, value):
        self._md = value

    def setLogHandler(self, handler):
        self.log_callback = handler

    def setUartHandler(self, handler):
        self.uart_callback = handler

    def setUartReceiveData(self, data_bytes, delay_instructions=500000, force_immediate=False):
        """Queue bytes for UART receive simulation.

        When the firmware's UART ISR runs, it reads UIIR, LSR, and URBR.
        Our read hook serves bytes from this queue.  Also arms interrupt
        delivery so the ISR gets invoked via the MIPS exception vector.

        Args:
            data_bytes: bytes to queue for UART receive
            delay_instructions: wait this many instructions before delivering
                               the first interrupt (default 500K, so TDS2 has
                               registered the UART ISR via OS_RegisterISR)
            force_immediate: if True, deliver IRQ at exactly delay_instructions
                            regardless of CP0 Status IE/EXL (for testing)
        """
        self._uart_rx_queue.extend(data_bytes)
        if len(self._uart_rx_queue) > 0:
            self._pending_uart_irq = True
            self._uart_irq_delivered = False
            self._uart_irq_arm_after = self.instruction_count + delay_instructions
            self._uart_irq_retries = 0
            self._uart_irq_force = force_immediate
        self.log(f"[UART RX] Queued {len(data_bytes)} bytes, IRQ armed after {delay_instructions} instructions{' (FORCED)' if force_immediate else ''}")

    def setSpiHandler(self, handler):
        self.spi_callback = handler

    def setSPIDump(self, enabled, flash_reads=False):
        """Enable or disable SPI dump logging (SPI commands, responses, flash
        program / erase).  flash_reads=True also logs normal-mode flash reads
        (once per 64 KB sector); that keeps a Unicorn memory hook installed,
        which slows every load of the emulation down (see _init_unicorn)."""
        self._spi_dump_enabled = enabled
        self._spi_dump_flash_reads = bool(enabled and flash_reads)
        if enabled and self._spi_status_injected:
            self._uninject_spi_status()
        if self._rom_dirty:
            self._rom_restore()
        self._update_flash_read_hooks()

    # The flash-window read hook (_hook_spi_flash_read) serves the SPI command
    # responses.  It is a Unicorn memory hook, so while it exists every guest
    # load takes Unicorn's slow path, and Unicorn decides that per translation
    # block when the block is translated.  Therefore:
    #  * it is only added / removed between emu_start() calls, and then the
    #    translation cache is flushed so that every block sees the change
    #    (added from a device callback while the CPU ran, the rest of the
    #    running block still read the flash window without it; that version
    #    also crashed Unicorn natively in 7-30% of the boots, together with the
    #    response bytes written into the read-only flash mapping, see
    #    _rom_inject);
    #  * when the guest enters SPI command mode without the hook, the emulation
    #    stops right at that SF_INS store (a stop requested inside a device
    #    access takes effect before the next instruction; the store is
    #    re-executed on resume and recognised as a replay), and the next
    #    emu_start() installs the hook before the guest reads the response;
    #  * leaving command mode stops at that SF_INS store too, and the next
    #    emu_start() removes the hook (and flushes): with the hook installed,
    #    every flash-window load (also in normal read mode) goes through it,
    #    which is slow and exposes the delay-slot bug (_device_access).  The
    #    two stops and flushes per command phase cost less than keeping it
    #    through sparse commands (dump.bin / Prima decompression: idle 0 s ~
    #    0.05 s, both ~20% faster than 0.5 s), but dense command sequences
    #    (dump.bin's application reads its flash database byte by byte, ~750k
    #    commands) run 5x faster when the hook stays through them: it is kept
    #    for flash_hook_idle_s of emulation time after command mode ends.
    flash_hook_idle_s = 0.05

    def _spi_can_inline_status(self):
        """Whether CMD 0x05 (Read Status Register) can be served inline from
        offset 0 of the flash window without installing _flash_read_hooks."""
        stream = self._spi_stream
        return (self._spi_status == 0 and not self._spi_dump_enabled
                and self.flash_device is None
                and not (stream is not None and stream.active))

    def _uninject_spi_status(self):
        if self._spi_status_injected:
            self._spi_status_injected = False
            if self.rom_image is not None:
                self._rom_view[0:4] = self.rom_image[0:4]

    def _flash_hooks_wanted(self):
        if self._spi_dump_flash_reads:
            return True
        if self._spi_is_passthrough():
            return False
        if self._spi_ins == 0x05 and self._spi_can_inline_status():
            return False
        if self._spi_ins in self._SPI_NO_READ_HOOK and (self._spi_stream is None or not self._spi_stream.active):
            return False
        return True

    def _update_flash_read_hooks(self):
        """The SPI controller mode or the logging setting changed."""
        wanted = self._flash_hooks_wanted()
        if wanted:
            self._spi_cmd_vt = self._vtime()
        if wanted == bool(self._flash_read_hooks):
            self._flash_hooks_pending = False
        elif self._vt_slice_t0 is None:               # not emulating: change it now
            self._apply_flash_hooks(force=True)
        elif wanted or self.flash_hook_idle_s <= 0:   # emulating: at the next emu_start()
            self._flash_hooks_pending = True
            if not self.is_stepping:                   # (a single step ends after this instruction)
                if self._stop_reason is None:
                    self._stop_reason = 'flashhooks'
                self._orig_emu_stop()
        # (else: no longer wanted; _apply_flash_hooks removes it after the idle time)

    def _apply_flash_hooks(self, force=False):
        """Between emu_start() calls: install the flash read hook if wanted;
        remove it if not, after flash_hook_idle_s without command mode (at
        once with force)."""
        self._flash_hooks_pending = False
        wanted = self._flash_hooks_wanted()
        if wanted and not self._flash_read_hooks:
            for flash_base in self._flash_windows:
                self._flash_read_hooks.append(self.mu.hook_add(
                    UC_HOOK_MEM_READ, self._hook_spi_flash_read,
                    begin=flash_base, end=flash_base + 0x00FFFFFF))
            self.flash_hook_changes += 1
            self._flush_tb()
        elif self._flash_read_hooks and not wanted and \
                (force or self._vtime() - self._spi_cmd_vt >= self.flash_hook_idle_s):
            if self._rom_dirty:
                self._rom_restore()
            for h in self._flash_read_hooks:
                self.mu.hook_del(h)
            self._flash_read_hooks = []
            self.flash_hook_changes += 1
            self._flush_tb()

    def _hook_null_jump(self, uc, address, size, user_data):
        if self.is_stepping:
            return
        self._stop_reason = 'null'
        uc.emu_stop()

    # The SDK's application images are loaded at 0x80000200, and some start with
    # 0xE00 zero bytes before their first code (the Ferguson T750i / T760i
    # applications).  Unicorn 2.1.4 crashes translating that run of ~900 NOPs
    # as one unhooked block, so while the range holds such a run it executes
    # under a code hook that does nothing (_hook_short_blocks); the exception
    # vectors below it stay unhooked.  Code there runs unhooked: a Python call
    # per instruction made the URZ0086's start-up (its BSS clear) take 1.7 s of
    # emulation time instead of 25 ms, and the SEE's program, which its
    # bootloader starts just before, ran all that time.
    _PADDING = (0x80000200, 0x80000FFF)
    _PADDING_WORDS = 128                # a run of zero words this long is padding, not code

    def _update_short_block_hook(self):
        """At a full CP0 site scan: hook the padding range while it holds a long
        run of zero words, unhook it otherwise."""
        zeros = bytes(4 * self._PADDING_WORDS)
        bases = {0x00000000}
        for start, length in self.chip.code_ranges():
            phys = start & 0x1FFFFFFF
            if (start >> 29) in (0, 4, 5) and length >= 0x1000 and phys + 0x1000 <= self._mapped_ram_size:
                bases.add(phys)
        wanted = set()
        for phys in bases:
            if phys + 0x1000 <= self._mapped_ram_size:
                padded = zeros in bytes(self._ram_view[phys + 0x200:phys + 0x1000])
            else:
                padded = zeros in self.mu.mem_read(0x80000000 + phys + 0x200, 0xE00)
            if padded:
                wanted.add((0x80000000 + phys + 0x200, 0x80000000 + phys + 0xFFF))
                if phys:
                    wanted.add((0xA0000000 + phys + 0x200, 0xA0000000 + phys + 0xFFF))
        for rng in list(self._short_block_hooks):
            if rng not in wanted:
                self.mu.hook_del(self._short_block_hooks.pop(rng))
                self._tb_flush_needed = True
        for lo, hi in sorted(wanted):
            if (lo, hi) not in self._short_block_hooks:
                self._short_block_hooks[(lo, hi)] = self.mu.hook_add(
                    UC_HOOK_CODE, self._hook_short_blocks, begin=lo, end=hi)
                self._tb_flush_needed = True
        self._short_block_hook = self._short_block_hooks.get(self._PADDING)

    def _hook_short_blocks(self, uc, address, size, user_data):
        """Nothing: being hooked keeps Unicorn's translation blocks short there
        (_update_short_block_hook, _find_long_blocks)."""

    # Unicorn 2.1.4 also crashes translating unhooked straight-line code blocks
    # of ~375+ MIPS32 instructions (such as the unrolled 64-round MD5 / SHA
    # compression functions in the C3505 and M3606 maincodes).  Covering runs
    # of >= _LONG_BLOCK_INSNS branchless non-zero instructions with
    # _hook_short_blocks causes TCG to fill its micro-op buffer and split the
    # translation block cleanly before the crash threshold.
    _LONG_BLOCK_INSNS = 300
    _LONG_BLK_BRK_MASK = 0x20F000FE
    _LONG_BLK_BRK_OP = None
    _LONG_BLK_VAL_OP = None

    def _find_long_blocks(self, data, base, views):
        """Hook branchless runs of >= _LONG_BLOCK_INSNS MIPS32 instructions in
        data (code at physical offset `base`) with _hook_short_blocks."""
        np = _get_np()
        if np is None:
            return
        n = len(data) // 4
        low = self._LONG_BLOCK_INSNS
        if n < low:
            return
        if self._LONG_BLK_BRK_OP is None:
            AliMipsSimulator._LONG_BLK_BRK_OP = np.array(
                [(1 <= op <= 7) or op == 0x1D or (20 <= op <= 23) for op in range(64)], dtype=bool)
            AliMipsSimulator._LONG_BLK_VAL_OP = np.array(
                [op == 0 or (8 <= op <= 15) or (28 <= op <= 46) for op in range(64)], dtype=bool)
        w = np.frombuffer(data, dtype='<u4', count=n)
        half = low >> 1
        sw = w[::half]
        sop = sw >> 26
        sfn = sw & 0x3F
        brk_lut = self._LONG_BLK_BRK_OP
        val_lut = self._LONG_BLK_VAL_OP
        s_brk = ((sw == 0) | (sw == 0xFFFFFFFF) | brk_lut[sop] |
                 ((sop == 0) & (sfn >= 8) & (sfn <= 13)) | (sw == 0x42000018))
        s_ok = ~s_brk
        cand = np.flatnonzero(s_ok[:-1] & s_ok[1:] & (val_lut[sop[:-1]] | val_lut[sop[1:]]))
        if len(cand) == 0:
            return
        mv = memoryview(data)[:n * 4].cast('I')
        brk_mask = self._LONG_BLK_BRK_MASK
        kept = []
        for k in cand.tolist():
            base_idx = k * half
            for d in (75, 1, 2, 3, 4, 5, 6, 7, 37, 112, 18, 56, 93, 131):
                pw = mv[base_idx + d]
                if (brk_mask >> (pw >> 26)) & 1:
                    break
                if pw < 0x04000000:
                    if pw == 0 or 8 <= (pw & 0x3F) <= 13:
                        break
                elif pw == 0xFFFFFFFF or pw == 0x42000018:
                    break
            else:
                kept.append(k)
        if not kept:
            return
        spans = []
        for k in kept:
            w_st = max(0, (k - 1) * half)
            w_en = min(n, (k + 2) * half + 1)
            if spans and w_st <= spans[-1][1]:
                spans[-1][1] = max(spans[-1][1], w_en)
            else:
                spans.append([w_st, w_en])
        for w_st, w_en in spans:
            sub = w[w_st:w_en]
            op = sub >> 26
            fn = sub & 0x3F
            breaker = ((sub == 0) | (sub == 0xFFFFFFFF) | brk_lut[op] |
                       ((op == 0) & (fn >= 8) & (fn <= 13)) | (sub == 0x42000018))
            raw_idx = np.flatnonzero(breaker)
            idx = np.empty(len(raw_idx) + 2, dtype=np.intp)
            idx[0] = -1
            idx[1:-1] = raw_idx
            idx[-1] = len(sub)
            gaps = np.diff(idx)
            for g in np.flatnonzero(gaps >= low).tolist():
                st = int(idx[g]) + 1
                en = int(idx[g + 1])
                if int(val_lut[op[st:en]].sum()) >= (en - st) * 3 // 4:
                    abs_st, abs_en = w_st + st, w_st + en
                    for view in views:
                        lo, hi = view + base + abs_st * 4, view + base + abs_en * 4 - 1
                        if (lo, hi) not in self._long_block_hooks:
                            self._long_block_hooks[(lo, hi)] = self.mu.hook_add(
                                UC_HOOK_CODE, self._hook_short_blocks, begin=lo, end=hi)
                            self._tb_flush_needed = True

    def setGpioHandler(self, handler):
        """Set the callback for GPIO pin changes, handler(address, size,
        value): called for every write of a GPIO bank's DO or DIR register
        with the bank's pin levels (_hook_gpio_write).  If the handler is a
        bound method of an object with di_override(di_offset, value), the
        object also answers the firmware's reads of the pins it drives
        (_hook_gpio_di_read)."""
        self.gpio_callback = handler
        from lemontree_decoder import LemontreeDecoder
        if isinstance(getattr(handler, "__self__", None), LemontreeDecoder):
            self.gpio_devices = [d for d in self.gpio_devices if not isinstance(d, LemontreeDecoder)]

    def setI2CDump(self, enabled):
        """Enable or disable I2C/GPIO trace logging. TM1650 results always shown."""
        if self.gpio_callback and hasattr(self.gpio_callback, '__self__'):
            self.gpio_callback.__self__.dump_enabled = enabled

    def addBreakpoint(self, address):
        self.breakpoints.add(address)
        self.log(f"Breakpoint added at 0x{address:08X}")
        self._sync_hooks_if_ready()

    def removeBreakpoint(self, address):
        if address in self.breakpoints:
            self.breakpoints.remove(address)
            self.log(f"Breakpoint removed at 0x{address:08X}")
            self._sync_hooks_if_ready()

    @property
    def stop_instr(self):
        """Address at which emulation stops (like a one-off breakpoint)."""
        return self._stop_instr

    @stop_instr.setter
    def stop_instr(self, value):
        self._stop_instr = value
        self._sync_hooks_if_ready()

    def _sync_hooks_if_ready(self):
        """Keep the fast-mode hooks in step with breakpoints/stop_instr for
        scripts that drive sim.mu.emu_start() directly instead of run()."""
        if self.mu is not None and self.rom_image is not None and getattr(self, '_virgin_hooks', None) is not None:
            try:
                self._sync_hooks()
            except Exception as e:
                self.log(f"Warning: hook sync failed: {e}")

    def log(self, msg):
        if self.log_callback:
            self.log_callback(msg)
        else:
            print(msg)

    def _uart_log(self, value):
        if self.uart_callback:
            # Pass the character code directly, let the handler decide format
            self.uart_callback(chr(value & 0xFF))
        else:
            try:
                print(bytes([value & 0xFF]).decode('ascii', errors='replace'), end='', flush=True)
            except:
                pass

    # SPI command name lookup for readable log output
    _SPI_CMD_NAMES = {
        0x03: "Read", 0x0B: "Fast Read", 0x9F: "JEDEC Read ID",
        0x05: "Read Status", 0xAB: "Release Power Down",
        0x90: "Read Mfr/Dev ID", 0x06: "WREN", 0x04: "WRDI",
        0x01: "Write Status", 0x02: "Page Program", 0xAD: "AAI Program",
        0x3B: "Dual Read", 0x6B: "Quad Read", 0xBB: "Dual I/O Read", 0xEB: "Quad I/O Read",
        0x32: "Quad Page Program",
        0x20: "Sector Erase 4K", 0x52: "Block Erase 32K",
        0xD8: "Block Erase 64K", 0xC7: "Chip Erase", 0x60: "Chip Erase",
    }

    def _spi_log(self, msg):
        if not self._spi_dump_enabled:
            return
        if self.spi_callback:
            self.spi_callback(msg)
        else:
            print(f"[SPI] {msg}", flush=True)

    def loadFile(self, filename, chip=None):
        filename = resolve_dump(filename)
        self.dump_path = filename
        self.log(f"Loading {filename}...")
        import ir_remote
        self.ir_coding = ir_remote.coding_for(filename)
        with open(filename, "rb") as f:
            code = f.read()
        
        if len(code) > self.rom_size:
            # Reallocation would break the multiple mem_map_ptr calls we did in _init_unicorn,
            # so for now we'll issue a strong warning and truncate if needed.
            # In a real environment, the ROM dump shouldn't exceed the configured ROM size.
            self.log(f"Warning: File size (0x{len(code):X}) exceeds rom_size (0x{self.rom_size:X}). Truncating!")
            code = code[:self.rom_size]
        
        # Keep the pristine image (padded with erased flash) and load it into the
        # shared ROM buffer; every mirror sees it.
        self.rom_image = bytearray(code) + bytearray(b'\xFF' * (self.rom_size - len(code)))
        self._spi_status_injected = False
        self._rom_dirty = []
        self._rom_write(0, self.rom_image)
        # SPI flash controller back to its power-on state (normal read mode)
        self._spi_ins, self._spi_fmt, self._spi_dum, self._spi_cfg = 0x03, 0x0D, 0x00, 0x00
        self._mmio_view[0x00098:0x0009C] = b'\x03\x0d\x00\x00'
        self._mmio_view[0x2E098:0x2E09C] = b'\x03\x0d\x00\x00'
        self._spi_status, self._spi_wel = 0x00, False
        self._spi_response, self._spi_resp_idx, self._last_flash_read_page = [], 0, -1
        self._update_flash_read_hooks()

        # A dual-CPU chip's SEE back in reset: a SEE core running the last image's program stops
        if self.chip.see is not None:
            self.chip.see.reset()
        # The image's chip family: its boot flow, and its devices if it differs
        # from the current one (chips/; the class itself: an M3503 is an M3602
        # and a C3505 an M3821 to isinstance, but their chip IDs and devices differ)
        if chip is None or (isinstance(chip, str) and chip.lower() in ("", "auto")):
            family = chips.detect(self.rom_image)
        elif isinstance(chip, str):
            by_name = {cls.__name__.upper(): cls for cls in chips.FAMILIES}
            if chip.upper() not in by_name:
                raise ValueError(f"unknown chip family {chip!r} (expected one of {[c.__name__ for c in chips.FAMILIES]})")
            family = by_name[chip.upper()]
        else:
            family = chip
        if type(self.chip) is not family:
            self._switch_family(family)
        else:
            self.chip.write_chip_id()       # (this image's board may read another chip ID)
        self.attach_demod()                 # (the board's external demodulator, when its sidecar names one)
        self.attach_gpio_devices()          # (its bit-banged I2C bus, pulled-up inputs)

        # Re-initialize globals if re-running
        self.instruction_count = 0
        self._count_icount = 0
        self._count_t0 = self._vtime()
        # CP0 timer back to its reset state (no Compare written yet)
        self._ti = False
        self._timer_armed = False
        self._timer_anchor = self._cp0_count_now()
        self._timer_next_icount = 0
        self._count_observed = None
        self._uart_ip3 = False
        while self._ic_lines:                   # (also clears their 0xB8000030 / 34 bits)
            self._ic_set_line((self._ic_lines & -self._ic_lines).bit_length() - 1, False)
        self._ge_status = 0
        self._irc_fifo.clear()
        self._irc_status = 0
        self._irc_frames.clear()
        self._irc_last_vt = -1e9
        self._ir_key_table = None
        self.ir_keys_sent = 0
        for master in self.i2c_masters:
            master.reset()
        self.smc.reset()
        self.timer_irq_count = self.ic_irq_count = self.ge_ops = 0
        self.busy_pending = 0.0
        self.lzma_decodes = []
        self.delay_calls = self.delay_jumps = 0
        self.delay_skipped = 0.0
        self._last_eret_vt = -1e9
        self._dev_replays = {}
        self.visit_counts = {}
        self.last_lui_addr = None
        self._rescan_all()
        # The reset state: the PC, after whatever the chip's boot ROM does first
        self.chip.start()

    def _rescan_all(self):
        """Fast mode: scan the flash, the RAM and the family's code ranges for
        CP0 instruction sites again, and install the hooks now -- some test
        scripts drive sim.mu.emu_start() directly instead of run(), and still
        need CP0 emulation."""
        for h in self._long_block_hooks.values():
            self.mu.hook_del(h)
        self._long_block_hooks.clear()
        self._scanned_ram_chunks.clear()
        self._rescan_due = True
        self._rom_sites_dirty = True
        self._sync_hooks()

    def _device_tables(self):
        """Copies of the device register handlers (reads, writes) and the slice
        services: taken before the first chip family installs its devices, they
        are the common devices'."""
        return ({off: list(h) for off, h in self._mmio_rd.items()},
                {off: list(h) for off, h in self._mmio_wr.items()},
                list(self.slice_services))

    def _switch_family(self, family):
        """Replace the chip family by `family` (a chips/ class): the current one
        gives back what its install() changed besides its devices
        (ChipFamily.uninstall: memory it mapped, hooks, attributes of the
        simulator), the device handlers and slice services go back to the
        common ones, then the new family installs its own.  Without that, a
        simulator -- which starts as the M3801 -- kept the M3801's
        demodulator, demultiplexer and RTC handlers under every other family."""
        self.chip.uninstall()
        reads, writes, services = self._common_devices
        self._mmio_rd.clear()
        self._mmio_rd.update((off, list(h)) for off, h in reads.items())
        self._mmio_wr.clear()
        self._mmio_wr.update((off, list(h)) for off, h in writes.items())
        self.slice_services[:] = services
        self.chip = family(self)
        self.chip.install()

    def _map_flash_mirror(self, base, size):
        """Map the flash window's mirror over base .. base + size - 1 (base: an
        address of the 0x0F000000 / 0x1F000000 windows in any segment, the
        range inside one 4 MB slot): read-only at the physical address, its
        bytes the flash's at _flash_offset(base).  _init_unicorn() maps the
        windows with it, and a chip family that put memory of its own there
        gives it back with it."""
        import ctypes
        perms = (UC_PROT_READ | UC_PROT_EXEC) if base < 0x80000000 else UC_PROT_ALL
        self.mu.mem_map_ptr(base, size, perms, ctypes.addressof(self.rom_buffer) + self._flash_offset(base))

    def _map_flash_linear_tail(self):
        """A flash larger than 4 MB also continues linearly above its window's
        top: physical 0x10000000 onwards shows flash offset 0x400000 onwards
        (read-only, in the physical, KSEG0 and KSEG1 views).  The bootloaders
        of the newer M3503 / C3505 / C3503 builds read the whole flash through
        SYS_FLASH_BASE_ADDR 0xAFC00000 upwards for their 'dump' command (the
        Amiko CHD8270+'s streams offset 0..0x3FFFFF from there and then loads
        0xB0000000); the SDK's segment layout below 0x0FC00000 (_flash_offset)
        stays as it is.  Nothing else is mapped there."""
        import ctypes
        tail = self.rom_size - 0x400000
        if tail <= 0:
            return
        ptr = ctypes.addressof(self.rom_buffer) + 0x400000
        for seg in (0x00000000, 0x80000000, 0xA0000000):
            try:
                self.mu.mem_map_ptr(seg + 0x10000000, tail, UC_PROT_READ | UC_PROT_EXEC, ptr)
            except Exception as e:
                self.log(f"Warning: Failed to map the flash's linear tail at {hex(seg + 0x10000000)}: {e}")

    def _sync_flash_windows(self):
        pass

    def _on_ram_size_changed(self):
        pass

    def set_upper_ram_mapped(self, on):
        """Switch physical 0x0F000000..0x10000000 between the 16 MB flash window
        (False, power-on reset) and the top 16 MB of a 256 MB DDR (True, once a
        256 MB bootloader sets 0xB8000220 bit 24)."""
        on = bool(on) and self.ram_size > 0x0F000000
        target = self._upper_ram_mapped if self._upper_ram_pending is None else self._upper_ram_pending
        if on == target:
            return
        if self._vt_slice_t0 is not None:
            self._upper_ram_pending = on
            if not self.is_stepping:
                if self._stop_reason is None:
                    self._stop_reason = 'flashhooks'
                self._orig_emu_stop()
            return
        self._apply_upper_ram_map(on)

    def _apply_upper_ram_map(self, on):
        import ctypes
        self._upper_ram_pending = None
        on = bool(on) and self.ram_size > 0x0F000000
        if on == self._upper_ram_mapped:
            return
        if self._rom_dirty:
            self._rom_restore()
        for h in self._flash_read_hooks:
            self.mu.hook_del(h)
        self._flash_read_hooks = []
        self._upper_ram_mapped = on
        self._mapped_ram_size = self.ram_size if on else min(self.ram_size, 0x0F000000)
        self._ram_words_len = (self._mapped_ram_size >> 2) if self._ram_words is not None else 0
        self._flash_windows = [0x1F000000] if on else [0x0F000000, 0x1F000000]
        self._sync_flash_windows()
        upper_sz = min(self.ram_size, 0x10000000) - 0x0F000000
        ram_ptr = ctypes.addressof(self.ram_buffer)
        slot = min(self.rom_size, 0x400000)
        for seg in (0x00000000, 0x80000000, 0xA0000000):
            self.mu.mem_unmap(seg + 0x0F000000, upper_sz)
            if on:
                self.mu.mem_map_ptr(seg + 0x0F000000, upper_sz, UC_PROT_ALL, ram_ptr + 0x0F000000)
            else:
                for offset in range(0, upper_sz, slot):
                    self._map_flash_mirror(seg + 0x0F000000 + offset, slot)
        fn = getattr(self.chip, 'on_upper_ram_mapped', None)
        if fn is not None:
            fn(on)
        see = getattr(self.chip, 'see', None)
        if see is not None and see.core is not None:
            see.core.core.set_upper_ram_mapped(on)
        self._apply_flash_hooks(force=True)
        self._flush_tb()

    def set_ram_size(self, size):
        """Resize the primary core's DDR buffer between runs (e.g. 128 MB <->
        256 MB on C3505 boards), resetting the 0x0F000000 window to flash."""
        import ctypes
        if self._shared is not None:
            return
        self._apply_upper_ram_map(False)
        if size == self.ram_size:
            return
        old_low = min(self.ram_size, 0x0F000000)
        for base in (0x80000000, 0xA0000000, 0x00000000):
            self.mu.mem_unmap(base, old_low)
        self.ge = None
        self._delay_code_views.clear()
        self._sflash_read_views.clear()
        self._vector_page = None
        self._scanned_ram_chunks.clear()
        for h in self._virgin_hooks.values():
            self.mu.hook_del(h)
        self._virgin_hooks.clear()
        self.ram_size = size
        self._mapped_ram_size = min(size, 0x0F000000)
        self.ram_buffer = ctypes.create_string_buffer(size)
        ram_ptr = ctypes.addressof(self.ram_buffer)
        new_low = min(size, 0x0F000000)
        for base in (0x80000000, 0xA0000000, 0x00000000):
            self.mu.mem_map_ptr(base, new_low, UC_PROT_ALL, ram_ptr)
        self._ram_view = memoryview(self.ram_buffer).cast('B')
        self._ram_words = self._ram_view.cast('I') if sys.byteorder == 'little' else None
        self._ram_halfwords = self._ram_view.cast('H') if sys.byteorder == 'little' else None
        self._ram_words_len = (self._mapped_ram_size >> 2) if self._ram_words is not None else 0
        self._on_ram_size_changed()
        self._flush_tb()

    def loadFileTruncated(self, filename, max_bytes):
        """Load a ROM file but keep only the first max_bytes.
        
        The rest of ROM is filled with 0xFF (erased flash state).
        Useful for testing bootloader behavior when main app chunks
        are missing or corrupted.
        """
        self.loadFile(filename)
        if max_bytes < self.rom_size:
            pad = b'\xFF' * (self.rom_size - max_bytes)
            self.rom_image[max_bytes:] = pad
            self._rom_write(max_bytes, pad)
            self._rescan_all()
            self.log(f"Truncated ROM to {max_bytes // 1024}KB (rest filled with 0xFF)")

    def _hook_mem_invalid(self, uc, access, address, size, value, user_data):
        access_types = {
            16: "READ", 17: "WRITE", 18: "FETCH",
            19: "READ_UNMAPPED", 20: "WRITE_UNMAPPED", 21: "FETCH_UNMAPPED",
            22: "WRITE_PROT", 23: "READ_PROT", 24: "FETCH_PROT",
        }
        pc = uc.reg_read(UC_MIPS_REG_PC)
        atype = access_types.get(access, f"UNKNOWN({access})")
        
        # Always print to stderr so crash details are never lost
        import sys as _sys
        print(f"\n[!] INVALID MEMORY ACCESS", file=_sys.stderr, flush=True)
        print(f"    Type: {atype}", file=_sys.stderr, flush=True)
        print(f"    Address: 0x{address:08X}", file=_sys.stderr, flush=True)
        print(f"    Size: {size}", file=_sys.stderr, flush=True)
        print(f"    PC: 0x{pc:08X}", file=_sys.stderr, flush=True)
        
        try:
            print(f"    Instruction bytes: {uc.mem_read(pc, 4).hex()}", file=_sys.stderr, flush=True)
        except:
            pass
        
        # Dump all GPRs for debugging
        gpr_names = [
            "zero","at","v0","v1","a0","a1","a2","a3",
            "t0","t1","t2","t3","t4","t5","t6","t7",
            "s0","s1","s2","s3","s4","s5","s6","s7",
            "t8","t9","k0","k1","gp","sp","fp","ra"
        ]
        print(f"    --- Register Dump ---", file=_sys.stderr, flush=True)
        for i, name in enumerate(gpr_names):
            val = uc.reg_read(self.gpr_map[i])
            print(f"    {name:4s} = 0x{val:08X}", file=_sys.stderr, flush=True)
        
        # Disassemble instruction at PC
        try:
            code = uc.mem_read(pc, 4)
            print(f"    --- Instruction at PC ---", file=_sys.stderr, flush=True)
            print(f"    Bytes: {' '.join(f'{b:02x}' for b in code)}", file=_sys.stderr, flush=True)
            for i in self.md.disasm(bytes(code), pc):
                print(f"    {i.mnemonic}\t{i.op_str}", file=_sys.stderr, flush=True)
        except Exception as e:
            print(f"    (could not disasm: {e})", file=_sys.stderr, flush=True)
        
        # Also send to log handler
        if address == 0 and access in [18, 21]:  # FETCH or FETCH_UNMAPPED
            self.log(f"\n[!] STOPPED: Jump to NULL (0x0) detected!")
        else:
            self.log(f"\n[!] INVALID MEMORY ACCESS")
            self.log(f"    Type: {atype}")
            self.log(f"    Address: 0x{address:08X}")
        self.log(f"    Size: {size}")
        self.log(f"    PC: 0x{pc:08X}")
        return False

    # ------------------------------------------------------------------
    # Replay-safe device side effects
    # ------------------------------------------------------------------
    # An asynchronous stop (the slice stopper, Unicorn's timeout, a GUI pause)
    # is noticed by Unicorn right after a load / store and rewinds the PC to
    # that instruction, which then runs again -- memory hook included -- on
    # resume.  For RAM that is harmless; for device registers whose access has
    # a side effect it duplicated UART TX characters, lost UART RX bytes and
    # skipped SPI response bytes.  Those hooks record their access
    # (_dev_note); if the emu_start() wrapper sees an asynchronous stop that
    # left the PC on that very instruction, the re-execution is recognised
    # (_dev_replay_of) and serves / skips the same data.  A stop noticed just
    # *before* a later pass of the same instruction (a GUI pause, the start of
    # a translation block) must not count: the access keeps a register
    # fingerprint, a rewind leaves the registers unchanged, and any other
    # hooked instruction / device access in between clears the record.
    # Pending replays are kept per (PC, SP), so an interrupt handler or another
    # task running the same putc / getc in between does not take them.

    def _device_access(self, uc, hooked=False):
        """Start of every device handler.  A new device access proves the
        noted one completed (see _dev_note).  An access that reached us
        through a Unicorn memory hook / protection fault (hooked=True: the
        flash window) in a branch delay slot meets a Unicorn 2.1.4 bug: the
        branch flags of hflags stay set after it, so the next translation
        block -- at the branch's target -- runs as the delay slot of a branch
        to that target, and its first instruction runs twice (the M3329's
        flash probe, whose target is another branch: PC 0 in the end).  So
        the emulation stops there (before that block: the branch has
        completed) and the emu_start() wrapper clears the flags
        (_clear_branch_flags).  mmio_map accesses (the device registers) do
        not have that bug -- unless a Unicorn memory hook (a debugging
        script's) covers the device window too, which is not checked."""
        self._dev_last = None
        if hooked and self._hflags_off is not None:
            if not self._live_env:
                self._ctx_save()
            if self._hflags_view.value & self._HFLAG_BMASK:
                pc = self._reg_read(UC_MIPS_REG_PC)
                if pc not in self._ds_dev_warned and len(self._ds_dev_warned) < 16:
                    self._ds_dev_warned.add(pc)
                    self.log(f"[DSLOT] device access in a branch delay slot at 0x{pc:08X}: stopping "
                             f"after the branch to clear its flags (Unicorn 2.1.4 would run its target twice)")
                self._ds_flags_stale = True
                if not self.is_stepping:            # (a single step ends after the branch anyway)
                    if self._stop_reason is None:
                        self._stop_reason = 'dslot'
                    self._orig_emu_stop()

    def _clear_branch_flags(self):
        """After an emu_start() that stopped for a hooked access in a delay
        slot (_device_access): the branch has completed, clear its flags."""
        self._ds_flags_stale = False
        if not self._live_env:
            self._ctx_save()
        if self._hflags_view.value & self._HFLAG_BMASK:
            self._hflags_view.value &= ~self._HFLAG_BMASK
            if not self._live_env:
                self.mu.context_restore(self._ctx)
            self.ds_flag_fixes += 1

    def _dev_note(self, uc, kind, address, data, exact=None):
        """Record a device access with a side effect (see the section comment).
        Its PC is exact in exact mode and for accesses through a Unicorn memory
        hook (exact=True: the flash window); in an mmio_map callback in fast
        mode it is the start of the translation block."""
        hooked_exact = exact is True
        if exact is None:
            exact = self._code_hook_h is not None
        gprs = self._gpr_snapshot(ctx_saved=hooked_exact and self._hflags_off is not None)
        pc = self._pc_view.value if self._pc_view is not None and gprs is not None else self._reg_read(UC_MIPS_REG_PC)
        self._dev_last = (kind, address, data, gprs, pc, exact)

    def _same_block(self, start, pc):
        """True if pc can lie in the translation block that starts at `start`:
        straight-line code from start to pc, or pc is the delay slot of the
        branch that ends it (in exact mode start is the access itself).  Tells
        a rewound access from a stop just before another instruction that
        repeats it (a later block)."""
        if start is None:
            return False
        start &= ~1
        # a translation block never crosses a 4 KB page
        if not 0 <= pc - start < 0x1000 or (start ^ pc) & ~0xFFF:
            return False
        m16 = self.is_mips16_mode()
        sites = self._cp0_site_hooks
        a = start
        try:
            while a < pc:
                if m16:
                    op = int.from_bytes(self.mu.mem_read(a, 2), 'little') >> 11
                    size = 4 if op in (0x1E, 0x03) else 2                # EXTEND / JAL(X)
                    insn = bytes(self.mu.mem_read(a, size))
                    hw = insn[0] | (insn[1] << 8)
                    ends = (self._insn_has_delay_slot(insn, size, True)
                            or self._m16_pc_relative_branch(insn, size)
                            or (size == 2 and op == 0x1D and (hw & 0x1F) in (0, 1, 5)))  # J(AL)R(C), SDBBP, BREAK
                else:
                    size = 4
                    insn = bytes(self.mu.mem_read(a, 4))
                    w = int.from_bytes(insn, 'little')
                    ends = (self._insn_has_delay_slot(insn, 4, False)
                            or a in sites                                  # hooked CP0 site: the hook moves the PC
                            or w in (0x42000018, 0x4200001F)               # ERET, DERET
                            or (w & 0xFE00003F) == 0x42000020              # WAIT
                            or (w & 0xFFE0FFDF) == 0x41606000              # DI / EI
                            or ((w >> 26) == 1 and ((w >> 16) & 0x1F) == 0x1F)    # SYNCI
                            or ((w >> 26) == 0 and (w & 0x3F) in (0x0C, 0x0D)))  # SYSCALL / BREAK
                if ends:
                    return pc == a + size and self._insn_has_delay_slot(insn, size, m16)
                a += size
            return a == pc
        except UcError:
            return False

    @staticmethod
    def _phys(address):
        """Physical address of a kseg0 / kseg1 / (ERL) kuseg address; None stays None."""
        if address is None:
            return None
        return address & 0x1FFFFFFF if 0x80000000 <= address < 0xC0000000 else address

    # MIPS32 load / store opcodes: lb lh lwl lw lbu lhu lwr sb sh swl sw swr ll sc
    _M32_MEM_OPS = frozenset((0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x28, 0x29, 0x2A, 0x2B, 0x2E,
                              0x30, 0x38))
    # MIPS16e: major opcode -> (offset scale, base register: None = rx, 29 = sp)
    _M16_MEM_OPS = {0x10: (1, None), 0x11: (2, None), 0x12: (4, 29), 0x13: (4, None),
                    0x14: (1, None), 0x15: (2, None), 0x18: (1, None), 0x19: (2, None),
                    0x1A: (4, 29), 0x1B: (4, None)}
    _M16_REGS = (16, 17, 2, 3, 4, 5, 6, 7)

    def _insn_mem_address(self, pc):
        """Effective address of the load / store at pc in the current ISA mode
        (with the current registers), or None if it is not one."""
        try:
            if self.is_mips16_mode():
                hw = int.from_bytes(self.mu.mem_read(pc, 2), 'little')
                ext = None
                if hw >> 11 == 0x1E:                        # EXTEND prefix
                    ext = hw
                    hw = int.from_bytes(self.mu.mem_read(pc + 2, 2), 'little')
                op = hw >> 11
                if op == 0x0C and (hw >> 8) & 7 == 2:       # SWRASP: sw ra, imm8*4(sp)
                    scale, base, imm = 4, 29, hw & 0xFF
                elif op in self._M16_MEM_OPS:
                    scale, base = self._M16_MEM_OPS[op]
                    if base is None:
                        base, imm = self._M16_REGS[(hw >> 8) & 7], hw & 0x1F
                    else:
                        imm = hw & 0xFF
                else:
                    return None
                if ext is not None:                         # 16-bit signed, unscaled
                    off = ((ext & 0x1F) << 11) | (((ext >> 5) & 0x3F) << 5) | (hw & 0x1F)
                    off -= (off & 0x8000) << 1
                else:
                    off = imm * scale
            else:
                w = int.from_bytes(self.mu.mem_read(pc, 4), 'little')
                if w >> 26 not in self._M32_MEM_OPS:
                    return None
                base, off = (w >> 21) & 31, w & 0xFFFF
                off -= (off & 0x8000) << 1
            return (self._reg_read(self.gpr_map[base]) + off) & 0xFFFFFFFF
        except UcError:
            return None

    def _dev_replay_of(self, uc, kind, address, data=None):
        """(kind, address, data) of the first execution if this access is its
        replay, else None (and then recorded as a new access by the caller)."""
        if not self._dev_replays:
            return None
        pc = self._reg_read(UC_MIPS_REG_PC)
        rp = self._dev_replays.pop((pc, self._reg_read(UC_MIPS_REG_SP)), None)
        if rp is None or rp[0] != kind or rp[1] != address or (data is not None and rp[2] != data):
            return None                     # not pending here, or re-executed with other data
        self._dev_note(uc, kind, address, rp[2])    # a stop during the replay is a replay again
        return rp

    # ------------------------------------------------------------------
    # Device register window (mmio_map at the physical 0x18000000)
    # ------------------------------------------------------------------
    def _mmio_on(self, kind, handler, begin, end):
        """Call handler(uc, access, address, size, value, user_data) -- the
        signature of a Unicorn memory hook -- for every read ('r') / write
        ('w') of the device window that starts at an offset in begin..end
        (offsets in the 16 MB window; any segment's address is accepted).  It
        runs before the access, like a memory hook: a read handler can put the
        value to be read into the register (via the 0xB8000000 view it is
        given as `address`), a write handler sees the register before the
        store lands -- and can return the value that lands instead, for
        registers whose bits do not simply take what is stored."""
        table = self._mmio_rd if kind == 'r' else self._mmio_wr
        for off in range(begin & 0xFFFFFF, (end & 0xFFFFFF) + 1):
            table.setdefault(off, []).append(handler)

    def _mmio_off(self, kind, handler, begin, end):
        """Undo _mmio_on(kind, handler, begin, end)."""
        table = self._mmio_rd if kind == 'r' else self._mmio_wr
        for off in range(begin & 0xFFFFFF, (end & 0xFFFFFF) + 1):
            handlers = table.get(off)
            if handlers and handler in handlers:
                handlers.remove(handler)
                if not handlers:
                    del table[off]

    @staticmethod
    def _mmio_offset(address):
        """Offset in the 16 MB device window of a physical / kseg0 / kseg1
        address of it (0x18xxxxxx, 0x98xxxxxx, 0xB8xxxxxx), or of a bare offset."""
        if address < 0x01000000:
            return address
        if (address & 0x1FFFFFFF) >> 24 == 0x18 and (address < 0x20000000 or address >= 0x80000000):
            return address & 0x00FFFFFF
        raise ValueError(f"0x{address:08X} is not in the device window (0x18000000-0x18FFFFFF)")

    def add_mmio_hook(self, kind, callback, begin, end):
        """Observe the guest's device register accesses: kind 'read' or
        'write'; accesses that START in begin..end (any segment's addresses of
        the 0x18000000 window, e.g. 0xB800A000..0xB800A0FF).  callback has the
        Unicorn memory hook signature (uc, access, address, size, value,
        user_data) with `address` in the side-effect-free 0xB8000000 view; a
        write observer runs before the store with the value written, a read
        observer after the device model updated the register, with the value
        the guest reads.  Use this instead of mu.hook_add(UC_HOOK_MEM_READ /
        WRITE), which slows every RAM access of the emulation down.  Caveats:
        in fast mode uc.reg_read(PC) inside it is the start of the translation
        block, not the accessing instruction; an access that re-executes after
        a stop at it (an asynchronous stop, see _dev_note, or the stop at an
        SF_INS store that installs the flash read hook) is seen again.
        Returns a handle for remove_mmio_hook()."""
        if kind not in ('read', 'write'):
            raise ValueError(f"kind must be 'read' or 'write', not {kind!r}")
        lo, hi = self._mmio_offset(begin), self._mmio_offset(end)
        if lo > hi:
            raise ValueError("begin > end")
        handle = (kind == 'write', lo, hi, callback)
        self._mmio_observers.append(handle)
        return handle

    def remove_mmio_hook(self, handle):
        self._mmio_observers.remove(handle)

    def _mmio_observe(self, uc, write, offset, size, value):
        address = 0xB8000000 | offset
        for w, lo, hi, cb in list(self._mmio_observers):
            if w == write and lo <= offset <= hi:
                cb(uc, UC_MEM_WRITE if write else UC_MEM_READ, address, size, value, None)

    def _mmio_read(self, uc, offset, size, user_data):
        self._dev_last = None           # (a new device access: the noted one completed)
        handlers = self._mmio_rd.get(offset)
        if handlers is None and not self._mmio_observers:
            if size == 1:
                return self._mmio_view[offset]
            if size == 4 and not (offset & 3) and self._mmio_words is not None:
                return self._mmio_words[offset >> 2]
            if size == 2 and not (offset & 1) and self._mmio_halfwords is not None:
                return self._mmio_halfwords[offset >> 1]
            return int.from_bytes(self._mmio_view[offset:offset + size], 'little')
        self._dev_cb_depth += 1
        try:
            if handlers:
                address = 0xB8000000 | offset
                for h in handlers:
                    h(uc, UC_MEM_READ, address, size, 0, None)
            if size == 1:
                value = self._mmio_view[offset]
            elif size == 4 and not (offset & 3) and self._mmio_words is not None:
                value = self._mmio_words[offset >> 2]
            elif size == 2 and not (offset & 1) and self._mmio_halfwords is not None:
                value = self._mmio_halfwords[offset >> 1]
            else:
                value = int.from_bytes(self._mmio_view[offset:offset + size], 'little')
            if self._mmio_observers:
                self._mmio_observe(uc, False, offset, size, value)
            return value
        finally:
            self._dev_cb_depth -= 1

    def _mmio_write(self, uc, offset, size, value, user_data):
        self._dev_last = None
        handlers = self._mmio_wr.get(offset)
        if handlers is None and not self._mmio_observers:
            if size == 1:
                self._mmio_view[offset] = value & 0xFF
            elif size == 4 and not (offset & 3) and self._mmio_words is not None:
                self._mmio_words[offset >> 2] = value & 0xFFFFFFFF
            elif size == 2 and not (offset & 1) and self._mmio_halfwords is not None:
                self._mmio_halfwords[offset >> 1] = value & 0xFFFF
            else:
                mask = (1 << (8 * size)) - 1
                self._mmio_view[offset:offset + size] = (value & mask).to_bytes(size, 'little')
            return
        value &= (1 << (8 * size)) - 1
        self._dev_cb_depth += 1
        try:
            if self._mmio_observers:
                self._mmio_observe(uc, True, offset, size, value)
            if handlers:
                address = 0xB8000000 | offset
                for h in handlers:
                    stored = h(uc, UC_MEM_WRITE, address, size, value, None)
                    if stored is not None:
                        value = stored
            if size == 1:
                self._mmio_view[offset] = value & 0xFF
            elif size == 4 and not (offset & 3) and self._mmio_words is not None:
                self._mmio_words[offset >> 2] = value & 0xFFFFFFFF
            elif size == 2 and not (offset & 1) and self._mmio_halfwords is not None:
                self._mmio_halfwords[offset >> 1] = value & 0xFFFF
            else:
                self._mmio_view[offset:offset + size] = (value & ((1 << (8 * size)) - 1)).to_bytes(size, 'little')
        finally:
            self._dev_cb_depth -= 1

    # Python-side memory access without device side effects: a mem_read /
    # mem_write of the physical device window 0x18xxxxxx goes through the
    # mmio_map callbacks (reading URBR pops a UART RX byte, writing THR prints
    # a character, ...); peek / poke use the 0xB8000000 view of it instead.
    @staticmethod
    def _quiet_address(address):
        return address + 0xA0000000 if 0x18000000 <= address < 0x19000000 else address

    def peek(self, address, size):
        """Read guest memory (any mapped address) without device side effects."""
        return self.mu.mem_read(self._quiet_address(address), size)

    def poke(self, address, data):
        """Write guest memory (any mapped address) without device side effects."""
        self.mu.mem_write(self._quiet_address(address), bytes(data))

    def _hook_flash_write_prot(self, uc, access, address, size, value, user_data):
        """A store to the read-only flash window: emulate it (SPI command
        trigger, page program, see _hook_spi_flash_write) and let it land (it
        is reverted before the firmware can read it back: at the next
        instruction in exact mode; in fast mode at the next SPI register write,
        flash hook, CP0 hook or slice end).  Anything else is invalid."""
        if any(w <= address < w + 0x01000000 for w in self._flash_windows):
            self._dev_cb_depth += 1
            try:
                (self.flash_device.store if self.flash_device else self._hook_spi_flash_write)(
                    uc, access, address, size, value, user_data)
            finally:
                self._dev_cb_depth -= 1
            return True
        return self._hook_mem_invalid(uc, access, address, size, value, user_data)

    def _hook_uart_write(self, uc, access, address, size, value, user_data):
        self._device_access(uc)
        # the UART's block (0xB8018300; the M3329's 0xB8001300, chips/m3329.py) is
        # 16-byte aligned: a store to its +0 is THR, in any segment's view
        if (address & 0xF) == 0:
            if self._dev_replay_of(uc, 'thr', address, value) is None:
                self._uart_log(value)
                self._dev_note(uc, 'thr', address, value)
            # _uart_log delivers TX synchronously; no FIFO or shift-register
            # byte remains pending. Report THRE (bit 5) and TEMT (bit 6), so
            # firmware can drain the UART before resetting or changing baud.
            # LSR is at UART base + 5 (SCI_16550_ULSR = 5).
            self._mmio_view[(address & 0xFFFFF0) | 5] = 0x60

    def _hook_uart_read(self, uc, access, address, size, value, user_data):
        """Handle reads from UART registers for RX simulation.

        16550 UART registers at base 0xB8018300:
          +0    URBR  — Receive Buffer Register (read: get received byte)
          +2    UIIR  — Interrupt Identification Register (0x04=RDA, 0x0C=CTI, 0x01=none)
          +5    ULSR  — Line Status Register (bit0=DataReady, bit5=THRE, bit6=TEMT)
          +0x12 URFC  — RX FIFO byte count (read by SDK4.0gc / M3821 ISR)
        """
        self._device_access(uc)
        reg_offset = (address & 0x1F)  # offset within 32-byte UART block
        off = address & 0xFFFFFF
        if reg_offset == 5:  # ULSR — Line Status Register
            lsr = 0x60  # synchronous TX has empty holding and shift registers
            if len(self._uart_rx_queue) > 0:
                lsr |= 0x01  # bit0 = Data Ready
            self._mmio_view[off] = lsr
        elif reg_offset == 0:  # URBR — Receive Buffer Register
            rp = self._dev_replay_of(uc, 'urbr', address)
            if rp is not None:
                self._mmio_view[off] = rp[2]     # the same byte again, nothing popped
            elif len(self._uart_rx_queue) > 0:
                byte_val = self._uart_rx_queue.popleft()
                self._mmio_view[off] = byte_val
                self._dev_note(uc, 'urbr', address, byte_val)
                self.log(f"[UART RX] Read byte 0x{byte_val:02X} ('{chr(byte_val)}'), {len(self._uart_rx_queue)} remaining")
                # Re-trigger interrupt if more data available
                if len(self._uart_rx_queue) > 0:
                    self._pending_uart_irq = True
                    self._uart_irq_delivered = False
        elif reg_offset == 2:  # UIIR — Interrupt Identification Register
            n = len(self._uart_rx_queue)
            if n >= 4:
                # bit0=0 pending, bits[3:1]=010 = Received Data Available (>= trigger level 4)
                self._mmio_view[off] = 0x04
            elif n > 0:
                # bit0=0 pending, bits[3:1]=110 = Character Timeout Indicator (1..3 bytes)
                self._mmio_view[off] = 0x0C
            else:
                # bit0=1 means no interrupt pending
                self._mmio_view[off] = 0x01
        elif reg_offset == 0x12:  # URFC — RX FIFO byte count
            self._mmio_view[off] = min(len(self._uart_rx_queue), 16)

    # The GPIO banks (tm1650_decoder.GPIO_DO_OFFSETS and _EXTRA_ give each bank's DO register; its DI
    # register is DO - 4, its DIR register DO + 4): DO and DIR writes go to the panel decoder as the
    # bank's pin levels, a DI read returns the DO value (pin loopback) for the output bits
    _GPIO_DO_OFFSETS = set(GPIO_DO_OFFSETS) | set(GPIO_EXTRA_DO_OFFSETS)
    _GPIO_DI_TO_DO = {do - 4: do for do in _GPIO_DO_OFFSETS}
    _GPIO_DI_TO_DIR = {do - 4: do + 4 for do in _GPIO_DO_OFFSETS}

    def _hook_gpio_write(self, uc, access, address, size, value, user_data):
        """A write of a GPIO bank's DO or DIR register: the GPIO handler gets
        the bank's pin levels as they are after it, `address` the bank's DO
        register -- an output pin at its DO bit, an input pin high (the
        bus's pull-up; the decoder adds what its chip pulls low).  Drivers
        that bit-bang a bus open-drain keep DO 0 and switch the direction
        (the Opticum Blue R265 Lite's application, tm1650_decoder.py).  The
        board's other chips on GPIO pins (gpio_devices) get the same."""
        self._device_access(uc)
        if not self.gpio_callback and not self.gpio_devices:
            return
        base = address & ~3
        shift = (address & 3) * 8
        mask = ((1 << (size * 8)) - 1) << shift
        word = self._mmio_word(base) & ~mask | ((value << shift) & mask)
        if (base & 0xFFF) in self._GPIO_DO_OFFSETS:
            do_addr, do_val, dir_val = base, word, self._mmio_word(base + 4)
        else:
            do_addr, dir_val = base - 4, word
            do_val = self._mmio_word(do_addr)
        levels = (do_val & dir_val | ~dir_val) & 0xFFFFFFFF
        if self.gpio_callback:
            self.gpio_callback(do_addr, 4, levels)
        for device in self.gpio_devices:
            device.on_gpio_write(do_addr, 4, levels)

    def _hook_gpio_di_read(self, uc, access, address, size, value, user_data):
        """GPIO DI→DO loopback with DIR-aware ACK simulation.
        
        For each bit:
        - If DIR bit = 1 (output): return the DO value (master is driving)
        - If DIR bit = 0 (input):  return 0 (simulate slave pulling low = ACK)

        This makes I2C START succeed (SDA=output, DI returns 1) while also
        making ACK succeed (SDA=input after SET_SDA_IN, DI returns 0).  The
        panel decoder answers for the input pins of its own chip instead
        (di_override): a TM1650's idle bus reads high, its SDA low only while
        it acknowledges or sends a 0 bit -- and so do the board's other chips
        on GPIO pins (gpio_devices: a bit-banged I2C bus, pulled-up inputs).
        """
        self._device_access(uc)
        di_offset = address & 0xFFF
        do_offset = self._GPIO_DI_TO_DO.get(di_offset)
        dir_offset = self._GPIO_DI_TO_DIR.get(di_offset)
        if do_offset is not None and dir_offset is not None:
            mmio_base = address & 0xFFFFF000
            do_val = self._mmio_word(mmio_base + do_offset)
            dir_val = self._mmio_word(mmio_base + dir_offset)
            # Output bits (DIR=1): return DO value
            # Input bits (DIR=0): return 0 (simulated slave response),
            # unless the GPIO handler's object drives a line (the TM1650
            # decoder answers key reads on SDA: di_override)
            di_val = do_val & dir_val
            cb = self.gpio_callback
            if cb is not None:
                override = getattr(getattr(cb, '__self__', None), 'di_override', None)
                if override is not None:
                    di_val = override(di_offset, di_val)
            for device in self.gpio_devices:
                di_val = device.di_override(di_offset, di_val)
            di_val = di_val & ~dir_val | (do_val & dir_val)
            self._mmio_write_word(address, di_val)

    # Status bytes (offset in the MMIO window) of device operations that
    # complete at once: {offset: (start bit, done bits to set, bits to clear)}.
    #  * PMU (pmu_m36, 0xB8018D00): the application init sets bit 0x80 of
    #    +2 and polls bit 0x20 with udelay(2000), up to 36,848 times (6-7
    #    minutes in the simulator; the failure is then ignored).  The 13-bit
    #    calibration value read afterwards (+1, +2[4:0]) is only used on
    #    another chip revision and stays 0.
    #  * VCAP_M36F (0xB800F000), opened by the video output: the driver sets
    #    bit 0 of +0x4B and spins, without a timeout, until the hardware clears
    #    it again.
    #  * The M36xx's DMA controller (dma_s3601, 0xB800F200), which the SEE's
    #    video output opens (the URZ0086's vpo_open): dma_dma_start sets bit 0
    #    of +0x4B the same way (bit 2 stops it, bit 7 reads busy).
    _SELF_COMPLETING = {
        0x18D02: (0x80, 0x20, 0x00),
        0x0F04B: (None, 0x00, 0x01),
        0x0F24B: (None, 0x00, 0x01),
    }

    def _hook_selfcomplete_read(self, uc, access, address, size, value, user_data):
        """Reads of a self-completing status byte see the operation finished
        (idempotent, so a replayed load after an asynchronous stop is harmless)."""
        self._device_access(uc)
        off = address & 0x00FFFFFF
        for reg, (start, done, clear) in self._SELF_COMPLETING.items():
            if off <= reg < off + size:
                b = self._mmio_view[reg]
                if start is None or b & start:
                    self._mmio_view[reg] = (b | done) & ~clear & 0xFF

    # Video engine (the video decoder's hardware, registers at 0xB8004200).
    # When the application starts playing a channel, the decoder driver resets
    # the VE (vdec_reset_ve_hw: 0xB8000060, 0xB8000028 bit 1) and then checks
    # the VE status word (+0x28, or +0x88 on another chip revision) for its
    # busy / event bits 8-25 (masks 0x036FFF00 / 0x017FFF00); if any is set it
    # takes the firmware's fatal path 0x8000070C, which reboots into the
    # bootloader.  The register is RAM here and held the 0x318 the driver wrote
    # at init, so dump.bin rebooted two minutes after its first screen and
    # started over.  With no VE events to report those bits read clear -- on
    # the chips whose VE has them there (ChipFamily.ve_status: not the M36xx,
    # whose decoder keeps its bit offset at +0x28).
    _VE_STATUS_REGS = (0x4228, 0x4288)
    _VE_STATUS_MASK = 0x037FFF00

    def _hook_ve_status_read(self, uc, access, address, size, value, user_data):
        self._device_access(uc)
        if not self.chip.ve_status:
            return
        v = self._mmio_word(address)
        if v & self._VE_STATUS_MASK:
            self._mmio_write_word(address, v & ~self._VE_STATUS_MASK)

    @staticmethod
    def _hook_chip_id_store(uc, access, address, size, value, user_data):
        """A store to the chip ID word leaves it as it is (the chip's ID, its
        variant bits).  The Cabletech URZ0083's bootloader pulses bit 31 of
        it (0xB6020000, 0x36020000, ... 0xB6020000): kept, the application
        read its chip as 0xB602, which its chip table does not know, and its
        display driver's attach rebooted it every ~38 M instructions."""
        return int.from_bytes(uc.mem_read(address, size), 'little')

    def _hook_mac_reset_read(self, uc, access, address, size, value, user_data):
        """ETHERNET_MAC_0 +0 (0xB802C000): the software-reset bit 3 reads back
        clear -- the reset completes at once (nothing else of the MAC is
        modelled).  Without it the T650i's network driver spun on the bit
        forever and its task starved the UI."""
        self._device_access(uc)
        off = address & 0xFFFFFC
        b = self._mmio_view[off]
        if b & 0x08:
            self._mmio_view[off] = b & 0xF7

    def _hook_mac_mdio_read(self, uc, access, address, size, value, user_data):
        """ETHERNET_MAC_0 +0x7C (0xB802C07C): the driver writes PHY address
        (bits 21-25), register (bits 16-20) and 0x88000000 (bit 31 busy / go,
        bit 27 read), polls until bit 31 clears -- giving up after 1000 ms of
        firmware time and taking 0xFFFF -- and reads the data from +0x82.  No
        PHY is modelled: the access completes at once and reads 0xFFFF, which
        is what an MDIO bus without a PHY returns (it idles high) and what the
        driver's timeout path used, so the firmware ends up in the same state,
        without waiting a second for every PHY register it probes."""
        self._device_access(uc)
        v = self._mmio_word(0x2C07C)
        if v & 0x80000000:
            self._mmio_write_word(0x2C07C, v & 0x7FFFFFFF)
            if v & 0x08000000:                       # a read: the data a bus without a PHY gives
                self._mmio_view[0x2C082:0x2C084] = b'\xFF\xFF'

    # Graphics engine (GE_M36F, registers at 0xB800A000).  A command written to
    # +4 is executed at once by the ge_m36f model (it draws into RAM, see
    # ge_m36f.py; ge_render = False only completes it) and sets its bit in the
    # interrupt status +8 (write 1 to clear), which drives interrupt-controller
    # line 4.  The driver's ISR acks +8 and wakes the drawing task through an
    # event flag; without the interrupt every operation ended in its timeout
    # (0.5-6 s) and a GE reset, so the UI took minutes to come up.
    _GE_DONE = {1: 0x4, 2: 0x1, 3: 0x2}     # command -> status bit (the flag bit its caller waits for)
    _IC_GE = 4                               # interrupt-controller line (0xB8000030 bit 4)

    def _hook_ge_write(self, uc, access, address, size, value, user_data):
        self._device_access(uc)
        off = address & 0xFFF
        if off == 0x004:
            done = self._GE_DONE.get(value & 0xFFFFFFFF, 0)
            # (a store rewound by an asynchronous stop must not complete twice)
            if done and self._dev_replay_of(uc, 'ge', address, value) is None:
                self._dev_note(uc, 'ge', address, value)
                self.ge_ops += 1
                if self.ge_render:
                    self._ge_execute(value & 0xFFFFFFFF)
                self._ge_status |= done
                self._ic_set_line(self._IC_GE, True)
        elif off == 0x008:
            self._ge_status &= ~value
            if not self._ge_status:
                self._ic_set_line(self._IC_GE, False)

    def _ge_execute(self, command):
        """Run GE command 1 (the live registers), 2 / 3 (the HQ / LQ command
        list between its start and end pointers) on the RAM image."""
        np = _get_np()
        if np is None:
            return
        if self.ge is None:
            import ge_m36f
            ram = np.frombuffer(self.ram_buffer, dtype=np.uint8, count=self.ram_size)
            self.ge = ge_m36f.GeM36F(ram, log=self.log)
        regs_arr = np.frombuffer(self._mmio_view[0xA000:0xA100], dtype='<u4')
        if command == 1:
            self.ge.run_io(regs_arr if (self.ge.fast_paths and self.ge.trace is None) else regs_arr.tolist())
            return
        o = 0x10 if command == 2 else 0x18
        start, end = int(regs_arr[o >> 2]) & 0x1FFFFFFF, int(regs_arr[(o >> 2) + 1]) & 0x1FFFFFFF
        if start <= end < start + 0x400000 and end + 4 <= self.ram_size:
            words_view = self.ge.ram[start:end + 4].view('<u4')
            if self.ge.fast_paths and self.ge.trace is None:
                self.ge.run_list(words_view, regs_arr)
            else:
                self.ge.run_list(words_view.tolist(), regs_arr.tolist())

    def capture_screen(self, path=None, screen=(1280, 720), include_video=False):
        """What the TV would show of the OSD: the enabled GMA display layers
        (registers 0xB8006300 / 0xB8006304: enable, first region head in RAM)
        composited over black (or over the last decoded video frame when
        include_video=True; see gma_capture.py and video_m36.py), drawn into
        RAM by the GE model.  Returns an RGB uint8 array (height, width, 3) and
        writes a PNG if path is given.  Needs numpy (and Pillow or zlib for the
        PNG)."""
        import gma_capture
        np = _get_np()
        ram = np.frombuffer(self.ram_buffer, dtype=np.uint8, count=self.ram_size)
        osd = getattr(self.chip, "osd", None)          # (the M3329's OSD layers: their palettes)
        ve = getattr(self.chip, "video_engine", None)
        video_rgb = ve.decode_last_frame() if (include_video and ve is not None) else None
        rgb, _ = gma_capture.capture(ram, self._mmio_view[0:0x10000], screen,
                                     m3327_palettes=osd.palettes if osd is not None else None,
                                     video_rgb=video_rgb,
                                     ycbcr_bit=getattr(self.chip, "gma_ycbcr_bit", 0),
                                     head_matrix=getattr(self.chip, "gma_head_matrix", False))
        if path:
            gma_capture.save_png(path, rgb)
        return rgb

    def _hook_ge_read(self, uc, access, address, size, value, user_data):
        self._device_access(uc)
        self._mmio_write_word((address & ~0xFFF) | 0x008, self._ge_status)

    # IR receiver (M6303 IRC, registers at 0xB8018100, see ir_remote.py).  A
    # frame from ir_send_nec() is put into the run-length FIFO at once and
    # signalled as the idle timeout (status bit 1): the firmware's ISR
    # (irc_m6303irc_lsr) reads the FIFO count (+1) and drains the bytes (+8)
    # -- on that interrupt it also schedules its decoder -- and acknowledges
    # the status by writing it back (+7, write 1 to clear).  The status drives
    # interrupt-controller line 19 (OS IRQ 27) while enabled in IER (+6).
    _IC_IRC = 19
    IR_FRAME_GAP_S = 0.25            # emulation time between two frames (NEC repeats every 108 ms)
    I2C_SCB_BASES = (0x18200, 0x18700, 0x18B00)  # the hardware I2C masters (i2c_scb.py; the M3801's
                                                 # SCB0 / SCB1 and the M3821's), window offsets

    def _hook_irc_read(self, uc, access, address, size, value, user_data):
        self._device_access(uc)
        off = address & 0xFFF                   # (0x1xx at either base, irc_base)
        abs_off = address & 0xFFFFFF
        if off == 0x101:                                     # FIFO byte count
            self._mmio_view[abs_off] = min(len(self._irc_fifo), 0x7F)
        elif off == 0x107:                                   # interrupt status
            self._mmio_view[abs_off] = self._irc_status
        elif off == 0x108:                                   # RLC data: pops the FIFO
            rp = self._dev_replay_of(uc, 'irc', address)
            if rp is not None:
                self._mmio_view[abs_off] = rp[2]
            elif self._irc_fifo:
                b = self._irc_fifo.popleft()
                self._mmio_view[abs_off] = b
                self._dev_note(uc, 'irc', address, b)

    def _hook_irc_write(self, uc, access, address, size, value, user_data):
        self._device_access(uc)
        self._irc_status &= ~value & 0xFF
        self._irc_update_line()

    def _irc_update_line(self):
        ier = self._mmio_view[self.irc_base + 6]
        self._ic_set_line(self.irc_line, bool(self._irc_status & ier & 3))

    def _irc_service(self):
        """Between slices (emulation thread): receive the next queued IR frame
        once the previous one was taken and IR_FRAME_GAP_S has passed."""
        if not self._irc_frames or self._irc_fifo or self._irc_status:
            return
        if self._vtime() - self._irc_last_vt < self.IR_FRAME_GAP_S:
            return
        if not self._mmio_view[self.irc_base] & 0x80:   # IRCCFG: controller enabled
            return
        rlc, label = self._irc_frames.popleft()
        self._irc_fifo.extend(rlc)
        self._irc_status |= 0x02
        self._irc_last_vt = self._vtime()
        self.ir_keys_sent += 1
        self.log(f"[IR] {label}: {len(rlc)} RLC bytes")
        self._irc_update_line()

    def ir_send_nec(self, address, command, label=None, address_hi=None):
        """Queue an NEC remote-control frame (address, command bytes; address_hi
        for an extended-NEC second address byte instead of ~address) for the
        IR receiver.  Thread-safe: it is received at the next slice boundary
        of run(), at least IR_FRAME_GAP_S of emulation time after the previous
        frame and only while the firmware has the controller enabled."""
        import ir_remote
        self._irc_frames.append((ir_remote.nec_rlc(address, command, address_hi),
                                 label or f"NEC 0x{address:02X}/0x{command:02X}"))

    def attach_watchdog(self, memory_clock_hz=27_000_000):
        """Model the chip's watchdog's counter (watchdog.Watchdog at
        0xB8018500) -- opt-in, after loadFile: it counts in emulated time at
        memory_clock_hz / 2^(5+n) (27 MHz: as measured on a real S3811) and
        records every overflow in reset mode (.overflows), but does not reset
        the machine.  Returns the model (also self.watchdog)."""
        import watchdog
        wd = getattr(self, "watchdog", None)
        if wd is None or wd._read not in self._mmio_rd.get(wd.base, ()):   # (a family switch dropped it)
            self.watchdog = watchdog.Watchdog(self, memory_clock_hz=memory_clock_hz)
        return self.watchdog

    def attach_usb_host(self, base=0x32000, line=29):
        """Model the chip's USB host controller's port (usb_host.UsbHost: the
        S3811's at 0xB8032000, interrupt-controller line 29) -- opt-in, after
        loadFile; .attach(speed) / .detach() plug a device in and out.
        Returns the model (also self.usb)."""
        import usb_host
        usb = getattr(self, "usb", None)
        if usb is None or usb._read not in self._mmio_rd.get(usb.base, ()):  # (a family switch dropped it)
            self.usb = usb_host.UsbHost(self, base, line)
        return self.usb

    def attach_tuner(self, chip=None, address=None):
        """Put a tuner chip model (tuners.py) on the I2C bus: `chip` (a key of
        tuners.MODELS) at the 7-bit `address`, or by default the one the loaded
        dump's sidecar names (device.tunerModel, dump_catalog.py).  The driver
        then sees a tuner that takes its settings and locks.  Returns the model
        (None when the dump names none)."""
        import tuners
        sec = None
        if chip is None:
            import dump_catalog
            model = dump_catalog.tuner_model(self.dump_path) if getattr(self, "dump_path", None) else None
            if not model:
                return None
            chip = model["chip"]
            address = model["address"] if address is None else address
            config = {k: model[c] for k, c in (("xtal_hz", "xtalHz"), ("if_hz", "ifHz")) if c in model}
            sec = model.get("secondary")
        elif address is None:
            raise ValueError("attach_tuner: give the tuner's 7-bit I2C address with its chip")
        else:
            config = {}
        device = tuners.make(chip, **config)
        self.i2c_devices[address] = device
        self.log(f"[I2C] tuner model {chip} at 0x{address:02X}")
        if sec:
            sec_cfg = {k: sec[c] for k, c in (("xtal_hz", "xtalHz"), ("if_hz", "ifHz")) if c in sec}
            self.i2c_devices[sec["address"]] = tuners.make(sec["chip"], **sec_cfg)
            self.log(f"[I2C] tuner model {sec['chip']} at 0x{sec['address']:02X}")
        if self._demod_address is not None and self._demod_address in self.i2c_devices:
            ext_demod = self.i2c_devices[self._demod_address]
            if hasattr(ext_demod, "tuner"):
                ext_demod.tuner = device
        return device

    def attach_demod(self):
        """Put the loaded board's external demodulator (demods.py: its
        sidecar's device.demodModel) on the I2C bus, in place of the one
        the previous image's board had; loadFile calls it.  Returns the
        model, or None when the board names none."""
        import demods
        import dump_catalog
        if self._demod_address is not None:
            if self.i2c_devices.get(self._demod_address) is self._demod_device:
                del self.i2c_devices[self._demod_address]
            self._demod_address = None
            self._demod_device = None
        given = dump_catalog.demod_model(self.dump_path) if getattr(self, "dump_path", None) else None
        if given is None:
            return None
        chip, address = given
        self.i2c_devices[address] = device = demods.make(chip, tuned=self.tuned_to_signal)
        if hasattr(device, "tuner"):
            device.tuner = self.tuner()
        self._demod_address = address
        self._demod_device = device
        self.log(f"[I2C] demodulator model {chip} at 0x{address:02X}")
        return device

    def attach_gpio_devices(self):
        """Put the loaded board's other chips on GPIO pins in place of the
        previous board's (loadFile calls it): the I2C bus its firmware
        bit-bangs to its tuner or other chips (its sidecar's device.gpioI2c,
        gpio_i2c.py; the slaves are sim.i2c_devices, as on the hardware
        masters) and the input pins its board pulls up (device.gpioPullUps:
        they read high, gpio_keys.GpioKeys that nobody presses).  Returns
        the list, sim.gpio_devices."""
        import dump_catalog
        from gpio_i2c import GpioI2cBus
        from gpio_keys import GpioKeys
        self.gpio_devices = []
        path = getattr(self, "dump_path", None)
        if not path:
            return self.gpio_devices
        bus = dump_catalog.gpio_i2c(path)
        if bus:
            self.gpio_devices.append(GpioI2cBus(self, *bus))
            self.log(f"[I2C] bit-banged bus on GPIO {bus[0]} (SCL) / {bus[1]} (SDA)")
        pull_ups = dump_catalog.gpio_pull_ups(path)
        if pull_ups:
            self.gpio_devices.append(GpioKeys(pull_ups))
        from front_panel import panel_spec
        from lemontree_decoder import LemontreeDecoder
        spec = panel_spec(path)
        if spec.get("chip") == "lemontree" and not isinstance(getattr(self.gpio_callback, "__self__", None), LemontreeDecoder):
            self.gpio_devices.append(LemontreeDecoder(spec["scl"], spec["sda"], log_handler=lambda m: None))
        return self.gpio_devices

    def tuner(self):
        """The tuner model on the I2C bus (tuners.py), or None."""
        devs = self.i2c_devices
        if not devs:
            return None
        import tuners
        ts = [d for d in devs.values() if tuners.is_tuner(d)]
        if not ts:
            return None
        if len(ts) == 1:
            return ts[0]
        return next((d for d in ts if d.frequency() is not None), ts[0])

    def tuner_info(self):
        """What the tuner is tuned to, one line (tuners.describe), or None
        without a tuner model."""
        import tuners
        return tuners.describe(self.tuner())

    def set_signal(self, on=True, frequencies=None):
        """A receivable channel: the dump's tuner model on the I2C bus
        (attach_tuner) and the chip family's demodulator reporting lock
        (chips/m3801.py, chips/m3821.py, chips/m3602.py, chips/m3503.py, or an
        external I2C demodulator in demods.py) -- on every frequency, or with
        `frequencies` (Hz) only while the tuner model is tuned to one of them
        (tuned_to_signal), as an antenna receives a few multiplexes: a channel
        search then finds those and nothing elsewhere.  There is no transport
        stream behind it (attach_mux), so the firmware finds a locked channel
        with nothing in it.  Returns (tuner model or None, demodulator
        modelled)."""
        tuner = self.tuner()
        if on and tuner is None:
            tuner = self.attach_tuner()
        self.signal_frequencies = None if frequencies is None else tuple(frequencies)
        demod = self.chip.set_signal(on)
        for dev in self.i2c_devices.values():
            if hasattr(dev, "set_signal"):
                dev.set_signal(on)
                if hasattr(dev, "tuner") and dev.tuner is None:
                    dev.tuner = tuner
                demod = True
        if not demod:
            self.log(f"[NIM] {self.chip.name}: no demodulator model, the firmware sees no lock")
        return tuner, demod

    SIGNAL_TOLERANCE_HZ = 1_000_000     # a terrestrial channel raster is 7 or 8 MHz

    def tuned_to_signal(self):
        """Whether the tuner sits on a frequency with a signal: any frequency
        unless set_signal() named some; then the tuner model must be tuned
        within SIGNAL_TOLERANCE_HZ of one of them (not while it calibrates)."""
        freqs = self.signal_frequencies
        if freqs is None:
            return True
        devs = self.i2c_devices
        if not devs:
            return False
        key = (freqs, tuple((id(d), getattr(d, "writes", None), getattr(d, "rf_hz", None)) for d in devs.values()))
        cache = self.__dict__.get("_tuned_cache")
        if cache is not None and cache[0] == key:
            return cache[1]
        tuner = self.tuner()
        f = tuner.frequency() if tuner is not None else None
        if not f or f.get("calibrating"):
            res = False
        else:
            res = any(abs(f["rf_hz"] - hz) <= self.SIGNAL_TOLERANCE_HZ for hz in freqs)
        self._tuned_cache = (key, res)
        return res

    def attach_mux(self, mux=None):
        """Put a transport stream behind the locked channel: the chip family's
        demultiplexer model (dmx_m36.Demux, chips/m3801.py and m3602.py) feeds
        the tables of `mux` (a transport_stream.Mux; by default one service,
        "AliSimulator TV") to the firmware's PID filters, so a channel change
        finds its PAT / PMT / SDT instead of waiting for them.  Usually with
        set_signal(True).  Returns the demultiplexer model, or None when the
        family has none."""
        dmx = getattr(self.chip, "dmx", None)
        if dmx is None:
            self.log(f"[DMX] {self.chip.name}: no demultiplexer model")
            return None
        if mux is None:
            import transport_stream
            mux = transport_stream.Mux()
        dmx.mux = mux
        if dmx.service not in self.slice_services:
            self.slice_services.append(dmx.service)
        self.log(f"[DMX] transport stream attached: {', '.join(s.name for s in mux.services)}")
        return dmx

    def dmx_info(self):
        """What the demultiplexer model is doing, one line, or None without one."""
        dmx = getattr(self.chip, "dmx", None)
        return dmx.describe() if dmx is not None else None

    def attach_smart_card(self, inserted=True, atr=None, ca_system_id=0x0B00):
        """Insert or remove an ISO 7816-3 T=0 smart card in the Smart Card
        Reader controller (smc_m36.SmartCard at 0xB8018800; by default a Conax
        0x0B00 card with ATR 3B 24 00 30 42 30 30).  Returns the SmartCard
        model."""
        self.smc.ca_system_id = ca_system_id
        self.smc.set_card(inserted=inserted, atr=atr)
        self.log(f"[SMC] smart card {'inserted' if inserted else 'removed'} (CA 0x{self.smc.ca_system_id:04X})")
        return self.smc

    def press_key(self, key, coding=None):
        """Press a remote-control key: a name of ir_remote.VKEYS ('UP', 'DOWN',
        'OK', 'MENU', 'EXIT', '0'..'9', ...) or a virtual key number.  The NEC
        code is looked up in the UI's own key table, found in RAM the first
        time (so only after the application has started).  Returns the
        (address, command) sent.  A chip family whose firmware keeps another
        kind of table (the M3329's) gives the frame itself: remote_frame()."""
        import ir_remote
        frame = self.chip.remote_frame(key) if hasattr(self.chip, "remote_frame") else None
        if frame is not None:
            address, command, address_hi = frame
            self.ir_send_nec(address, command, label=f"key {key}", address_hi=address_hi)
            return address, command
        vkey = ir_remote.VKEYS[key.upper()] if isinstance(key, str) else int(key)
        if not self._ir_key_table:
            np = _get_np()
            ram = np.frombuffer(self.ram_buffer, dtype=np.uint8, count=self.ram_size)
            self._ir_key_table = ir_remote.find_key_table(ram)
            if not self._ir_key_table:
                raise RuntimeError("no remote key table in RAM (has the application started?)")
        if vkey not in self._ir_key_table and isinstance(key, str):
            # the firmware may number this key differently (ir_remote.VKEY_FALLBACKS)
            vkey = next((v for v in ir_remote.VKEY_FALLBACKS.get(key.upper(), ())
                         if v in self._ir_key_table), vkey)
        if vkey not in self._ir_key_table:
            raise KeyError(f"key {key!r} (vkey {vkey}) is not in the firmware's key table")
        # the frame bytes a table code stands for depend on the firmware's SDK
        # generation (ir_remote.IR_CODINGS; set from the dump's name by loadFile)
        address, command, address_hi = ir_remote.frame_from_ir16(self._ir_key_table[vkey], coding or self.ir_coding)
        if address_hi is None:
            self.ir_send_nec(address, command, label=f"key {key}")
        else:
            self.ir_send_nec(address, command, label=f"key {key}", address_hi=address_hi)
        return address, command

    def _hook_ic_status_read(self, uc, access, address, size, value, user_data):
        """Interrupt-controller status (0xB8000030 / 34; the SEE's at 0xB8040030 /
        34, ic_base; or 4 words at 0xB8081080..8C on C3507) shows the asserted
        lines (a write-back acknowledge does not clear a line its device still drives)."""
        lines = self._ic_lines
        if lines:
            for word in range(4):
                bits = (lines >> (32 * word)) & self._M32
                if bits:
                    a = self._ic + 4 * word
                    self._mmio_write_word(a, self._mmio_word(a) | bits)

    def _ic_set_line(self, line, on):
        """Drive an interrupt-controller input of a modelled device (a level):
        its status bit (0xB8000030 / 34, at ic_base) follows it, and while it
        is asserted and enabled (0xB8000038 / 3C) the CPU sees IP3."""
        bit = 1 << line
        was = self._ic_lines
        addr = self._ic + 4 * (line // 32)
        b = 1 << (line % 32)
        cur = self._mmio_word(addr)
        if on:
            if (was & bit) and (cur & b):
                return
            self._ic_lines = was | bit
            self._mmio_write_word(addr, cur | b)
            if not (was & bit):
                self._irq_soon()
        else:
            if not (was & bit) and not (cur & b):
                return
            self._ic_lines = was & ~bit
            self._mmio_write_word(addr, cur & ~b)

    def _ic_ip3(self):
        """IP3 from the interrupt controller: a modelled line asserted and
        enabled, or the other CPU's doorbell (_doorbell_ip3)."""
        lines = self._ic_lines
        if lines:
            en = self._mmio_word(self._ic_en) | (self._mmio_word(self._ic_en + 4) << 32)
            if lines >> 64:
                en |= (self._mmio_word(self._ic_en + 8) << 64) | (self._mmio_word(self._ic_en + 12) << 96)
            if lines & en:
                return True
        return self._doorbell_ip3()

    def set_ic_layout(self, status, enable):
        """Where a chip's interrupt controller keeps its status and enable
        words (device-window offsets; the M3329's 0x38 and 0x3C, which take
        lines 0..31 only, or the C3507's 4-word controller at 0x81080 and
        0x81040): the modelled devices' lines go there.  A chip family calls it
        from install() (and with 0x30, 0x38 from uninstall())."""
        if self._ic != 0xB8000000 + self.ic_base:
            old_s = self._ic - 0xB8000000
            old_e = self._ic_en - 0xB8000000
            old_span = min(16, abs(old_e - old_s)) if old_e != old_s else 8
            self._mmio_off('r', self._hook_ic_status_read, old_s, old_s + old_span - 1)
        self._ic = 0xB8000000 + status
        self._ic_en = 0xB8000000 + enable
        if status != self.ic_base:
            span = min(16, abs(enable - status)) if enable != status else 8
            self._mmio_on('r', self._hook_ic_status_read, status, status + span - 1)

    def _doorbell_ip3(self):
        """The other CPU of a dual-CPU chip rings this one (chips/see.py
        Doorbells): its channel 1 / 2 ring bits (doorbell_in: their byte's
        offset in the device window and the shift that puts them at bits 7 /
        6) are this CPU's OS IRQ 0x47 / 0x46, interrupt controller lines 63 /
        62, which assert IP3 while their enable bits (31 / 30 of the second
        enable word) are set -- the SDK's OS_RegisterISR sets them --, but do
        not show in the status words: the dispatcher reads the ring byte
        itself, and takes an IP3 without status for a ring."""
        if self.doorbell_in is None:
            return False
        offset, shift = self.doorbell_in
        return bool((self._mmio_view[offset] << shift) & self._mmio_view[self.ic_base + 0xF] & 0xC0)

    def _irq_soon(self):
        """A device raised an interrupt from a memory hook.  Fast mode, inside a
        slice: end the slice at the next hooked CP0 instruction (or by the
        asynchronous backstop) so that run() delivers it.  Not emu_stop() here:
        Unicorn would finish the translation block first and skip the CP0
        hooks in it (see async_stop_margin_us).  Exact mode delivers it at the
        next instruction anyway."""
        if self._in_run and self._code_hook_h is None and self._slice_cap_end is not None:
            if self._slice_uses_stopper:
                self._arm_deadline(0.0)
                self._slice_armed_end = self._vtime()
            else:
                self._slice_deadline = time.perf_counter()

    def _hook_spi_write(self, uc, access, address, size, value, user_data):
        """Handle writes to SPI flash controller registers.

        Matches the hardware register interface from flash_raw_sl_c.c:
          SF_INS (+0x98) — SPI command/instruction
          SF_FMT (+0x99) — format (which bus phases are active)
          SF_DUM (+0x9A) — dummy/data register
          SF_CFG (+0x9B) — configuration
        The firmware also writes INS+FMT together with one 16-bit store, so
        every byte of the access is dispatched to its own register.
        """
        self._dev_last = None
        if self._spi_dump_enabled:
            if self._dev_replay_of(uc, 'spi_reg', address, value) is not None:
                return      # the same store again after a stop at it (e.g. to install the flash read hook)
            self._dev_note(uc, 'spi_reg', address, value)
        other_base = 0x00090 if (address & 0xFFFF0) == 0x2E090 else 0x2E090
        reg = address & 0xF
        if size == 1:
            byte = value & 0xFF
            self._mmio_view[other_base | reg] = byte
            if reg == 0x8:
                if byte == self._spi_ins and not self._rom_dirty and not self._spi_dump_enabled:
                    if byte == 0x05 and self._spi_status_injected:
                        self._spi_resp_idx = 0
                        return
                    if byte in self._SPI_READS and not self._flash_read_hooks and (self._spi_stream is None or not self._spi_stream.active):
                        return
                self._spi_write_ins(uc, byte)
            elif reg == 0x9:
                self._spi_fmt = byte
                if self._spi_dump_enabled:
                    self._spi_write_fmt(byte)
            elif reg == 0xA:
                self._spi_dum = byte
            elif reg == 0xB:
                self._spi_cfg = byte
            return
        if size == 2 and reg == 0x8:
            ins_b = value & 0xFF
            fmt_b = (value >> 8) & 0xFF
            if self._mmio_halfwords is not None:
                self._mmio_halfwords[(other_base | 8) >> 1] = value & 0xFFFF
            else:
                self._mmio_view[other_base | 8] = ins_b
                self._mmio_view[other_base | 9] = fmt_b
            self._spi_fmt = fmt_b
            if not self._spi_dump_enabled:
                if ins_b == self._spi_ins and not self._rom_dirty:
                    if ins_b == 0x05 and self._spi_status_injected:
                        self._spi_resp_idx = 0
                        return
                    if ins_b in self._SPI_READS and not self._flash_read_hooks and (self._spi_stream is None or not self._spi_stream.active):
                        return
                self._spi_write_ins(uc, ins_b)
                return
            self._spi_write_ins(uc, ins_b)
            self._spi_write_fmt(fmt_b)
            return
        for i in range(size):
            r = (address + i) & 0xF
            byte = (value >> (8 * i)) & 0xFF
            self._mmio_view[other_base | r] = byte
            if r == 0x8:
                self._spi_write_ins(uc, byte)
            elif r == 0x9:
                self._spi_fmt = byte
                if self._spi_dump_enabled:
                    self._spi_write_fmt(byte)
            elif r == 0xA:
                self._spi_dum = byte
            elif r == 0xB:
                self._spi_cfg = byte

    def _spi_write_ins(self, uc, cmd):
        """SF_INS written: latch the SPI command and queue its response bytes."""
        if not self._spi_dump_enabled and not self._rom_dirty and not self._flash_read_hooks \
                and self.flash_device is None and (self._spi_stream is None or not self._spi_stream.active):
            if cmd in self._SPI_READS:
                if self._spi_status_injected:
                    self._spi_status_injected = False
                    if self.rom_image is not None:
                        self._rom_view[0:4] = self.rom_image[0:4]
                self._spi_ins = cmd
                self._last_flash_read_page = -1
                self._flash_hooks_pending = False
                self._spi_resp_idx = 0
                self._spi_response = []
                return
            if cmd == 0x05 and self._spi_can_inline_status():
                if not self._spi_status_injected:
                    if self._rom_words is not None:
                        self._rom_words[0] = 0
                    else:
                        self._rom_view[0:4] = b'\x00\x00\x00\x00'
                    self._spi_status_injected = True
                self._spi_ins = 0x05
                self._last_flash_read_page = -1
                self._flash_hooks_pending = False
                self._spi_resp_idx = 0
                self._spi_response = [0]
                return
        if cmd == self._spi_ins and not self._rom_dirty and not self._spi_dump_enabled:
            if cmd == 0x05 and self._spi_status_injected:
                self._spi_resp_idx = 0
                return
            if cmd in self._SPI_READS and not self._flash_read_hooks and (self._spi_stream is None or not self._spi_stream.active):
                return
        if self._spi_status_injected and cmd != 0x05:
            self._uninject_spi_status()
        if self._rom_dirty:
            self._rom_restore()          # response bytes must not survive into normal read mode
        self._spi_ins = cmd
        self._last_flash_read_page = -1  # Reset so next passthrough read always logs
        if cmd == 0x05 and self._spi_can_inline_status():
            self._rom_view[0:4] = b'\x00\x00\x00\x00'
            self._spi_status_injected = True
        self._update_flash_read_hooks()
        if self._spi_dump_enabled:
            cmd_name = self._SPI_CMD_NAMES.get(cmd, "Unknown")
            pc = self._reg_read(UC_MIPS_REG_PC)
            # (fast mode: inside a device access Unicorn's PC is the translation block start)
            where = f"PC=0x{pc:08X}" if self._code_hook_h is not None else f"block at 0x{pc:08X}"
            self._spi_log(f"CMD 0x{cmd:02X} ({cmd_name}) [{where}]")
        self._spi_resp_idx = 0
        self._spi_response = self._spi_command_response(cmd)
        if cmd in (0x06, 0x04):     # Write Enable / Disable
            self._spi_set_wel(cmd == 0x06)

    def _spi_set_wel(self, on):
        """The part's write-enable latch (status bit 1): set by WREN, cleared by
        WRDI and by every command it enabled (WRSR, erase, page program)."""
        self._spi_wel = on
        self._spi_status = (self._spi_status | 0x02) if on else (self._spi_status & ~0x02)

    def _spi_command_response(self, cmd):
        """The bytes the part answers a command with (the ID and status reads);
        WRSR / reads / program / erase have none."""
        if cmd == 0x9F:      # JEDEC Read ID: 3 bytes, padded to 4 for word reads
            return list(self._spi_jedec_id) + [0x00]
        if cmd == 0x05:      # Read Status Register: bit0=WIP, bit1=WEL, bits[5:2]=BP
            return [self._spi_status]
        if cmd == 0xAB:      # Release from Deep Power Down / Read Electronic ID
            # A real part clocks its electronic ID out after the 3 dummy bytes,
            # repeatedly: one below the JEDEC capacity byte (W25Q32 / MX25L3205
            # 0x15, W25Q64 / MX25L6405 0x16).  The ALi drivers read it without
            # a dummy phase and match byte 3 ("0x15, 56 /*MX25L3205*/", "0x16,
            # 56 /*MX25L6405D*/"); the newer tables also know 4 MB parts by
            # the JEDEC capacity byte ("0x16, 16"), the Ferguson T50's 2009
            # bootloader only by this read -- with 0x00 there it attached no
            # flash device and rebooted.
            res = (self._spi_jedec_id[2] - 1) & 0xFF
            return [res, res, res, res]
        if cmd == 0x90:      # Read Manufacturer/Device ID
            return [self._spi_jedec_id[0], self._spi_jedec_id[2],
                    self._spi_jedec_id[0], self._spi_jedec_id[2]]
        return []

    def _spi_response_bytes(self, size):
        """The next `size` bytes the part clocks out for a flash-window load:
        the stream's while a chip family's byte-stream mode is on, else what is
        left of the last SF_INS command's response, then 0x00 (idle, not busy)."""
        stream = self._spi_stream
        if stream is not None and stream.active:
            return stream.read(size)
        resp = bytearray(size)
        for i in range(size):
            if self._spi_resp_idx < len(self._spi_response):
                resp[i] = self._spi_response[self._spi_resp_idx]
                self._spi_resp_idx += 1
        return bytes(resp)

    def _spi_write_fmt(self, value):
        self._spi_fmt = value
        if not self._spi_dump_enabled:
            return
        flags = []
        if value & 0x01: flags.append("DATA")
        if value & 0x02: flags.append("DUMM")
        if value & 0x04: flags.append("ADDR")
        if value & 0x08: flags.append("CODE")
        if value & 0x40: flags.append("CONT_RD")
        if value & 0x80: flags.append("CONT_WR")
        self._spi_log(f"  FMT 0x{value:02X} [{' | '.join(flags)}]")

    def _hook_spi_read(self, uc, access, address, size, value, user_data):
        """Handle reads from SPI flash controller registers.

        Firmware does volatile readback of registers it just wrote
        (e.g. write SF_INS then read SF_INS back). Return the stored values.
        """
        self._device_access(uc)
        base_off = address & 0xFFFFFF
        for i in range(size):
            reg = (address + i) & 0xF
            if reg == 0x8:
                self._mmio_view[base_off + i] = self._spi_ins & 0xFF
            elif reg == 0x9:
                self._mmio_view[base_off + i] = self._spi_fmt & 0xFF
            elif reg == 0xA:
                self._mmio_view[base_off + i] = self._spi_dum & 0xFF
            elif reg == 0xB:
                self._mmio_view[base_off + i] = self._spi_cfg & 0xFF

    def _spi_is_passthrough(self):
        """Check if SPI controller is in normal flash read mode (passthrough).
        
        In normal read mode, reads from SYS_FLASH_BASE_ADDR return actual
        flash content. The controller is in passthrough when:
          SF_INS = 0x03 (Read), 0x0B (Fast Read) or a dual / quad read

        Note: SF_HIT_ADDR may or may not be set. In CONT_RD mode the firmware
        sets FMT=0x0D (DATA|ADDR|CODE) for the first read, then FMT=0x09
        (DATA|CODE) for sequential reads without address phase.

        The dual and quad reads (0x3B, 0x6B, 0xBB, 0xEB) deliver the same
        bytes, only faster: the M3601E / M3606 bootloaders switch to the quad
        I/O read 0xEB under the chip ID 0x3603 (the Cabletech URZ0083's and
        URZ0086's), and their chunk headers read as zeros while only 0x03 /
        0x0B counted -- "malloc size: 0, please check the application!".

        A chip family's byte-stream mode (chips/m3821.py) takes the window
        over while it is on, whatever SF_INS says.
        """
        stream = self._spi_stream
        return self._spi_ins in self._SPI_READS and not (stream is not None and stream.active)

    _SPI_READS = (0x03, 0x0B, 0x3B, 0x6B, 0xBB, 0xEB)
    _SPI_NO_READ_HOOK = frozenset((0x01, 0x02, 0x04, 0x06, 0x20, 0x32, 0x52, 0x60, 0xAD, 0xC7, 0xD8))

    def _flash_offset(self, address):
        """Offset into the flash image for any mirror of the memory-mapped flash.

        The 16 MB windows (physical 0x0F000000 / 0x1F000000) show flash offset
        0 at their 0x..C00000 slot (SYS_FLASH_BASE_ADDR 0xAFC00000, the reset
        vector 0xBFC00000); a part larger than 4 MB shows its 4 MB segment n
        at 0x..C00000 - n * 4 MB -- the SDK's flash driver reaches offset o at
        SYS_FLASH_BASE_ADDR - (o & 0xC00000) + (o & 0x3FFFFF) ("M3329E and
        M3202 SFlash addr mapping in 8M or 16M", flash_raw_sl_c.c).  For 4 MB
        and smaller parts this is the address modulo rom_size."""
        rel = address & 0x00FFFFFF
        seg = (0xC00000 - (rel & 0xC00000)) >> 22
        return ((seg << 22) | (rel & 0x3FFFFF)) % self.rom_size

    def _rom_write(self, off, data):
        """Write bytes at flash offset off into the shared ROM buffer (wrapping
        at the end of the flash like the next mirror does); see _flash_offset for
        the layout."""
        if not isinstance(data, (bytes, bytearray)):
            data = bytes(data)
        n_total = len(data)
        if 0 <= off and off + n_total <= self.rom_size:
            self._rom_view[off:off + n_total] = data
            return
        mv = memoryview(data)
        pos = 0
        while pos < n_total:
            o = (off + pos) % self.rom_size
            n = min(n_total - pos, self.rom_size - o)
            self._rom_view[o:o + n] = mv[pos:pos + n]
            pos += n

    def _rom_restore(self):
        """Undo transient writes to the memory-mapped flash window (see rom_image;
        a parallel flash in autoselect mode shows its IDs there instead)."""
        for off, size in self._rom_dirty:
            end = min(off + size, self.rom_size)
            if self.flash_device is None:
                self._rom_write(off, self.rom_image[off:end])
            else:
                self._rom_write(off, self.flash_device.read(off, end - off))
        self._rom_dirty.clear()
        if self._spi_status_injected:
            self._rom_view[0:4] = b'\x00\x00\x00\x00'

    def _flash_program(self, off, byte):
        """Program one byte: flash can only clear bits until the sector is erased."""
        if off < self.rom_size:
            self.rom_image[off] &= byte
            self._rom_sites_dirty = True

    def _flash_erase(self, start, length):
        start = min(start, self.rom_size)
        length = min(length, self.rom_size - start)
        self.rom_image[start:start + length] = b'\xFF' * length
        self._rom_write(start, b'\xFF' * length)
        self._rom_sites_dirty = True

    def _rom_inject(self, uc, address, off, data):
        """Put transient bytes (SPI responses) into the flash window for the
        load at `address`, always through the writable 0xAFC00000 view of the
        ROM buffer.  A Python write to the guest's read-only flash mapping
        makes Unicorn toggle its protection, and doing that from a hook while
        the CPU runs crashed Unicorn natively ('access violation reading
        0xAFC00000' in 1 of 30 Prima boots; 0 of 105 since).  Reverted by _rom_restore."""
        self._rom_write(off, data)              # (a load across the end of a mirror reads the next one)

    def _hook_spi_flash_read(self, uc, access, address, size, value, user_data):
        self._dev_cb_depth += 1
        try:
            self._spi_flash_read(uc, address, size)
        finally:
            self._dev_cb_depth -= 1

    def _spi_flash_read(self, uc, address, size):
        """Handle reads from the memory-mapped flash region (SYS_FLASH_BASE_ADDR).

        When the SPI controller is in command mode (not passthrough), reads
        from the flash address space return SPI response data instead of
        flash content. This implements the hardware behavior where:

          write_uint8(SF_FMT, SF_HIT_CODE | SF_HIT_DATA);  // command mode
          write_uint8(SF_INS, 0x9F);                         // JEDEC Read ID
          result = *(volatile UINT32 *)SYS_FLASH_BASE_ADDR;  // read response

        The response bytes are placed in the ROM buffer for this one load and
        restored from rom_image before the next flash-window load (and at the
        next instruction in exact mode), so they never leak into the flash
        contents the firmware reads later.
        """
        rel = address & 0x00FFFFFF
        off = 0 if rel == 0xC00000 else self._flash_offset(address)
        if self._spi_is_passthrough():
            if self._rom_dirty:
                self._rom_restore()      # undo the previous transient bytes before this load
            self._dev_last = None        # (a plain flash read: no side effect, nothing to replay)
            # Log flash read offset (throttled: only when 64KB sector changes)
            sector = off >> 16
            if self._spi_dump_flash_reads and self._last_flash_read_page != sector:
                self._last_flash_read_page = sector
                self._spi_log(f"  FLASH READ @ 0x{off:06X} (sector {sector})")
            return  # Normal read mode — let ROM content pass through
        if self._spi_status_injected and off + size <= 4:
            if self._rom_dirty:
                self._rom_restore()
            self._dev_last = None
            return

        # Command mode — inject SPI response data (skip restoring the exact same slot we overwrite)
        same_dirty = len(self._rom_dirty) == 1 and self._rom_dirty[0] == (off, size)
        if self._rom_dirty and not same_dirty:
            self._rom_restore()
            same_dirty = False
        self._device_access(uc, hooked=True)
        if self._dev_replays:
            rp = self._dev_replay_of(uc, 'spi', address)
            if rp is not None and len(rp[2]) == size:
                self._rom_inject(uc, address, off, rp[2])   # replay: the same response bytes again
                if not same_dirty:
                    self._rom_dirty.append((off, size))
                return
        stream = self._spi_stream
        resp = stream.read(size) if (stream is not None and stream.active) else self._spi_response_bytes(size)
        if off + size <= self.rom_size:
            self._rom_view[off:off + size] = resp
        else:
            self._rom_write(off, resp)
        if not same_dirty:
            self._rom_dirty.append((off, size))
        self._dev_note(uc, 'spi', address, resp, exact=True)    # (memory hook: exact PC)
        if self._spi_dump_enabled and self._spi_response:
            self._spi_log(f"  RESP [{size}B]: {' '.join(f'{b:02X}' for b in resp)}")

    def _hook_spi_flash_write(self, uc, access, address, size, value, user_data):
        """Handle writes to the memory-mapped flash region (SYS_FLASH_BASE_ADDR).

        Memory-mapped writes trigger SPI command execution:
          - WREN/WRDI (cmd 0x06/0x04): trigger via write to any flash address
          - WRSR (cmd 0x01): the write data is the new status register value
          - Erase (cmd 0x20/0x52/0xD8/0xC7/0x60): erase the sector containing
            the address (or the whole chip)
          - Page Program (cmd 0x02) / AAI (0xAD): program the data bytes

        The guest's store itself is reverted later (see _hook_flash_write_prot);
        only the emulated program/erase changes rom_image.
        """
        self._device_access(uc, hooked=True)
        if self._spi_status_injected:
            self._uninject_spi_status()
        if self._rom_dirty:
            self._rom_restore()
        off = self._flash_offset(address)
        self._rom_dirty.append((off, size))
        if self._spi_is_passthrough():
            return  # Normal mode — a write to the flash window has no effect

        data = value.to_bytes(size, 'little')
        stream = self._spi_stream
        if stream is not None and stream.active:
            # the bytes go out to the part (once: a stop at this store replays it)
            if self._dev_replay_of(uc, 'spi_stream', address, data) is None:
                self._dev_note(uc, 'spi_stream', address, data, exact=True)
                stream.write(data)
            return
        self._spi_execute(self._spi_ins, off, data)
        if size in (1, 4) and self._spi_ins in (0x02, 0x32) and self._code_hook_h is None and not self._spi_dump_enabled \
                and self.flash_device is None:
            self._spi_fast_page_program(address, off, size)

    def _spi_fast_page_program(self, address, off, size=1):
        """Fast-forward the remaining bytes of an ALi SDK sflash_write byte or
        word loop in fast mode so multi-megabyte first-boot flash
        initializations do not fault on every store."""
        pc = self._reg_read(UC_MIPS_REG_PC)
        phys_pc = pc & 0x1FFFFFFF
        if not (16 <= phys_pc and phys_pc + 128 <= self._mapped_ram_size and not (phys_pc & 3)):
            return
        rw = self._ram_words
        if size == 4:
            w_idx = phys_pc >> 2
            w_sw, w_addi, w_sltu, w_bnez, w_adds = (
                rw[w_idx], rw[w_idx + 1], rw[w_idx + 2], rw[w_idx + 3], rw[w_idx + 4])
            if (w_sw & 0xFC00FFFF) == 0xAC000000 and (w_addi & 0xFC00FFFF) == 0x24000004 \
                    and (w_sltu & 0xFC0007FF) == 0x0000002B and (w_adds & 0xFC00FFFF) == 0x24000004:
                r_i = (w_addi >> 21) & 0x1F
                r_len = (w_sltu >> 16) & 0x1F
                r_cmp = (w_sltu >> 11) & 0x1F
                r_src = (w_adds >> 21) & 0x1F
                if ((w_addi >> 16) & 0x1F) == r_i and ((w_sltu >> 21) & 0x1F) == r_i \
                        and ((w_adds >> 16) & 0x1F) == r_src \
                        and (w_bnez >> 16) == (0x1400 | (r_cmp << 5)) \
                        and (w_bnez & 0xFFFF) in (0xFFF9, 0xFFF0):
                    gmap = self.gpr_map
                    i_val = self._reg_read(gmap[r_i])
                    len_val = self._reg_read(gmap[r_len])
                    rem = (len_val - (i_val + 4)) & ~3
                    if 0 < rem <= 0x400000:
                        src_addr = self._reg_read(gmap[r_src])
                        src_phys = (src_addr + 4) & 0x1FFFFFFF
                        dst_off = off + 4
                        if src_phys + rem <= self._mapped_ram_size and dst_off + rem <= self.rom_size \
                                and ((address & 0x3FFFFF) + 4 + rem) <= 0x400000:
                            src_mv = self._ram_view[src_phys:src_phys + rem]
                            if self.rom_image[dst_off:dst_off + rem] == b'\xFF' * rem:
                                self.rom_image[dst_off:dst_off + rem] = src_mv
                            else:
                                for k in range(rem):
                                    self.rom_image[dst_off + k] &= src_mv[k]
                            self._rom_view[dst_off:dst_off + rem] = self.rom_image[dst_off:dst_off + rem]
                            self._rom_sites_dirty = True
                            self._reg_write(gmap[r_src], (src_addr + rem) & 0xFFFFFFFF)
                            self._reg_write(gmap[r_i], (i_val + rem) & 0xFFFFFFFF)
            return
        if True:
            i0 = phys_pc >> 2
            if i0 >= 3 and (
                rw[i0 - 3] == 0x10C00006 and rw[i0 - 2] == 0x20C6FFFF and rw[i0 - 1] == 0x90AB0000
                and rw[i0] == 0xA08B0000 and rw[i0 + 1] == 0x24A50001 and rw[i0 + 2] == 0x1000FFFA
                and rw[i0 + 3] == 0x24840001
            ):
                gmap = self.gpr_map
                rem = self._reg_read(gmap[6])
                if 0 < rem <= 0x400000:
                    dst_addr = self._reg_read(gmap[4])
                    src_addr = self._reg_read(gmap[5])
                    src_phys = (src_addr + 1) & 0x1FFFFFFF
                    dst_off = off + 1
                    if src_phys + rem <= self._mapped_ram_size and dst_off + rem <= self.rom_size \
                            and ((address & 0x3FFFFF) + 1 + rem) <= 0x400000:
                        src_mv = self._ram_view[src_phys:src_phys + rem]
                        if self.rom_image[dst_off:dst_off + rem] == b'\xFF' * rem:
                            self.rom_image[dst_off:dst_off + rem] = src_mv
                        else:
                            for k in range(rem):
                                self.rom_image[dst_off + k] &= src_mv[k]
                        self._rom_view[dst_off:dst_off + rem] = self.rom_image[dst_off:dst_off + rem]
                        self._rom_sites_dirty = True
                        self._reg_write(gmap[4], (dst_addr + rem) & 0xFFFFFFFF)
                        self._reg_write(gmap[5], (src_addr + rem) & 0xFFFFFFFF)
                        self._reg_write(gmap[6], 0)
                return
            w_idx = (phys_pc - 8) >> 2
            rw = self._ram_words
            w0, w1, w2, w3, w4, w5 = rw[w_idx], rw[w_idx + 1], rw[w_idx + 2], rw[w_idx + 3], rw[w_idx + 4], rw[w_idx + 5]
            if (w0 & 0xFC00FFFF) == 0x90000000 and (w2 & 0xFC00FFFF) == 0xA0000000 \
                    and (w3 & 0xFC00FFFF) == 0x24000001 and (w4 & 0xFC0007FF) == 0x0000002B \
                    and (w5 & 0xFC1FFFFF) == 0x1400FFFA:
                r_src = (w0 >> 21) & 0x1F
                r_val = (w0 >> 16) & 0x1F
                r_i = (w3 >> 21) & 0x1F
                r_len = (w4 >> 16) & 0x1F
                r_cmp = (w4 >> 11) & 0x1F
                if w1 == (0x24000001 | (r_src << 21) | (r_src << 16)) \
                        and ((w2 >> 16) & 0x1F) == r_val and ((w3 >> 16) & 0x1F) == r_i \
                        and ((w4 >> 21) & 0x1F) == r_i and ((w5 >> 21) & 0x1F) == r_cmp:
                    gmap = self.gpr_map
                    i_val = self._reg_read(gmap[r_i])
                    len_val = self._reg_read(gmap[r_len])
                    if i_val == 0:
                        for k in range(7, 30):
                            wk = rw[w_idx + k]
                            if (wk & 0xFC0007FF) == 0x00000023 and ((wk >> 16) & 0x1F) == r_len:
                                r_tot = (wk >> 21) & 0x1F
                                if ((wk >> 11) & 0x1F) == r_tot \
                                        and (rw[w_idx + k + 1] & 0xFFE00000) == (0x14000000 | (r_tot << 21)):
                                    tot_val = self._reg_read(gmap[r_tot])
                                    if len_val < tot_val <= 0x400000 - (address & 0x3FFFFF):
                                        len_val = tot_val
                                        self._reg_write(gmap[r_len], len_val)
                                break
                    rem = len_val - (i_val + 1)
                    if 0 < rem <= 0x400000:
                        src_addr = self._reg_read(gmap[r_src])
                        src_phys = src_addr & 0x1FFFFFFF
                        if src_phys + rem <= self._mapped_ram_size and off + 1 + rem <= self.rom_size \
                                and ((address & 0x3FFFFF) + 1 + rem) <= 0x400000:
                            src_mv = self._ram_view[src_phys:src_phys + rem]
                            dst_off = off + 1
                            if self.rom_image[dst_off:dst_off + rem] == b'\xFF' * rem:
                                self.rom_image[dst_off:dst_off + rem] = src_mv
                            else:
                                for k in range(rem):
                                    self.rom_image[dst_off + k] &= src_mv[k]
                            self._rom_view[dst_off:dst_off + rem] = self.rom_image[dst_off:dst_off + rem]
                            self._rom_sites_dirty = True
                            self._reg_write(gmap[r_src], (src_addr + rem) & 0xFFFFFFFF)
                            self._reg_write(gmap[r_i], (i_val + rem) & 0xFFFFFFFF)

    def _spi_execute(self, cmd, off, data):
        """Carry out a command that changes the part: WREN / WRDI, WRSR (the
        status is data[0]), an erase of the block at flash offset off (or of
        the chip), a page program / AAI of data at off."""
        cmd_name = self._SPI_CMD_NAMES.get(cmd, f"0x{cmd:02X}")
        if cmd in (0x06, 0x04):     # WREN / WRDI — trigger
            self._spi_set_wel(cmd == 0x06)
            self._spi_log(f"  EXEC {cmd_name}")
        elif cmd == 0x01:    # WRSR — write status register
            if self._spi_wel and data:
                self._spi_status = data[0]
                self._spi_set_wel(False)
                self._spi_log(f"  EXEC {cmd_name} = 0x{data[0]:02X}")
        elif cmd in (0xC7, 0x60, 0xD8, 0x52, 0x20):   # erase
            if not self._spi_wel:
                self._spi_log(f"  EXEC {cmd_name} without WEL (applied anyway)")
            if cmd in (0xC7, 0x60):
                self._flash_erase(0, self.rom_size)
                self._spi_log(f"  EXEC {cmd_name}")
            else:
                blk = {0xD8: 0x10000, 0x52: 0x8000, 0x20: 0x1000}[cmd]
                self._flash_erase(off & ~(blk - 1), blk)
                self._spi_log(f"  EXEC {cmd_name} @ flash[0x{off & ~(blk - 1):06X}]")
            self._spi_set_wel(False)
        elif cmd in (0x02, 0x32, 0xAD):                  # page program (quad: 0x32) / AAI
            if not self._spi_wel:
                self._spi_log(f"  EXEC {cmd_name} without WEL (applied anyway)")
            for i, byte in enumerate(data):
                self._flash_program(off + i, byte)
            shown = f"0x{int.from_bytes(data, 'little'):0{2 * len(data)}X}" if len(data) <= 4 else f"{len(data)} bytes"
            self._spi_log(f"  EXEC {cmd_name} @ flash[0x{off:06X}] = {shown}")
            if cmd != 0xAD:
                self._spi_set_wel(False)

    # ------------------------------------------------------------------
    # ISA mode tracking (MIPS32 vs MIPS16e)
    #
    # Unicorn (QEMU) executes MIPS16e natively -- the 24Kf model carries
    # ASE_MIPS16 -- and keeps the current mode in bit MIPS_HFLAG_M16 (0x400)
    # of env->hflags.  The API only lets us *set* that bit (low bit of the PC
    # passed to emu_start()/reg_write()), it never reports it back: reg_read(PC)
    # is always even.  The hflags word is however part of the blob returned by
    # context_save(), so we locate it once (_calibrate_hflags) and read it
    # directly whenever the exact mode is needed: at every emu_start() and
    # after every mode-changing jump (JALX / JR / JALR / JRC / JALRC / ERET).
    #
    # Rules that follow from experiments with Unicorn 2.1.4:
    #  * reg_write(PC, x) inside a code hook makes execution continue at x
    #    (the hooked instruction is skipped) -- no emu_stop() needed.  The
    #    low bit of x selects the ISA mode of the target.
    #  * A PC write from a branch *delay slot* is ignored (the branch wins),
    #    so nothing is emulated manually there.
    #  * A 2-byte hook size means MIPS16; a 4-byte one is MIPS32 or a MIPS16
    #    EXTEND/JAL/JALX -- the tracked mode disambiguates.
    # ------------------------------------------------------------------
    HFLAG_M16 = 0x400
    _CACHED_HFLAGS_OFF = None
    _CACHED_CTX_SIZE = None
    _CACHED_GPR_OFF = None

    def _bind_ctx_save(self):
        try:
            lib = sys.modules[type(self.mu).__module__].uclib
            uch, ctx_ptr = self.mu._uch, self._ctx.context
            c_save = lib.uc_context_save
            self._ctx_save = lambda: c_save(uch, ctx_ptr)
        except Exception:
            self._ctx_save = lambda: self.mu.context_update(self._ctx)

    def _calibrate_hflags(self):
        """Find CPUMIPSState.hflags inside Unicorn's context blob (see above)."""
        import struct, ctypes
        if AliMipsSimulator._CACHED_HFLAGS_OFF is not None:
            try:
                ctx = self.mu.context_save()
                if ctx.size == AliMipsSimulator._CACHED_CTX_SIZE:
                    self._hflags_off = AliMipsSimulator._CACHED_HFLAGS_OFF
                    self._ctx = ctx
                    base = ctypes.cast(ctx.context, ctypes.c_void_p).value
                    self._hflags_view = ctypes.c_uint32.from_address(base + self._hflags_off)
                    self.mu.context_update(self._ctx)
                    self._bind_ctx_save()
                    self.log(f"ISA mode tracking: hflags at context offset {self._hflags_off}")
                    return
            except Exception:
                pass
        cands = []
        ctx = None
        try:
            probe = self._new_mips_uc()
            probe.mem_map(0x1000, 0x1000)
            probe.mem_write(0x1000, struct.pack('<2H', 0x6500, 0x6500))   # MIPS16: nop ; nop
            probe.mem_write(0x1100, struct.pack('<2I', 0, 0))             # MIPS32: nop ; nop
            probe.emu_start(0x1000 | 1, 0x2000, count=1)
            blob16 = bytes(probe.context_save())
            probe.emu_start(0x1100, 0x2000, count=1)
            blob32 = bytes(probe.context_save())
            for off in range(0, min(len(blob16), len(blob32)) - 3, 4):
                w16 = struct.unpack_from('<I', blob16, off)[0]
                w32 = struct.unpack_from('<I', blob32, off)[0]
                if (w16 ^ w32) == self.HFLAG_M16 and (w16 & self.HFLAG_M16):
                    cands.append(off)
            ctx = self.mu.context_save()
            if ctx.size != len(blob16):
                cands = []
        except Exception as e:
            self.log(f"Warning: hflags calibration failed: {e}")
            cands = []
        if len(cands) != 1 or ctx is None:
            self.log(f"Warning: could not locate hflags in Unicorn context (candidates={cands}); "
                     f"falling back to address-based ISA mode heuristics")
            self._hflags_off = None
            return
        self._hflags_off = cands[0]
        AliMipsSimulator._CACHED_HFLAGS_OFF = self._hflags_off
        AliMipsSimulator._CACHED_CTX_SIZE = ctx.size
        self._ctx = ctx
        base = ctypes.cast(ctx.context, ctypes.c_void_p).value
        self._hflags_view = ctypes.c_uint32.from_address(base + self._hflags_off)
        # Make sure context_update works with this binding before relying on it.
        self.mu.context_update(self._ctx)
        self._bind_ctx_save()
        self.log(f"ISA mode tracking: hflags at context offset {self._hflags_off}")

    def _calibrate_gpr_view(self):
        """Find the 32 GPRs inside the context blob, for cheap register
        fingerprints (_gpr_snapshot: one context_update instead of 32
        reg_reads).  Called once the GPR map exists."""
        import struct, ctypes
        self._gpr_view = None
        self._pc_view = None
        self._live_env = False
        self._env_u32 = None
        if self._ctx is None:
            return
        off = AliMipsSimulator._CACHED_GPR_OFF
        if off is not None:
            base = ctypes.cast(self._ctx.context, ctypes.c_void_p).value
            self._gpr_view = (ctypes.c_char * 128).from_address(base + off - 4)
            self._pc_view = ctypes.c_uint32.from_address(base + off + 124)
        else:
            try:
                vals = [0x5A5A0000 | (i << 8) | 0xA5 for i in range(1, 32)]
                for i, v in enumerate(vals, 1):
                    self._reg_write(self.gpr_map[i], v)
                self.mu.context_update(self._ctx)
                blob = ctypes.string_at(self._ctx.context, self._ctx.size)
                off = blob.find(struct.pack('<31I', *vals))
                for i in range(1, 32):
                    self._reg_write(self.gpr_map[i], 0)
                if off >= 4:
                    AliMipsSimulator._CACHED_GPR_OFF = off
                    base = ctypes.cast(self._ctx.context, ctypes.c_void_p).value
                    self._gpr_view = (ctypes.c_char * 128).from_address(base + off - 4)
                    self._pc_view = ctypes.c_uint32.from_address(base + off + 124)
            except Exception as e:
                self.log(f"Warning: GPR fingerprint calibration failed: {e}")
                return
        if off is None or off < 4:
            return
        try:
            uch_addr = ctypes.cast(self.mu._uch, ctypes.c_void_p).value
            if uch_addr and sys.byteorder == 'little' and ctypes.sizeof(ctypes.c_void_p) == 8:
                cpu_addr = ctypes.c_uint64.from_address(uch_addr + 0x1B8).value
                if cpu_addr:
                    env_addr = ctypes.c_uint64.from_address(cpu_addr + 0x170).value
                    if env_addr:
                        self._reg_write(UC_MIPS_REG_T0, 0x5A5AA5A5)
                        self.mu.context_update(self._ctx)
                        ctx_env = ctypes.cast(self._ctx.context, ctypes.c_void_p).value + off - 4
                        ok = (ctypes.string_at(env_addr, 132) == ctypes.string_at(ctx_env, 132))
                        self._reg_write(UC_MIPS_REG_T0, 0)
                        if ok and self._hflags_off is not None:
                            hf_env_off = self._hflags_off - (off - 4)
                            ok = (ctypes.c_uint32.from_address(env_addr + hf_env_off).value == self._hflags_view.value)
                        if ok:
                            self._live_env = True
                            self._gpr_view = (ctypes.c_char * 128).from_address(env_addr)
                            self._pc_view = ctypes.c_uint32.from_address(env_addr + 128)
                            self._gpr_snapshot = lambda ctx_saved=False, _gv=self._gpr_view: _gv.raw
                            if self._hflags_off is not None:
                                self._hflags_view = ctypes.c_uint32.from_address(env_addr + self._hflags_off - (off - 4))
                                self.get_hflags = lambda _hv=self._hflags_view: _hv.value
                            self._ctx_save = lambda: None
                            env_u32 = (ctypes.c_uint32 * 512).from_address(env_addr)
                            self._env_u32 = env_u32
                            c_io = getattr(self, '_c_reg_io', None)
                            if c_io is not None:
                                uch, val, ref, c_read, c_write = c_io
                                has_cp0_status = (env_u32[348] == self._reg_read(UC_MIPS_REG_CP0_STATUS))
                                if has_cp0_status:
                                    def fast_reg_read(reg, _u32=env_u32, _uch=uch, _val=val, _ref=ref, _cr=c_read):
                                        if 2 <= reg <= 33:
                                            return _u32[reg - 2]
                                        if reg == 1:
                                            return _u32[32]
                                        if reg == 139:
                                            return _u32[348]
                                        err = _cr(_uch, reg, _ref)
                                        if err:
                                            raise UcError(err)
                                        return _val.value & 0xFFFFFFFF
                                else:
                                    def fast_reg_read(reg, _u32=env_u32, _uch=uch, _val=val, _ref=ref, _cr=c_read):
                                        if 2 <= reg <= 33:
                                            return _u32[reg - 2]
                                        if reg == 1:
                                            return _u32[32]
                                        err = _cr(_uch, reg, _ref)
                                        if err:
                                            raise UcError(err)
                                        return _val.value & 0xFFFFFFFF
                                def fast_reg_write(reg, value, _u32=env_u32, _uch=uch, _val=val, _ref=ref, _cw=c_write):
                                    if 3 <= reg <= 33:
                                        _u32[reg - 2] = value & 0xFFFFFFFF
                                        return
                                    if reg != 2:
                                        _val.value = value
                                        err = _cw(_uch, reg, _ref)
                                        if err:
                                            raise UcError(err)
                                self._reg_read = fast_reg_read
                                self._reg_write = fast_reg_write
        except Exception:
            pass

    def _gpr_snapshot(self, ctx_saved=False):
        """The 32 GPRs as bytes (None if not calibrated)."""
        if self._gpr_view is None:
            return None
        if not ctx_saved:
            self._ctx_save()
        return self._gpr_view.raw

    def get_hflags(self):
        """Current QEMU hflags word, or None if calibration failed."""
        if self._hflags_off is None:
            return None
        self._ctx_save()
        return self._hflags_view.value

    def is_mips16_mode(self, pc=None):
        """Exact ISA mode of the CPU right now (valid inside hooks and after
        emu_start returns).  Without hflags calibration falls back to the
        address heuristic for pc (or the current PC)."""
        hf = self.get_hflags()
        if hf is None:
            if pc is None:
                pc = self.mu.reg_read(UC_MIPS_REG_PC)
            return self.is_mips16_addr(pc)
        return bool(hf & self.HFLAG_M16)

    @property
    def isa_mode(self):
        if self._hflags_off is not None:
            return ISAMode.MIPS16 if self.is_mips16_mode() else ISAMode.MIPS32
        return self._isa_mode_fallback

    @isa_mode.setter
    def isa_mode(self, value):
        """Force the ISA mode of the instruction at the current PC (Unicorn takes
        the mode from bit 0 of the PC, so the PC is rewritten with that bit)."""
        self._isa_mode_fallback = value
        if self.mu is not None:
            pc = self.mu.reg_read(UC_MIPS_REG_PC) & ~1
            self.mu.reg_write(UC_MIPS_REG_PC, pc | (1 if value == ISAMode.MIPS16 else 0))
            self._cur_m16 = (value == ISAMode.MIPS16)

    def start_pc(self, pc):
        """PC value to hand to mu.emu_start(): the current ISA mode in bit 0.

        Scripts that call sim.mu.emu_start() directly must use this instead of
        a plain reg_read(PC) (which is always even and would restart MIPS16
        code as MIPS32)."""
        return self._start_pc(pc)

    def _start_pc(self, pc):
        """PC value to hand to emu_start(): resets the tracker and encodes the ISA mode in bit 0."""
        hf = self.get_hflags() if self._hflags_off is not None else None
        if hf is not None:
            m16 = bool(hf & self.HFLAG_M16)
        else:
            m16 = self.is_mips16_addr(pc)
        self._cur_m16 = m16
        self._isa_mode_fallback = ISAMode.MIPS16 if m16 else ISAMode.MIPS32
        # An asynchronous stop can leave the CPU between a branch and its delay
        # slot (the translation block ended at a page boundary): the first
        # instruction then runs as the delay slot, so nothing may be injected there.
        in_ds = bool(hf is not None and hf & self._HFLAG_BMASK)
        self._next_in_delay_slot = in_ds
        self._mode_resync_in = 2 if in_ds else 0   # the branch may switch the ISA mode
        return (pc & ~1) | (1 if m16 else 0)

    # MIPS32 primary opcodes whose instruction has a branch delay slot
    _M32_DELAY_SLOT_OPCODES = frozenset({2, 3, 4, 5, 6, 7, 0x14, 0x15, 0x16, 0x17, 0x1D})
    _M32_REGIMM_BRANCH_RT = frozenset({0, 1, 2, 3, 0x10, 0x11, 0x12, 0x13})
    # Precomputed (has_ds, may_switch) by 6-bit MIPS32 primary opcode (None for opcodes 0, 1, 0x11, 0x12)
    _M32_OP_TRAITS = tuple(
        None if op in (0, 1, 0x11, 0x12) else
        (True, True) if op == 0x1D else
        (True, False) if op in {2, 3, 4, 5, 6, 7, 0x14, 0x15, 0x16, 0x17} else
        (False, False)
        for op in range(64)
    )
    # Precomputed (compact_jump, has_ds, may_switch, pc_rel) by 5-bit MIPS16 primary opcode (None for 0x03, 0x0C, 0x1D)
    _M16_OP_TRAITS = tuple(
        None if op in (0x03, 0x0C, 0x1D) else
        (False, False, False, True) if op in (0x02, 0x04, 0x05) else
        (False, False, False, False)
        for op in range(32)
    )

    @classmethod
    def _insn_has_delay_slot(cls, insn, size, m16):
        if m16:
            hw = insn[0] | (insn[1] << 8)
            op = hw >> 11
            if op == 0x03:                                    # JAL / JALX
                return True
            if op == 0x1D and (hw & 0x1F) == 0:               # RR JR/JALR family
                return ((hw >> 5) & 7) in (0, 1, 2)           # JR rx / JR ra / JALR (not JRC/JALRC)
            return False
        w = int.from_bytes(insn, 'little')
        op = w >> 26
        if op in cls._M32_DELAY_SLOT_OPCODES:
            return True
        if op == 0:
            return (w & 0x3F) in (8, 9)                       # JR / JALR
        if op == 1:
            return ((w >> 16) & 0x1F) in cls._M32_REGIMM_BRANCH_RT
        if op in (0x11, 0x12):                                # BC1x / BC2x
            return ((w >> 21) & 0x1F) == 8
        return False

    @staticmethod
    def _insn_may_switch_mode(insn, size, m16):
        """True for instructions after which the ISA mode may differ (target taken from a register or JALX)."""
        if m16:
            hw = insn[0] | (insn[1] << 8)
            op = hw >> 11
            if op == 0x03:
                return bool(hw & 0x0400)                      # JALX (x bit); JAL stays MIPS16
            return op == 0x1D and (hw & 0x1F) == 0            # JR / JALR / JRC / JALRC
        w = int.from_bytes(insn, 'little')
        op = w >> 26
        if op == 0x1D:                                        # JALX
            return True
        return op == 0 and (w & 0x3F) in (8, 9)               # JR / JALR

    @staticmethod
    def _m16_pc_relative_branch(insn, size):
        """MIPS16 B / BEQZ / BNEZ / BTEQZ / BTNEZ (plain or EXTENDed).  These
        have no delay slot and Unicorn completes them inside the instruction:
        a reg_write(PC) from a code hook before one of them raises an
        'Unhandled CPU exception' or is ignored, so no interrupt may be
        injected there (verified with Unicorn 2.1.4)."""
        hw = insn[0] | (insn[1] << 8)
        if size == 4:
            if (hw >> 11) != 0x1E:                            # JAL / JALX: redirect works
                return False
            hw = insn[2] | (insn[3] << 8)                     # instruction after EXTEND
        op = hw >> 11
        return op in (0x02, 0x04, 0x05) or (op == 0x0C and ((hw >> 8) & 7) in (0, 1))

    def _hook_code(self, uc, address, size, user_data):
        # The previous instruction completed: its device access (if any) can no
        # longer be rewound by a stop (see _dev_note).
        self._dev_last = None
        # Undo transient writes into the flash window made by the previous instruction.
        if self._rom_dirty:
            self._rom_restore()

        # (CP0 Count is derived from instruction_count, see _cp0_count_now.)

        # Hook-based single-stepping: stop before the 2nd instruction (see step()).
        # If that instruction is a branch delay slot Unicorn executes it anyway,
        # so it is still tracked/emulated below and the stop is issued at the end.
        phys = address & 0x1FFFFFFF
        seg = address >> 29
        w = None
        if seg in (0, 4, 5):
            if phys + size <= self._mapped_ram_size:
                if size == 4 and not (address & 3) and self._ram_words is not None:
                    w = self._ram_words[phys >> 2]
                elif size == 2 and not (address & 1) and self._ram_halfwords is not None:
                    w = self._ram_halfwords[phys >> 1]
            elif (address & 0x0F000000) == 0x0F000000 and self.flash_device is None and not self._flash_read_hooks:
                rel = address & 0x00FFFFFF
                off = (((0xC00000 - (rel & 0xC00000)) | (rel & 0x3FFFFF)) % self.rom_size)
                if off + size <= self.rom_size:
                    if size == 4 and not (off & 3) and self._rom_words is not None:
                        w = self._rom_words[off >> 2]
                    elif size == 2 and not (off & 1) and self._rom_halfwords is not None:
                        w = self._rom_halfwords[off >> 1]
        if w is None:
            w = int.from_bytes(self.mu.mem_read(address, size), 'little')

        if size == 2:
            op = w >> 11
            t = self._M16_OP_TRAITS[op]
            if t is not None:
                compact_jump, has_ds, may_switch, pc_rel = t
            elif op == 0x0C:
                compact_jump = has_ds = may_switch = False
                pc_rel = ((w >> 8) & 7) in (0, 1)
            elif op == 0x03:
                compact_jump = pc_rel = False
                has_ds = True
                may_switch = bool(w & 0x0400)
            else:
                is_jr = (w & 0x1F) == 0
                sub = (w >> 5) & 7
                compact_jump = is_jr and sub in (4, 5, 6)
                has_ds = is_jr and sub in (0, 1, 2)
                may_switch = is_jr
                pc_rel = False
        else:
            compact_jump = False

        stop_after = False
        if self.is_stepping:
            self._step_count += 1
            if self._step_count > 1:
                self._stop_reason = 'step'
                if not self._next_in_delay_slot and not compact_jump:
                    self.mu.emu_stop()
                    return
                stop_after = True

        in_delay_slot = self._next_in_delay_slot

        # ---- ISA mode of this instruction ----
        m16 = self._cur_m16
        if self._mode_resync_in:
            self._mode_resync_in -= 1
            if self._mode_resync_in == 0:
                m16 = self.is_mips16_mode(address)
        if size == 2:
            m16 = True                                        # only MIPS16 has 2-byte instructions
        elif m16 and ((w >> 11) & 0x1F) not in (0x1E, 0x03):
            m16 = self.is_mips16_mode(address)                # 4-byte MIPS16 must be EXTEND or JAL/JALX
        if self.verify_isa_mode and self._hflags_off is not None:
            exact = self.is_mips16_mode()
            if exact != m16:
                self.isa_mode_mismatches += 1
                self.log(f"[ISA] tracked {'MIPS16' if m16 else 'MIPS32'} but CPU is "
                         f"{'MIPS16' if exact else 'MIPS32'} at 0x{address:08X} (size {size})")
                m16 = exact
        self._cur_m16 = m16
        if size == 4:
            if m16:
                op0 = (w & 0xFFFF) >> 11
                has_ds = (op0 == 0x03)
                may_switch = (op0 == 0x03 and bool(w & 0x0400))
                hw1 = w >> 16
                op1 = hw1 >> 11
                pc_rel = (op0 == 0x1E) and (op1 in (0x02, 0x04, 0x05) or (op1 == 0x0C and ((hw1 >> 8) & 7) in (0, 1)))
            else:
                op = w >> 26
                t = self._M32_OP_TRAITS[op]
                if t is not None:
                    has_ds, may_switch = t
                elif op == 0:
                    has_ds = may_switch = ((w & 0x3E) == 8)
                elif op == 1:
                    has_ds = ((w >> 16) & 0x1F) in self._M32_REGIMM_BRANCH_RT
                    may_switch = False
                else:
                    has_ds = ((w >> 21) & 0x1F) == 8
                    may_switch = False
                pc_rel = False
        self._next_in_delay_slot = has_ds
        if may_switch:
            self._mode_resync_in = 2 if has_ds else 1

        # ---- Bookkeeping: history, visit counts, trace ----
        self._last_hook_size = size
        self._last_hook_addr = address
        self.prev_executed_pc = self.current_executed_pc
        self.current_executed_pc = address

        ph = self.pc_history
        ph.append(address)
        if not (self.instruction_count & 511) and len(ph) >= self.history_size * 2:
            del ph[:-self.history_size]

        vc = self.visit_counts
        try:
            vc[address] += 1
        except KeyError:
            vc[address] = 1
        self.instruction_sizes[address] = size
        self.instruction_isa[address] = m16

        if self.trace_instructions:
            try:
                insn = w.to_bytes(size, 'little')
                loop_str = f" [LOOP {vc[address]}]" if vc[address] > 1 else ""
                bytes_str = ' '.join(f'{b:02x}' for b in insn)
                if m16:
                    mnemonic, operands = MIPS16Decoder.decode(insn, address)
                    self.log(f"0x{address:08X}: {bytes_str:<15} {mnemonic}\t{operands}{loop_str}")
                else:
                    for i in self.md.disasm(insn, address):
                        self.log(f"0x{i.address:08X}: {bytes_str:<15} {i.mnemonic}\t{i.op_str}{loop_str}")
            except Exception:
                pass

        # ---- Breakpoints / stop address (checked before the instruction runs) ----
        if not self.is_stepping:
            if self._stop_instr is not None and address == self._stop_instr:
                self.log(f"\n[STOP] Reached stop address: 0x{address:08X}")
                self._stop_reason = 'stop_instr'
                self.mu.emu_stop()
                return
            if self.breakpoints and address in self.breakpoints:
                self.log(f"\n[BREAKPOINT] Hit at 0x{address:08X}")
                self._stop_reason = 'breakpoint'
                self.mu.emu_stop()
                return

        # ---- Interrupt injection (UART receive, CP0 timer, software) ----
        irq_stop = False
        if self._pending_uart_irq and not self._uart_irq_delivered and not in_delay_slot \
                and not self.is_stepping and self.instruction_count >= self._uart_irq_arm_after:
            ie = self.cp0_status & 0x01
            exl = self.cp0_status & 0x02
            force = getattr(self, '_uart_irq_force', False)
            if force or (ie and not exl):
                if compact_jump or pc_rel:
                    irq_stop = True
                else:
                    exc_vector = self._enter_uart_irq(self.mu, address | (1 if m16 else 0))
                    self._cur_m16 = False
                    self._mode_resync_in = 0
                    self._next_in_delay_slot = False
                    self._write_pc(exc_vector)   # even -> MIPS32
                    return

        # Count advances 2 per instruction here, so the next Compare crossing
        # is a known instruction count.
        if self.instruction_count >= self._timer_next_icount:
            self._timer_update()
        if (self.cp0_status & 0x7) == 0x1 and not in_delay_slot \
                and (self._ti or self._ic_lines or self.doorbell_in is not None or (self.cp0_cause & 0x300)) \
                and not self.is_stepping and self._irq_deliverable():
            if compact_jump or pc_rel:
                irq_stop = True
            else:
                exc_vector = self._enter_interrupt(self.mu, address | (1 if m16 else 0))
                self._cur_m16 = False
                self._mode_resync_in = 0
                self._next_in_delay_slot = False
                self._write_pc(exc_vector)
                return

        # ---- CP0 emulation (MIPS32 COP0 opcode 0x10: MFC0 / MTC0 / ERET) ----
        if size == 4 and not m16 and (w >> 26) == 0x10:
            self._emulate_cop0(self.mu, address, w, in_delay_slot)

        self.instruction_count += 1
        if stop_after:
            self.mu.emu_stop()
        elif irq_stop:
            self._stop_reason = 'irq'       # takes effect after the branch; run() delivers
            self.mu.emu_stop()
        elif self.max_instructions and not self.is_stepping and self.instruction_count >= self.max_instructions:
            self._stop_reason = 'max_instructions'
            self.mu.emu_stop()

    def _emulate_cop0(self, uc, address, w, in_delay_slot):
        """Emulate MFC0/MTC0 of Count, Status, Cause, EPC and EBase and ERET with
        the simulated CP0 state.  Returns True if the PC was redirected past the
        instruction (i.e. Unicorn will not execute it)."""
        rs = (w >> 21) & 0x1F
        if rs == 0x00:                      # MFC0 rt, rd
            val = self._cp0_read((w >> 11) & 0x1F, w & 0x7)
            if val is None:
                return False                # other registers: let Unicorn handle
            if in_delay_slot:
                self._delay_slot_skips += 1
                return False
            rt = (w >> 16) & 0x1F
            u32 = self._env_u32
            if u32 is not None:
                if rt:
                    u32[rt] = val & 0xFFFFFFFF
            else:
                self._reg_write(self.gpr_map[rt], val & 0xFFFFFFFF)
            self._write_pc(address + 4)
            return True
        if rs == 0x04:                      # MTC0 rt, rd
            rd = (w >> 11) & 0x1F
            rt = (w >> 16) & 0x1F
            if rd == 12 and not self.force_erl and not in_delay_slot and self._code_hook_h is None:
                return self._follow_status_write(uc, address, rt)
            u32 = self._env_u32
            rt_val = u32[rt] if u32 is not None else (self._reg_read(self.gpr_map[rt]) & 0xFFFFFFFF)
            resched = self._cp0_write(uc, rd, w & 0x7, rt_val)
            if resched is None:
                return False
            if in_delay_slot:
                self._delay_slot_skips += 1  # shadow updated; native MTC0 still executes
                if resched:
                    self._reschedule_slice() # a stop here takes effect after the branch
                return False
            self._write_pc(address + 4 * self._repeated(address, w))
            if resched:
                self._reschedule_slice()
            return True
        if rs == 0x10 and (w & 0x3F) == 0x18:    # ERET
            if in_delay_slot:
                return False
            target = self._eret(uc)
            self._write_pc(target)   # bit 0 selects the ISA mode
            self._reschedule_slice()
            return True
        return False

    def _follow_status_write(self, uc, address, rt):
        """Fast mode, native Status: an MTC0 Status the CPU executes itself --
        the hook takes the value over and re-plans the slice when the write can
        bring an interrupt (_cp0_write's rule); only when that ends the slice
        here does the hook complete the write and move past it (the stop comes
        before the instruction).  Returns whether the PC moved."""
        val = self._reg_read(self.gpr_map[rt]) & 0xFFFFFFFF
        old = self.cp0_status
        self.cp0_status = val
        if not ((old ^ val) & 0xFF06 or val & ~old & 0x1):
            return False
        before = self._stop_reason
        self._reschedule_slice()
        if self._stop_reason is before:
            return False
        self._write_native_status(uc, val)
        self._reg_write(UC_MIPS_REG_PC, address + 4)
        return True

    def _repeated(self, address, w):
        """Fast mode, an MTC0 at address just emulated: how many words the PC
        moves on -- past up to three NOPs and the same MTC0 again, which writes
        the same value (the RTOS's interrupt disable writes Status twice, a
        hazard padding: one hook instead of two), unless a breakpoint or the
        stop address lies there; else 1."""
        words = self._ram_words
        i = (address & 0x1FFFFFFF) >> 2
        if self._code_hook_h is not None or words is None or (address >> 29) not in (4, 5) \
                or not 0 < i < self._ram_words_len - 4:
            return 1
        x1 = words[i + 1]
        if x1 and x1 != w:
            return 1
        for k in range(1, 5):
            x = words[i + k]
            if x == w:
                end = address + 4 * k
                if (self.stop_instr is not None and address < self.stop_instr <= end) or \
                        any(address < b <= end for b in self.breakpoints):
                    return 1
                return k + 1
            if x:
                return 1
        return 1

    def _cp0_read(self, rd, sel):
        """What MFC0 of CP0 register rd, sel reads (Count, Compare, Status,
        Cause, EPC, EBase), or None for a register Unicorn keeps."""
        if rd == 12:
            return self.cp0_status
        if rd == 9:
            val = self._cp0_count_now()
            self._timer_update(val)
            self._count_observed = val
            return val
        if rd == 14:
            return self.cp0_epc
        if rd == 13:
            self._timer_update()
            return self._cause_value()
        if rd == 11:
            return self.cp0_compare
        if rd == 15 and sel == 1:
            return self.cp0_ebase
        return None

    def _cp0_write(self, uc, rd, sel, val):
        """MTC0 of val to CP0 register rd, sel: None for a register Unicorn
        keeps, else whether the write can change when the next interrupt comes
        (then the slice is re-planned: _reschedule_slice)."""
        if rd == 12:
            if self.force_erl:
                val &= ~0x4             # never adopt the ERL that only the native Status carries
            old = self.cp0_status
            self.cp0_status = val
            self._write_native_status(uc, val)
            # Only enabling (IE, an IM bit) or a change of EXL / ERL can make an
            # interrupt deliverable or move the slice's deadline: an interrupt
            # disable or a rewrite of the same value (critical sections) cannot.
            return bool((old ^ val) & 0xFF06 or val & ~old & 0x1)
        if rd == 9:
            self._timer_update()        # crossings before the write still count
            self.cp0_count = val
            self._count_icount = self.instruction_count
            self._count_t0 = self._vtime()
            self._timer_anchor = val
            self._count_observed = val
            self._timer_next_icount = 0
            return True
        if rd == 11:
            self._write_compare(val)
            return True
        if rd == 13:
            # Only IP1..0 (software interrupts), WP, IV and DC are writable.
            self.cp0_cause = (self.cp0_cause & ~0x08C00300) | (val & 0x08C00300)
            return True
        if rd == 14:
            self.cp0_epc = val
            return False
        if rd == 15 and sel == 1:       # EBase: bits 29..12 writable, 31..30 read as 0b10,
            self.cp0_ebase = 0x80000000 | (val & 0x3FFFF000) | (self.cp0_ebase & 0x3FF)    # CPUNum read-only
            return False
        return None

    def _eret(self, uc):
        """CP0 side of ERET (EXL cleared, UART re-arm); returns the target PC
        (EPC, bit 0 = ISA mode)."""
        self.cp0_status &= ~0x02            # clear EXL
        self._write_native_status(uc, self.cp0_status)
        uart_done = self._uart_ip3          # this ERET ends a UART interrupt
        self._uart_ip3 = False
        self._last_eret_vt = self._vtime()
        target = self.cp0_epc & 0xFFFFFFFF
        self._cur_m16 = bool(target & 1)
        self._mode_resync_in = 0
        self._next_in_delay_slot = False
        # Timer ticks end in an ERET each: log the first ones only.
        self._eret_logged += 1
        if self._eret_logged <= 64 or self._eret_logged % 1000 == 0:
            self.log(f"[ERET] Returning to {hex(target)}, Status=0x{self.cp0_status:08X}"
                     + (f" (ERET #{self._eret_logged})" if self._eret_logged > 64 else ""))
        # More RX bytes queued: interrupt again shortly after the UART ISR
        # returns (only then: timer ticks end in ERETs too, and must not
        # bring a setUartReceiveData() delay forward).
        if uart_done and len(self._uart_rx_queue) > 0:
            self._pending_uart_irq = True
            self._uart_irq_delivered = False
            self._uart_irq_arm_after = max(self._uart_irq_arm_after, self.instruction_count + 100)
        return target

    # ------------------------------------------------------------------
    # CP0 Count, interrupt entry
    # ------------------------------------------------------------------
    # ALi firmware addresses peripherals and the flash window through kuseg
    # (e.g. 0x18000058, 0x0FC00000) as if kuseg were identity mapped.  QEMU
    # only maps kuseg 1:1 while Status.ERL is set, so the native Status register
    # always carries ERL; the firmware's own view of Status (cp0_status) does not.
    force_erl = True

    def _write_native_status(self, uc, val):
        if self.force_erl:
            val |= 0x4
        try:
            (self._reg_write if uc is self.mu else uc.reg_write)(UC_MIPS_REG_CP0_STATUS, val & 0xFFFFFFFF)
        except Exception:
            pass

    def _vtime(self):
        """Emulation time in seconds: wall time spent inside emu_start() calls."""
        t = self._vt_accum
        t0 = self._vt_slice_t0
        if t0 is not None:
            now = self._vt_stop_t
            if now is None:
                now = self._clk_cache
                if now is None:
                    now = self._clk()
                    if self._in_cp0_hook:
                        self._clk_cache = now       # one reading per hooked CP0 instruction
            dt = now - t0
            if dt > 0.0:
                return t + dt
        return t

    def _setup_clock(self):
        """The emulation-time clock for the thread calling emu_start()."""
        import threading
        key = (threading.get_native_id(), self.count_clock)
        if key != self._clk_key:
            from thread_clock import make_thread_clock
            try:
                self._clk = make_thread_clock(self.count_clock)
            except ValueError:
                raise
            self._clk_key = key

    def _cp0_count_now(self):
        """Simulated CP0 Count.

        Full-hook mode: 2 ticks per executed instruction (deterministic, as the
        hardware does at half the CPU clock).  Fast mode: emulation time at
        count_hz, so firmware delay and timeout loops take real time instead
        of depending on how fast the host happens to emulate."""
        if self._code_hook_h is None:
            vt = self._vt_accum
            t0 = self._vt_slice_t0
            if t0 is not None:
                now = self._vt_stop_t
                if now is None:
                    now = self._clk_cache
                    if now is None:
                        now = self._clk()
                        if self._in_cp0_hook:
                            self._clk_cache = now
                dt = now - t0
                if dt > 0.0:
                    vt += dt
            ticks = int((vt - self._count_t0) * self.count_hz)
        else:
            ticks = 2 * (self.instruction_count - self._count_icount)
        return (self.cp0_count + ticks) & 0xFFFFFFFF

    def _rebase_count(self):
        """Keep Count continuous when the Count formula changes (the exact
        per-instruction hook is installed or removed)."""
        self.cp0_count = self._cp0_count_now()
        self._count_icount = self.instruction_count
        self._count_t0 = self._vtime()
        self._timer_next_icount = 0

    # ------------------------------------------------------------------
    # CP0 timer
    # ------------------------------------------------------------------
    # MIPS32 R2 / 24K: when Count passes Compare, Cause.TI (bit 30) is set and
    # routed to IP7 (IntCtl.IPTI = 7); it stays set until Compare is written.
    # It is an edge, not "Count >= Compare": firmware that writes Compare = 0
    # right after Count = 0 (ali_sdk.bin) must not see IP7.  Crossings are
    # checked against the Count value of the previous check (_timer_anchor):
    # in fast mode at every slice boundary and every hooked CP0 instruction,
    # in exact mode at the precomputed instruction count of the next crossing.
    _M32 = 0xFFFFFFFF
    _LATE_COMPARE_WINDOW = 0x40000000   # Count ticks (~10.7 s at 100 MHz) since the guest read Count

    @property
    def timer_enabled(self):
        """CP0 timer interrupt on/off (e.g. off while single-stepping in the GUI)."""
        return self._timer_enabled

    @timer_enabled.setter
    def timer_enabled(self, on):
        self._timer_enabled = bool(on)
        if not on:
            self._ti = False            # a latched tick is dropped
        self._timer_next_icount = 0     # exact mode: re-check on the next instruction

    def _timer_update(self, now=None):
        """Latch Cause.TI if Count passed Compare since the last check."""
        if not self._timer_enabled:
            # The anchor stays put: a Compare that Count passes while the timer
            # is off fires (once) when it is switched on again.
            self._timer_next_icount = 1 << 62
            return
        if now is None:
            now = self._cp0_count_now()
        if self._timer_armed and not self._ti:
            d_cmp = (self.cp0_compare - self._timer_anchor) & self._M32
            if d_cmp and d_cmp <= ((now - self._timer_anchor) & self._M32):
                self._ti = True
        self._timer_anchor = now
        if self._code_hook_h is not None:
            if self._ti or not self._timer_armed:
                self._timer_next_icount = 1 << 62
            else:
                d = (self.cp0_compare - now) & self._M32 or (1 << 32)
                self._timer_next_icount = self.instruction_count + (d + 1) // 2

    def _write_compare(self, val):
        """MTC0 Compare: clears Cause.TI and arms the timer.

        Late-Compare rule: in fast mode Count follows the host clock, so a host
        stall between the tick handler's `mfc0 Count` and its `mtc0 Compare`
        (Compare = Count + period) can leave the new Compare behind Count, and
        the next tick would only come after Count wraps (43 s at 100 MHz).  The
        crossing is therefore checked from the Count value the guest last read
        (if recent), i.e. a Compare that Count passed in that time fires now."""
        now = self._cp0_count_now()
        self._timer_update(now)
        self.cp0_compare = val
        self._ti = False
        self._timer_armed = True
        obs = self._count_observed
        if obs is not None and ((now - obs) & self._M32) <= self._LATE_COMPARE_WINDOW:
            self._timer_anchor = obs
        self._count_observed = None
        self._timer_update(now)

    def _cause_value(self):
        """Cause as the guest reads it: stored bits plus the hardware lines."""
        v = self.cp0_cause
        if self._ti:
            v |= 0x40008000             # TI + IP7
        if self._uart_ip3 or self._ic_ip3():
            v |= 0x00000800             # IP3 (ALi interrupt controller)
        return v

    def _irq_deliverable(self):
        """A timer, software or modelled device (IP3, _ic_set_line) interrupt
        is requested: IE=1, EXL=0, ERL=0 and (IP & IM) != 0.  The UART
        interrupt is delivered by its own one-shot path (_irq_due /
        _enter_uart_irq)."""
        s = self.cp0_status
        if (s & 0x7) != 0x1:
            return False
        return bool((self._ti and s & 0x8000) or (self.cp0_cause & s & 0x300)
                    or (s & 0x800 and self._ic_ip3()))

    def _enter_interrupt(self, uc, epc):
        """Take an interrupt exception: EPC (ISA mode in bit 0), Cause.BD and
        ExcCode cleared (ExcCode 0 = Int), Status.EXL set.  Returns the vector."""
        self.cp0_epc = epc & self._M32
        self.cp0_cause &= ~0x8000007C
        self.cp0_status |= 0x02
        self._write_native_status(uc, self.cp0_status)
        bev = self.cp0_status & 0x00400000
        iv = self.cp0_cause & 0x00800000
        if self._ti and self.cp0_status & 0x8000:
            self.timer_irq_count += 1
            if self.timer_irq_count <= 8 or self.timer_irq_count % 1000 == 0:
                self.log(f"[TIMER IRQ] #{self.timer_irq_count} from 0x{epc & ~1:08X}")
        if self.cp0_status & 0x800 and not self._uart_ip3 and self._ic_ip3():    # (served in the same pass)
            self.ic_irq_count += 1
            if self.ic_irq_count <= 8 or self.ic_irq_count % 1000 == 0:
                rung = " and a doorbell" if self._doorbell_ip3() else ""
                self.log(f"[IC IRQ] #{self.ic_irq_count} lines 0x{self._ic_lines:X}{rung} from 0x{epc & ~1:08X}")
        return (0xBFC00200 if bev else self.cp0_ebase & 0xFFFFF000) + (0x200 if iv else 0x180)

    def _reschedule_slice(self):
        """Fast mode, inside a run() slice: an MTC0 Count / Compare / Status /
        Cause or an ERET changed when the next interrupt can be taken.

        If one is deliverable now, end the slice here and let run() take it at
        the boundary (the hook already moved the PC past the instruction; an
        interrupt is never injected inside a CP0 hook, where the kernel may
        have k0/k1 live).  Otherwise move the slice deadline to the next timer
        event: a tick handler's MTC0 Compare / ERET sets up the next tick."""
        if not (self._in_run and self._code_hook_h is None and self._slice_cap_end is not None):
            return
        now = self._vtime()
        count = (self.cp0_count + int((now - self._count_t0) * self.count_hz)) & 0xFFFFFFFF
        self._timer_update(count)           # crossing between two reads would be lost
        if self._irq_deliverable():
            hold = self._irq_gap_left(now)
            if hold > 0 and self._slice_uses_stopper:
                self._arm_deadline(hold)    # let the interrupted code run first
                self._slice_armed_end = now + hold
            else:
                self._stop_reason = 'irq'
                self._orig_emu_stop()
            return
        w = self._timer_wait_us(count)
        end = self._slice_cap_end if w is None else min(self._slice_cap_end, now + w / 1e6)
        if self._slice_uses_stopper:
            exl = bool(self.cp0_status & 0x2)
            if exl and not self._slice_armed_exl:
                # The guest entered exception level itself (a context switch:
                # MTC0 Status with EXL, then ERET a few instructions later): the
                # backstop needs the long EXL margin.  Before the deadline it is
                # async_stop_margin_us away, so it is simply moved; after it, the
                # short backstop may already be firing, so end the slice here
                # (synchronously, the MTC0 is done) -- the next slice, which runs
                # the ERET, starts with the long EXL backstop.
                if self._slice_deadline is None or time.perf_counter() >= self._slice_deadline:
                    self._stop_reason = 'resched'
                    self._orig_emu_stop()
                    return
            # (IE toggles: deadline unchanged; leaving EXL shortens the backstop)
            if abs(end - self._slice_armed_end) > 50e-6 or exl != self._slice_armed_exl:
                self._arm_deadline(max(end - now, 0.0))
                self._slice_armed_end = end
        elif self._slice_planned_end is not None and \
                end < self._slice_planned_end - max(self.min_slice_us / 1e6, 0.001):
            # Unicorn's timeout cannot be moved: end the slice now if the deadline
            # really moved earlier, run() plans the next one
            self._stop_reason = 'irq'
            self._orig_emu_stop()

    # QEMU MIPS_HFLAG_BMASK: the CPU is between a branch and its delay slot.
    _HFLAG_BMASK = 0x0087F800

    def _at_safe_point(self):
        """True if the PC can be redirected to an exception vector after an
        asynchronous slice stop (not between a branch and its delay slot,
        which can happen when a translation block ends at a page boundary)."""
        hf = self.get_hflags()
        return hf is None or not (hf & self._HFLAG_BMASK)

    def _timer_wait_us(self, count=None):
        """Fast mode: microseconds until the slice should end for the CP0
        timer, or None.  0 if a timer interrupt is pending and deliverable
        (its delivery was deferred); None if it is pending but masked by IE /
        EXL (the handler's ERET or an MTC0 Status re-plans the slice) or IM7 is
        off; otherwise the time until Count reaches Compare.  IE / EXL do not
        matter for the latter: they usually change before the deadline."""
        if not (self.timer_enabled and self._timer_armed):
            return None
        s = self.cp0_status
        if not (s & 0x8000) or (s & 0x4):
            return None
        if self._ti:
            return self._irq_gap_left() * 1e6 if self._irq_deliverable() else None
        if count is None:
            count = self._cp0_count_now()
        d = (self.cp0_compare - count) & self._M32
        return d * 1e6 / self.count_hz

    def _irq_gap_left(self, now=None):
        """Fast mode: seconds the guest still has to run after the last ERET
        before the next timer / software interrupt may be taken (0 = now)."""
        if self._code_hook_h is not None:
            return 0.0
        if now is None:
            now = self._vtime()
        return max(0.0, self._last_eret_vt + self.irq_min_gap_us / 1e6 - now)

    def _get_stopper(self):
        """The fast-mode slice stopper (created on first use), or None to use
        emu_start(timeout=)."""
        if self._stopper_made != self.slice_stopper:       # first use, or the setting changed
            if self._stopper is not None:
                self._stopper.close()
                self._stopper = None
            self._stopper_made = self.slice_stopper
            try:
                from slice_stopper import make_stopper
                self._stopper = make_stopper(self.mu, self.slice_stopper)
            except ValueError:
                self._stopper_made = None
                raise                       # unknown slice_stopper name
            except Exception as e:
                self.log(f"Warning: slice stopper '{self.slice_stopper}' unavailable ({e}); "
                         f"using Unicorn's emu_start timeout")
                self._stopper = None
            if self._stopper is not None:
                import weakref
                weakref.finalize(self, self._stopper.close)
        return self._stopper

    def _enter_uart_irq(self, uc, epc):
        """Set up the CP0 state for the UART receive interrupt and return the
        exception vector.  epc carries the ISA mode in bit 0 like real hardware."""
        self._uart_irq_delivered = True
        self._pending_uart_irq = False
        self._uart_irq_retries += 1
        # ALi interrupt controller: EISR/EIER bit 16 = UART IRQ 24
        uart_ic_bit = 1 << 16
        eisr, eier = self._ic, self._ic_en
        try:
            eisr_val = int.from_bytes(uc.mem_read(eisr, 4), 'little')
            uc.mem_write(eisr, (eisr_val | uart_ic_bit).to_bytes(4, 'little'))
            eier_val = int.from_bytes(uc.mem_read(eier, 4), 'little')
            uc.mem_write(eier, (eier_val | uart_ic_bit).to_bytes(4, 'little'))
        except Exception:
            pass
        self._uart_ip3 = True             # IP3, ORed into Cause (a pending IP7 stays visible)
        self.cp0_status |= 0x0800         # IM[3]
        exc_vector = self._enter_interrupt(uc, epc)
        self.log(f"[UART IRQ] Delivering interrupt #{self._uart_irq_retries} -> {hex(exc_vector)} "
                 f"(from {hex(epc & ~1)}, icount={self.instruction_count})")
        return exc_vector

    def _irq_due(self):
        """True if a UART interrupt is armed and may be taken now (Status IE, !EXL)."""
        if not (self._pending_uart_irq and not self._uart_irq_delivered):
            return False
        if self.instruction_count < self._uart_irq_arm_after:
            return False
        if getattr(self, '_uart_irq_force', False):
            return True
        return bool(self.cp0_status & 0x01) and not (self.cp0_status & 0x02)

    # ------------------------------------------------------------------
    # Fast mode: hook management
    # ------------------------------------------------------------------
    # MIPS32 encodings of MFC0/MTC0 rt, {Count, Compare, Status, Cause, EPC}
    # (sel 0), EBase (reg 15 sel 1) and ERET, little-endian, matched at any
    # byte offset and then filtered to 4-byte alignment.  Data or MIPS16 code
    # matching by accident is harmless: the site hook re-checks the ISA mode
    # and the encoding.
    _CP0_SITE_RE = re.compile(rb'(?:\x00[\x48\x58\x60\x68\x70]|\x01\x78)[\x00-\x1f\x80-\x9f]\x40|\x18\x00\x00\x42')
    _RAM_CODE_LIMIT = 0x02000000        # scan/track the first 32MB of RAM for code
    _VIRGIN_CHUNK = 0x00100000          # 1MB first-execution chunks

    def _want_full_hook(self):
        return (self.hook_every_instruction or self.trace_instructions or self.verify_isa_mode
                or self._step_full_hook)

    def _flush_tb(self):
        """Drop translated blocks so that newly added code hooks take effect."""
        try:
            self.mu.ctl_flush_tb()
        except Exception:
            try:
                self.mu.ctl_remove_cache(0, 0xFFFFFFFF)
            except Exception:
                pass
        self._tb_flush_needed = False

    def _sync_hooks(self):
        """Install the hook set for the current mode (called before emu_start)."""
        full = self._want_full_hook()
        if full and self._code_hook_h is None:
            for h in (list(self._cp0_site_hooks.values()) + list(self._bp_hooks.values()) +
                      list(self._virgin_hooks.values()) + list(self._long_block_hooks.values())):
                self.mu.hook_del(h)
            self._cp0_site_hooks.clear(); self._bp_hooks.clear(); self._virgin_hooks.clear(); self._long_block_hooks.clear()
            self._scanned_ram_chunks.clear()
            self._rom_sites_hooked, self._vector_page = False, None
            self._rebase_count()            # Count: emulation time -> instruction count
            self._code_hook_h = self.mu.hook_add(UC_HOOK_CODE, self._hook_code)
            self._tb_flush_needed = True
        elif not full and self._code_hook_h is not None:
            self._rebase_count()            # Count: instruction count -> emulation time
            self.mu.hook_del(self._code_hook_h)
            self._code_hook_h = None
            self._rescan_due = True
            self._tb_flush_needed = True
        if not full:
            # Breakpoints / stop address as single-address hooks
            wanted = set(self.breakpoints)
            if self.stop_instr is not None:
                wanted.add(self.stop_instr)
            for addr in list(self._bp_hooks):
                if addr not in wanted:
                    self.mu.hook_del(self._bp_hooks.pop(addr))
                    self._tb_flush_needed = True
            for addr in wanted:
                if addr not in self._bp_hooks:
                    self._bp_hooks[addr] = self.mu.hook_add(UC_HOOK_CODE, self._hook_breakpoint, begin=addr, end=addr)
                    self._tb_flush_needed = True
            if not self._virgin_hooks:
                chunks = set(range(0, min(self._mapped_ram_size, self._RAM_CODE_LIMIT), self._VIRGIN_CHUNK))
                # and the chunks of the chip's code beyond that (a SEE core's program,
                # whose delay() and LzmaDecode() only these scans find)
                for start, length in self.chip.code_ranges():
                    phys = start & 0x1FFFFFFF
                    if phys + length <= self._mapped_ram_size:
                        chunks.update(range(phys & -self._VIRGIN_CHUNK, phys + length, self._VIRGIN_CHUNK))
                for seg in (0x80000000, 0xA0000000):
                    for base in sorted(seg + c for c in chunks):
                        self._virgin_hooks[base] = self.mu.hook_add(
                            UC_HOOK_CODE, self._hook_virgin, begin=base, end=base + self._VIRGIN_CHUNK - 1)
                self._tb_flush_needed = True
            if self._rescan_due or (self.rescan_interval and
                                    self.instruction_count - self._last_rescan_icount >= self.rescan_interval):
                self._rescan_cp0_sites()
        if self._tb_flush_needed:
            self._flush_tb()

    # (word & 0xFFE0FFFF) of MFC0/MTC0 rt, {Count, Compare, Status, Cause, EPC} sel 0 and EBase (15 sel 1)
    _CP0_WORDS = frozenset([op | (rd << 11) | sel for op in (0x40000000, 0x40800000)
                            for rd, sel in ((9, 0), (11, 0), (12, 0), (13, 0), (14, 0), (15, 1))])
    _CP0_WORD_ARRAY = None
    _ERET_WORD = 0x42000018

    def _find_cp0_sites(self, data, base):
        """Offsets (plus base) of 4-byte-aligned CP0 instruction encodings in data."""
        out = set()
        np = _get_np()
        if np is not None:
            if self._site_word_array is None:
                self._site_word_array = np.array(sorted(self._site_words), dtype=np.uint32)
            n = len(data) & ~3
            # The words' top bytes (a strided view): MFC0 / MTC0 have 0x40, ERET
            # 0x42 -- rare in code and data, so one vector pass over them finds
            # the few candidates, a second classifies those.
            cand = np.flatnonzero((np.frombuffer(data, dtype=np.uint8, count=n)[3::4] | 2) == 0x42)
            if len(cand):
                x = np.frombuffer(data, dtype='<u4', count=n // 4)[cand]
                hit = (x == self._ERET_WORD) | np.isin(x & np.uint32(0xFFE0FFFF), self._site_word_array)
                out.update((base + 4 * cand[hit]).tolist())
            return self._drop_disable_sites(data, base, out)
        data = bytes(data)
        n = len(data)
        fullmatch = self._CP0_SITE_RE.fullmatch
        for m in self._CP0_SITE_RE.finditer(data):      # one linear pass
            p = m.start()
            if (p & 3) == 0:
                out.add(base + p)
            else:
                # a misaligned match swallows up to 3 bytes of the next aligned
                # word; check that word explicitly so nothing is missed
                q = (p & ~3) + 4
                if q + 4 <= n and fullmatch(data, q, q + 4):
                    out.add(base + q)
        if len(self._site_words) != len(self._CP0_WORDS):    # (native Status: no MFC0 Status sites)
            out = {a for a in out if (int.from_bytes(data[a - base:a - base + 4], 'little') & 0xFFE0FFFF)
                   in self._site_words or data[a - base:a - base + 4] == b"\x18\x00\x00\x42"}
        return self._drop_disable_sites(data, base, out)

    # The TDS RTOS's interrupt disable, a quarter to a third of all hooked CP0
    # instructions of an application (dump_maciej, the S60: 232,000 calls in
    # their first 150 M instructions, with ~232,000 enables):
    #   mfc0 T, Status; nop x3; addiu X, zero, 6; and X, X, T; bnez X, out
    #   addiu X, zero, -2; and T, T, X; mtc0 T, Status; nop x2; mtc0 T, Status
    # (the newer SDK's has an EHB among the NOPs, the R265 Lite 1.2.0's five
    # NOPs: 1-8 NOPs / EHBs taken).
    # Both writes store the Status it has just read with IE cleared: they can
    # bring no interrupt, so under the native Status (where the CPU executes
    # them itself) their hooks would only follow the value -- run() takes the
    # native Status over at every slice boundary, and the enable's hook, which
    # stays, sees the write that can bring one.  Meanwhile the shadow keeps IE
    # set: a hook that asks whether an interrupt is deliverable may end a slice
    # in vain, the boundary then finding it masked.  Not with the forced ERL,
    # whose hooks emulate every MTC0 Status.
    skip_irq_disable = True

    def _drop_disable_sites(self, data, base, sites):
        """sites without the two MTC0 Status of each interrupt disable (see
        skip_irq_disable) in data (code at `base`)."""
        if self.force_erl or not self.skip_irq_disable:
            return sites
        drop = {a for a in sites if self._is_irq_disable(data, a - base)}
        return sites - drop if drop else sites

    def _is_irq_disable(self, data, p):
        """Whether the word at offset p of data is an MTC0 Status of the
        interrupt disable (skip_irq_disable): its first, or the same again
        after 1-8 NOPs / EHBs."""
        n = len(data)
        if p < 28 or p > n - 4:
            return False
        unpack = struct.unpack_from
        mtc0 = unpack("<I", data, p)[0]
        if (mtc0 & 0xFFE0FFFF) != 0x40806000:
            return False
        q = p - 4
        for _ in range(8):
            if q < 0 or unpack("<I", data, q)[0] not in (0, 0xC0):
                break
            q -= 4
        if q >= 0 and q < p - 4 and unpack("<I", data, q)[0] == mtc0:
            p = q                                   # (the second write: the first is checked)
        if p < 28:
            return False
        w_m20, w_m16, w_m12, w_m8, w_m4 = unpack("<5I", data, p - 20)
        t, x = (mtc0 >> 16) & 31, (w_m8 >> 16) & 31
        if x == t or w_m4 != 0x24 | t << 21 | x << 16 | t << 11 or w_m8 != 0x2400FFFE | x << 16 \
                or (w_m12 & 0xFFFF0000) != 0x14000000 | x << 21 \
                or w_m16 != 0x24 | x << 21 | t << 16 | x << 11 or w_m20 != 0x24000006 | x << 16:
            return False
        q = p - 24
        for _ in range(8):
            if q < 0 or unpack("<I", data, q)[0] not in (0, 0xC0):
                break
            q -= 4
        return q >= 0 and q < p - 24 and unpack("<I", data, q)[0] == (0x40006000 | t << 16)

    def _add_cp0_sites(self, sites):
        for addr in sites:
            if addr not in self._cp0_site_hooks:
                hook = self._hook_cp0_site
                if self._is_irq_enable_at(addr):
                    hook = self._hook_irq_enable
                    self._irq_enable_sites.add(addr)
                self._cp0_site_hooks[addr] = self.mu.hook_add(UC_HOOK_CODE, hook, begin=addr, end=addr)
                self._tb_flush_needed = True

    # The interrupt enable's MTC0 Status (os_enable_interrupt: mfc0 T, Status;
    # 1-8 NOPs / EHBs; addiu X, zero, 6; and X, X, T; bnez X, out; ori T, T, 1;
    # mtc0 T, Status), the most hooked CP0 instruction once the disable is not
    # hooked (the T650i: 39% of them).  With the disable unfollowed the shadow
    # keeps IE set, so the follow finds nothing to change; what matters is the
    # deadline check, which ends the slice for an interrupt that came due
    # meanwhile.  Its hook (_hook_irq_enable) returns at once while the shadow
    # has IE set (and no exception level), no slice deadline has passed and
    # no breakpoint is set; else it is the site's full hook.  Native Status
    # only, with skip_irq_disable.
    def _is_irq_enable_at(self, addr):
        """Whether the CP0 site at addr is the interrupt enable's MTC0 Status."""
        if self.force_erl or not self.skip_irq_disable or addr < 64:
            return False
        data = self._guest_bytes(addr - 60, 64)
        if len(data) < 64:
            return False
        words = struct.unpack("<16I", data)                     # words[15]: the site
        mtc0, t = words[15], (words[15] >> 16) & 31
        x = (words[13] >> 21) & 31
        if (mtc0 & 0xFFE0FFFF) != 0x40806000 or x == t or words[14] != 0x34000001 | t << 21 | t << 16 \
                or (words[13] & 0xFFFF0000) != 0x14000000 | x << 21 or words[12] != 0x24 | x << 21 | t << 16 | x << 11 \
                or words[11] != 0x24000006 | x << 16:
            return False
        k = 10
        while k > 1 and words[k] in (0, 0xC0):                  # (1-8 NOPs / EHBs)
            k -= 1
        return 1 <= 10 - k <= 8 and words[k] == 0x40006000 | t << 16

    def _hook_irq_enable(self, uc, address, size, user_data):
        """The interrupt enable's MTC0 Status (see _is_irq_enable_at)."""
        if (self.cp0_status & 0x7) == 0x1 and not self.breakpoints and self._stop_instr is None \
                and not self._rom_dirty and (self._slice_deadline is None or time.perf_counter() < self._slice_deadline):
            return
        self._hook_cp0_site(uc, address, size, user_data)

    def _rescan_cp0_sites(self, ranges=None):
        """Scan ROM (cached) and RAM for CP0 instruction encodings and hook each
        site.  ranges: list of (start, length) in the 0x80000000 RAM view; None
        scans the whole tracked RAM area."""
        sites = set()
        if self._rom_sites_dirty or not self._rom_sites_hooked:
            if self._rom_sites_dirty:
                self._rom_sites = self._find_cp0_sites(self.rom_image, 0)
                self._rom_sites_dirty = False
                self._find_lzma_decoders(self.rom_image, 0, (0xAFC00000, 0xBFC00000, 0x8FC00000, 0x9FC00000))
            # Flash executes from KSEG1 (and the BEV vector) -- and through KSEG0: the
            # T750i's XIP bootloader runs its set-up (MTC0 EBase, Status) from the
            # flash window's cached view, where its CP0 instructions ran natively.
            for base in (0xAFC00000, 0xBFC00000, 0x8FC00000, 0x9FC00000):
                sites |= {base + off for off in self._rom_sites}
            self._rom_sites_hooked = True
        full = ranges is None
        if full:
            chunk = self._VIRGIN_CHUNK
            ram_chunks = set(range(0, min(self._mapped_ram_size, self._RAM_CODE_LIMIT), chunk))
            extra = []
            for start, length in self.chip.code_ranges():
                phys = start & 0x1FFFFFFF
                if (start >> 29) in (0, 4, 5) and phys + length <= self._mapped_ram_size:
                    ram_chunks.update(range(phys & -chunk, phys + length, chunk))
                else:
                    extra.append((start, length))
            ranges = [(0x80000000 + c, min(chunk, self._mapped_ram_size - c)) for c in sorted(ram_chunks)] + extra
        for start, length in ranges:
            phys = start & 0x1FFFFFFF
            in_ram = (start >> 29) in (0, 4, 5) and phys + length <= self._mapped_ram_size
            ram_bytes = None
            if in_ram:
                ram = self._ram_view[phys:phys + length]            # (the RAM buffer itself, no copy)
                if length >= self._VIRGIN_CHUNK:
                    ram_bytes = zlib.crc32(ram)
                    if self._scanned_ram_chunks.get((phys, length) if full else (phys, length, False)) == ram_bytes:
                        continue
            else:
                try:
                    ram = self.mu.mem_read(start, length)
                except UcError as e:
                    self.log(f"Warning: RAM scan for CP0 sites failed at {hex(start)}: {e}")
                    continue
            found = self._find_cp0_sites(ram, phys)                 # physical offsets
            for seg in (0x80000000, 0xA0000000):                     # KSEG0 and KSEG1 views
                sites |= {seg + off for off in found}
            if (start >> 29) in (0, 4, 5):
                self._find_long_blocks(ram, phys, (0x80000000, 0xA0000000))
                self._find_poll_loops(ram, phys, (0x80000000, 0xA0000000))
            if not full and (start >> 29) in (4, 5):                # (a chunk's first execution, new code)
                self._find_lzma_decoders(ram, phys, (0x80000000, 0xA0000000))
                self._find_delay_routines(ram, phys, (0x80000000, 0xA0000000))
            if ram_bytes is not None:
                self._scanned_ram_chunks[(phys, length)] = ram_bytes
                if not full:
                    self._scanned_ram_chunks[(phys, length, False)] = ram_bytes
        self._add_cp0_sites(sites)
        if full:
            self._update_short_block_hook()
            self._rescan_due = False
            self._last_rescan_icount = self.instruction_count
        if self.debug_enabled:
            self.log(f"[fast] {len(self._cp0_site_hooks)} CP0 sites hooked (icount={self.instruction_count})")

    def _hook_breakpoint(self, uc, address, size, user_data):
        if self.is_stepping:
            return
        if self._stop_instr is not None and address == self._stop_instr:
            self.log(f"\n[STOP] Reached stop address: 0x{address:08X}")
            self._stop_reason = 'stop_instr'
            uc.emu_stop()
        elif address in self.breakpoints:
            self.log(f"\n[BREAKPOINT] Hit at 0x{address:08X}")
            self._stop_reason = 'breakpoint'
            uc.emu_stop()

    def _hook_virgin(self, uc, address, size, user_data):
        """First execution inside a RAM chunk: code was copied or decompressed
        there, so scan the chunk for CP0 sites and hook them before going on."""
        base = address & ~(self._VIRGIN_CHUNK - 1)
        h = self._virgin_hooks.pop(base, None)
        if h is None:
            return
        if self._vt_slice_t0 is not None and self._vt_stop_t is None:
            self._vt_stop_t = self._clk()           # the rescan is host time, not Count time
        uc.hook_del(h)
        phys = base & 0x1FFFFFFF
        self._rescan_cp0_sites([(0x80000000 + phys, self._VIRGIN_CHUNK)])
        # Flushing the translation cache from inside a hook can corrupt block
        # chaining (the current block is being executed), so stop the slice
        # here instead: the hook runs before this instruction executes, run()
        # resumes at the same PC, and _sync_hooks() flushes first.
        self._stop_reason = 'rescan'
        uc.emu_stop()

    def _hook_cp0_site(self, uc, address, size, user_data):
        """Fast-mode hook on one MFC0/MTC0/ERET encoding found by scanning."""
        # MIPS16 code that matched by accident is 2-byte instructions here: no
        # site's first halfword is an EXTEND or JAL(X) prefix (op 0x1E / 0x03;
        # they are ADDIUSP, ADDIU8, SLTIU, I8, LI, CMPI or XORI).
        if size != 4:
            return
        # The previous word tells whether this is a branch delay slot (a PC
        # redirect would be ignored there); treat it as MIPS32 (a MIPS16 caller
        # reaches MIPS32 code only via JALX, whose target is never a delay slot).
        if self._rom_dirty:
            self._rom_restore()
        words = self._ram_words
        i = (address & 0x1FFFFFFF) >> 2
        if words is not None and 0 < i < self._ram_words_len and (address >> 29) in (0, 4, 5):
            prev, w = words[i - 1], words[i]            # RAM (kuseg, KSEG0, KSEG1): its buffer
        else:
            try:
                both = self.mu.mem_read(address - 4, 8)
                prev, w = int.from_bytes(both[:4], 'little'), int.from_bytes(both[4:], 'little')
            except UcError:
                prev, w = None, int.from_bytes(self.mu.mem_read(address, 4), 'little')
        if (w >> 26) != 0x10:
            return                      # code changed since the scan
        dsw = self._delay_slot_words
        if prev in dsw:
            in_ds = dsw[prev]
        else:
            in_ds = dsw[prev] = self._insn_has_delay_slot(prev.to_bytes(4, 'little'), 4, False)
        # Fast path for common non-delay-slot MFC0/MTC0 instructions when no
        # breakpoints or stop address are active.
        if not in_ds and self._stop_instr is None and not self.breakpoints:
            masked = w & 0xFFE0FFFF
            if masked == 0x40004800:                        # MFC0 rt, Count
                if self._code_hook_h is None:
                    vt = self._vt_accum
                    t0 = self._vt_slice_t0
                    if t0 is not None:
                        now = self._vt_stop_t
                        if now is None:
                            now = self._clk()
                        dt = now - t0
                        if dt > 0.0:
                            vt += dt
                    val = (self.cp0_count + int((vt - self._count_t0) * self.count_hz)) & 0xFFFFFFFF
                    if self._timer_enabled:
                        if self._timer_armed and not self._ti:
                            d_cmp = (self.cp0_compare - self._timer_anchor) & 0xFFFFFFFF
                            if d_cmp and d_cmp <= ((val - self._timer_anchor) & 0xFFFFFFFF):
                                self._ti = True
                        self._timer_anchor = val
                    else:
                        self._timer_next_icount = 1 << 62
                else:
                    val = self._cp0_count_now()
                    self._timer_update(val)
                self._count_observed = val
                rt = (w >> 16) & 0x1F
                u32 = self._env_u32
                if u32 is not None:
                    if rt:
                        u32[rt] = val
                else:
                    self._reg_write(self.gpr_map[rt], val)
                self._write_pc(address + 4)
                if self._slice_deadline is not None and self._stop_reason is None \
                        and time.perf_counter() >= self._slice_deadline:
                    self._stop_reason = 'deadline'
                    self._orig_emu_stop()
                return
            if masked in (0x40007000, 0x40007801, 0x40006000, 0x40005800):  # MFC0 rt, EPC / EBase / Status / Compare
                val = (self.cp0_epc if masked == 0x40007000 else
                       self.cp0_ebase if masked == 0x40007801 else
                       self.cp0_status if masked == 0x40006000 else self.cp0_compare) & 0xFFFFFFFF
                rt = (w >> 16) & 0x1F
                u32 = self._env_u32
                if u32 is not None:
                    if rt:
                        u32[rt] = val
                else:
                    self._reg_write(self.gpr_map[rt], val)
                self._write_pc(address + 4)
                if self._slice_deadline is not None and self._stop_reason is None \
                        and time.perf_counter() >= self._slice_deadline:
                    self._stop_reason = 'deadline'
                    self._orig_emu_stop()
                return
            if masked == 0x40006800:                        # MFC0 rt, Cause
                self._timer_update()
                val = self._cause_value() & 0xFFFFFFFF
                rt = (w >> 16) & 0x1F
                u32 = self._env_u32
                if u32 is not None:
                    if rt:
                        u32[rt] = val
                else:
                    self._reg_write(self.gpr_map[rt], val)
                self._write_pc(address + 4)
                if self._slice_deadline is not None and self._stop_reason is None \
                        and time.perf_counter() >= self._slice_deadline:
                    self._stop_reason = 'deadline'
                    self._orig_emu_stop()
                return
            if masked == 0x40807000:                        # MTC0 rt, EPC
                rt = (w >> 16) & 0x1F
                u32 = self._env_u32
                self.cp0_epc = u32[rt] if u32 is not None else (self._reg_read(self.gpr_map[rt]) & 0xFFFFFFFF)
                self._write_pc(address + 4 * self._repeated(address, w))
                if self._slice_deadline is not None and self._stop_reason is None \
                        and time.perf_counter() >= self._slice_deadline:
                    self._stop_reason = 'deadline'
                    self._orig_emu_stop()
                return
            if masked == 0x40806000:                        # MTC0 rt, Status
                rt = (w >> 16) & 0x1F
                u32 = self._env_u32
                val = u32[rt] if u32 is not None else (self._reg_read(self.gpr_map[rt]) & 0xFFFFFFFF)
                if not self.force_erl and self._code_hook_h is None:
                    old = self.cp0_status
                    self.cp0_status = val
                    if (old ^ val) & 0xFF06 or val & ~old & 0x1:
                        before = self._stop_reason
                        self._reschedule_slice()
                        if self._stop_reason is not before:
                            self._write_native_status(self.mu, val)
                            self._write_pc(address + 4)
                else:
                    if self.force_erl:
                        val &= ~0x4
                    old = self.cp0_status
                    self.cp0_status = val
                    self._write_native_status(self.mu, val)
                    self._write_pc(address + 4 * self._repeated(address, w))
                    if (old ^ val) & 0xFF06 or val & ~old & 0x1:
                        self._reschedule_slice()
                if self._slice_deadline is not None and self._stop_reason is None \
                        and time.perf_counter() >= self._slice_deadline:
                    self._stop_reason = 'deadline'
                    self._orig_emu_stop()
                return
            if masked == 0x40806800:                        # MTC0 rt, Cause
                rt = (w >> 16) & 0x1F
                u32 = self._env_u32
                val = u32[rt] if u32 is not None else (self._reg_read(self.gpr_map[rt]) & 0xFFFFFFFF)
                self.cp0_cause = (self.cp0_cause & ~0x08C00300) | (val & 0x08C00300)
                self._write_pc(address + 4 * self._repeated(address, w))
                self._reschedule_slice()
                if self._slice_deadline is not None and self._stop_reason is None \
                        and time.perf_counter() >= self._slice_deadline:
                    self._stop_reason = 'deadline'
                    self._orig_emu_stop()
                return
        # A breakpoint / stop address on this instruction: its hook may be queued
        # behind this one, and Unicorn skips the remaining hooks of an instruction
        # once a stop is requested (an interrupt made deliverable here does that).
        # So stop before the instruction here, like the breakpoint hook would.
        bp_reason = None
        if (self._stop_instr is not None or self.breakpoints) and not self.is_stepping:
            if self._stop_instr is not None and address == self._stop_instr:
                bp_reason = 'stop_instr'
            elif address in self.breakpoints:
                bp_reason = 'breakpoint'
            if bp_reason and not in_ds:
                self.log(f"\n[{'STOP' if bp_reason == 'stop_instr' else 'BREAKPOINT'}] "
                         f"{'Reached stop address' if bp_reason == 'stop_instr' else 'Hit at'}: 0x{address:08X}")
                self._stop_reason = bp_reason
                self.mu.emu_stop()
                return
        # One clock reading for this instruction (Count, timer checks), taken
        # when first needed (_vtime): the thread clock costs ~0.5 us per read,
        # and MFC0 Status / EPC need none.
        self._in_cp0_hook = True
        try:
            self._emulate_cop0(self.mu, address, w, in_ds)
        finally:
            self._in_cp0_hook = False
            self._clk_cache = None
        if bp_reason and self._stop_reason == 'irq':
            self._stop_reason = bp_reason   # (delay slot: Unicorn completes the branch first)
        # Slice deadline, synchronously (see async_stop_margin_us): the hook has
        # emulated the instruction, so no CP0 instruction can run natively.
        elif self._slice_deadline is not None and self._stop_reason is None \
                and time.perf_counter() >= self._slice_deadline:
            self._stop_reason = 'deadline'
            self._orig_emu_stop()

    def _mips16_bytes(self, pc):
        """The bytes of the MIPS16 instruction at pc: 2, or 4 for JAL / JALX and EXTENDed ones."""
        insn_bytes = self.mu.mem_read(pc, 2)
        if ((int.from_bytes(insn_bytes, 'little') >> 11) & 0x1F) in (0x1E, 0x03):
            insn_bytes = self.mu.mem_read(pc, 4)
        return bytes(insn_bytes)

    def _decode_for_display(self, pc, m16):
        """(mnemonic, operands, size) of the instruction at pc in the given mode."""
        try:
            if m16:
                insn_bytes = self._mips16_bytes(pc)
                mnemonic, operands = MIPS16Decoder.decode(insn_bytes, pc)
                return mnemonic, operands, len(insn_bytes)
            insn_bytes = self.mu.mem_read(pc, 4)
            disasm = list(self.md.disasm(bytes(insn_bytes), pc))
            if disasm:
                return disasm[0].mnemonic, disasm[0].op_str, 4
            return "???", "", 4
        except Exception:
            return "???", "", 2 if m16 else 4

    def _log_unicorn_error(self, e):
        try:
            pc = self.mu.reg_read(UC_MIPS_REG_PC)
            m16 = self.is_mips16_mode()
            self.log(f"Unicorn Error: {e}")
            self.log(f"PC at error: {hex(pc)} ({'MIPS16' if m16 else 'MIPS32'})")
            self.log(f"Status at error: {hex(self.mu.reg_read(UC_MIPS_REG_CP0_STATUS))}")
            mnemonic, operands, sz = self._decode_for_display(pc, m16)
            raw = bytes(self.mu.mem_read(pc, sz)).hex()
            self.log(f"Instruction at PC: {raw} {mnemonic} {operands}")
            self.log(f"Instructions executed: {self.instruction_count}, last hooked: "
                     f"0x{self._last_hook_addr:08X} (size {self._last_hook_size})")
            if (pc & ~1) == 0 and self.force_erl and not self.mu.reg_read(UC_MIPS_REG_CP0_STATUS) & 0x4:
                self.log("Note: the forced Status.ERL is gone, so an ERET most likely ran natively (to "
                         "ErrorEPC = 0): Unicorn skips code hooks while an asynchronous stop is "
                         "pending (see async_stop_margin_us in simulator.py)")
        except Exception:
            pass

    def apply_manual_fixes(self):
        """No-op: kept for API compatibility with test scripts"""
        pass

    def invalidate_jit(self, address):
        """No-op: kept for API compatibility with test scripts"""
        pass

    def is_mips16_addr(self, address):
        """Heuristic to check if address is in known MIPS16 region"""
        # Main firmware body seems to be below 0x81E8E000
        # Loader/Trigger at 0x81E8E1B8 is MIPS32
        if (address & 0xFFE00000) == 0x81E00000:
             if address < 0x81E8E000:
                 return True
        return False

    def _take_interrupt_at_boundary(self, cur_pc):
        """Between slices: take a due UART interrupt, or a deliverable timer /
        software interrupt.  Returns the PC to continue at."""
        uart = self._irq_due()
        if not uart:
            self._timer_update()
            if not self._irq_deliverable() or self._irq_gap_left() > 0:
                return cur_pc               # (gap: the next slice is planned to end with it)
        hf = self.get_hflags()
        if hf & self._HFLAG_BMASK:
            return cur_pc                   # between a branch and its delay slot: next boundary
        epc = cur_pc | (1 if (hf & self.HFLAG_M16) else 0)
        if uart:
            if self._code_hook_h is None:
                self._rescan_cp0_sites()    # fast mode: the ISR code must be hooked before it runs
                if self._tb_flush_needed:
                    self._flush_tb()
            vector = self._enter_uart_irq(self.mu, epc)
        else:
            # No full rescan for timer ticks (100-250 ms each): the vector chunk
            # is scanned when it first executes and the periodic rescan covers
            # code written later -- except the vector's own page, scanned here:
            # an application that writes its handler over the bootloader's takes
            # its first tick before the periodic rescan sees the new code, and an
            # EBase read that runs natively reports Unicorn's CPU number 0x3FF
            # (the URZ0086's handler then takes its second-CPU path).  The page
            # is scanned again only when its bytes changed.
            vector = self._enter_interrupt(self.mu, epc)
            page = vector & 0x1FFFF000
            if self._code_hook_h is None and page < min(self.ram_size, self._RAM_CODE_LIMIT):
                seen = self._vector_page
                page_bytes = bytes(self._ram_view[page:page + 0x1000])
                if seen is None or seen[0] != page or page_bytes != seen[1]:
                    self._rescan_cp0_sites([(0x80000000 | page, 0x1000)])
                    self._vector_page = (page, page_bytes)
                    if self._tb_flush_needed:
                        self._flush_tb()
        self.mu.reg_write(UC_MIPS_REG_PC, vector)
        return vector

    def _arm_deadline(self, seconds):
        """End the running timed slice `seconds` from now: synchronously at the
        first hooked CP0 instruction after that (_hook_cp0_site), or by the
        asynchronous stopper async_stop_margin_us later."""
        self._slice_deadline = time.perf_counter() + seconds
        self._slice_jumped = 0.0
        if self._slice_uses_stopper:
            exl = bool(self.cp0_status & 0x2)
            self._slice_armed_exl = exl
            margin = self.async_stop_margin_exl_us if exl else self.async_stop_margin_us
            self._stopper.arm(seconds + margin / 1e6)

    def _run_slice(self, cur_pc, end_addr, slice_us, count=0):
        """Fast mode: one native slice.  A timed slice (slice_us) ends after
        slice_us microseconds or at the next timer interrupt, whichever comes
        first, and CP0 hooks can move that deadline (_reschedule_slice).  A
        counted slice (slice_us=None) runs `count` instructions.  Returns the
        emulation time the slice took."""
        stopper = None
        if slice_us is not None:
            cap_us = max(self.min_slice_us, slice_us)
            wait = self._timer_wait_us()
            if self._ic_ip3() and self._irq_deliverable():
                # a device interrupt held back by irq_min_gap_us
                gap = self._irq_gap_left() * 1e6
                wait = gap if wait is None else min(wait, gap)
            if wait is not None:
                slice_us = min(slice_us, wait)
            slice_us = max(self.min_slice_us, slice_us)
            stopper = self._get_stopper()
        v0 = self._vtime()
        if slice_us is not None:
            self._slice_cap_end = v0 + cap_us / 1e6
            self._slice_planned_end = v0 + slice_us / 1e6
        else:
            # counted slice: hooks may still end it for a deliverable interrupt
            self._slice_cap_end = float('inf')
            self._slice_planned_end = None
        self._slice_uses_stopper = stopper is not None
        self._slice_armed_end = self._slice_planned_end
        self._slice_deadline = None
        self._stop_reason = None
        delayed = self.delay_skipped
        try:
            if stopper is not None:
                self._arm_deadline(slice_us / 1e6)
                try:
                    self.mu.emu_start(self._start_pc(cur_pc), end_addr, count=count)
                finally:
                    stopper.disarm()
            elif slice_us is not None:
                self._arm_deadline(slice_us / 1e6)          # (Unicorn's timeout is the backstop)
                self.mu.emu_start(self._start_pc(cur_pc), end_addr,
                                  timeout=max(1, int(slice_us + self.async_stop_margin_us)), count=count)
            else:
                self.mu.emu_start(self._start_pc(cur_pc), end_addr, count=count)
        except UcError:
            # A CP0 instruction ran natively (its hook skipped under an asynchronous
            # stop): with the forced ERL a native ERET jumps to ErrorEPC = 0 and
            # clears ERL, and the fetch at kuseg 0 then faults inside this slice.
            # Hand it to run()'s boundary repair, which redoes the ERET.
            if self.force_erl and (self.mu.reg_read(UC_MIPS_REG_PC) & ~1) == 0 \
                    and not self.mu.reg_read(UC_MIPS_REG_CP0_STATUS) & 0x4:
                self._stop_reason = None
            else:
                raise
        except OSError as e:
            # Native faults can have several causes. cur_pc is the slice-entry
            # address, not necessarily the instruction that faulted; preserve
            # the original error rather than diagnosing every fault as a long
            # straight-line translation failure. The Uc instance is unusable.
            raise RuntimeError(
                f"Unicorn native failure during a fast slice starting at PC=0x{cur_pc:08X} "
                f"({type(e).__name__}: {e}); the engine cannot safely resume") from e
        finally:
            self._slice_cap_end = None
            self._slice_deadline = None
            self._slice_delayed = self.delay_skipped - delayed
        return self._vtime() - v0

    # A core whose program waits for an interrupt in a branch-to-self (the RTOS's
    # idle task; the SEE's) spins away as much host time as it emulates: with
    # idle_skip (the default) run() moves its emulation time -- its Count and
    # its estimated instruction count with it -- on to its next timer interrupt
    # instead (_idle_until).  A loop found that way also ends the slices that
    # reach it (_hook_idle_loop): most turns start in the tick handler, which
    # returns into the loop.  dump_maciej's first 150 M instructions are a
    # third idle.
    idle_skip = True
    _IDLE_LOOP = bytes.fromhex("ffff0010" "00000000")      # b . / nop

    def _budget(self):
        """Fast mode: the instructions run() may still count -- up to
        max_instructions, and to a UART interrupt armed so many instructions
        ahead (setUartReceiveData) -- or None (no limit)."""
        budget = None
        if self.max_instructions:
            budget = self.max_instructions - self.instruction_count
        if self._pending_uart_irq and not self._uart_irq_delivered and \
                self._uart_irq_arm_after > self.instruction_count:
            arm = self._uart_irq_arm_after - self.instruction_count
            budget = arm if budget is None else min(budget, arm)
        return budget

    def _idle_until(self, max_vtime):
        """The emulation time an idle loop can skip to -- when interrupts are
        enabled (IE, not EXL / ERL): the next timer interrupt (one Count tick
        past Compare, where the timer latches), max_vtime, the end of the
        instruction budget (_budget) or batch_timeout_us on (the slice services
        see the time pass in steps), whichever comes first; with an interrupt
        deliverable, the end of irq_min_gap_us after the last ERET (the loop
        has nothing to run meanwhile) --, or None (nothing to skip to)."""
        if (self.cp0_status & 0x7) != 0x1 or self._irq_due():
            return None
        now = self._vtime()
        if self._irq_deliverable():
            hold = self._irq_gap_left(now)
            if hold <= 0:
                return None
            until = now + hold
        else:
            until = now + self.batch_timeout_us / 1e6
            wait = self._timer_wait_us()
            if wait is not None:
                until = min(until, now + wait / 1e6 + 1.0 / self.count_hz)
        if max_vtime is not None:
            until = min(until, max_vtime)
        budget = self._budget()
        if budget is not None:
            until = min(until, now + budget / self._insn_rate)
        return until if until > now else None

    def _idle_start(self, pc):
        """Whether pc is an idle loop (`b .` with a nop in its delay slot, or
        `wait` / `wait; b .-4; nop`) with interrupts enabled; its code hook is
        installed then."""
        if not self.idle_skip or (self.cp0_status & 0x7) != 0x1 or (self._start_pc(pc) & 1):
            return False
        hook_pcs = (pc,)
        if (pc & 3) == 0 and self._ram_words is not None and (pc >> 29) in (0, 4, 5):
            i = (pc & 0x1FFFFFFF) >> 2
            if not (0 <= i < self._ram_words_len - 1):
                return False
            w0, w1 = self._ram_words[i], self._ram_words[i + 1]
            if (w0 == 0x1000FFFF and w1 == 0) or (w0 == 0x42000020 and w1 == 0x1000FFFE):
                pass
            elif i >= 1 and self._ram_words[i - 1] == 0x42000020 and w0 == 0x1000FFFE and w1 == 0:
                hook_pcs = (pc - 4, pc)
            else:
                return False
        else:
            try:
                if bytes(self.mu.mem_read(pc, 8)) != self._IDLE_LOOP:
                    return False
            except UcError:
                return False
        for hp in hook_pcs:
            if hp not in self._idle_loops:
                self._idle_loops[hp] = self.mu.hook_add(UC_HOOK_CODE, self._hook_idle_loop, begin=hp, end=hp)
                self._tb_flush_needed = True
        return True

    def _skip_idle(self, pc, max_vtime):
        """Fast mode, between slices: in an idle loop that only an interrupt
        ends -- `b .` with a nop in its delay slot (_idle_until) --, the
        emulation time skips on, and the instruction count with it, at the
        estimated rate (instruction counts stay a measure of emulation time,
        as the loop's spinning would have made them; no CP0 rescan for those).
        Returns whether it moved."""
        if not self._idle_start(pc):
            return False
        until = self._idle_until(max_vtime)
        if until is None:
            return False
        skipped = until - self._vtime()
        self.idle_skipped += skipped
        self._advance_time(skipped)
        return True

    # A core waiting for the other one in a tight poll of a mailbox register --
    # lw rt, off(rs); beq / bne rt, rX, back; nop: the T760i's main CPU on the
    # SEE's 0xB8040204, its SEE on 0xB8000200, a third of all their device
    # reads -- reads the same value until the other core, which runs between
    # this core's slices (chips/see.py SeeCore), has stored: the spin is idle
    # time.  run() moves the emulation time on as for an idle loop
    # (_skip_poll): with interrupts enabled to the next one, else to the end
    # of the turn; a code hook on the load ends the slices that reach it while
    # the poll still holds and the time can move on.  Only while a second core
    # runs (the mailboxes are the dual-CPU SDK's).
    poll_skip = True
    _MAILBOXES = frozenset((0x200, 0x204, 0x40200, 0x40204))     # (device-window offsets)

    def _mailbox_peer(self):
        """Whether another core runs whose stores end this core's mailbox polls."""
        if self._shared is not None:
            return True                             # (a SEE core: the main CPU)
        core = getattr(getattr(self.chip, "see", None), "core", None)
        return core is not None and core.service in self.slice_services

    def _poll_loop(self, pc):
        """The mailbox address a tight poll loop at pc reads, while the loop's
        condition holds, or None."""
        words = self._ram_words
        i = (pc & 0x1FFFFFFF) >> 2
        if not self.poll_skip or words is None or (pc >> 29) not in (4, 5) or not 0 <= i < self._ram_words_len - 4:
            return None
        lw = words[i]
        if (lw >> 26) != 0x23:
            return None
        br = words[i + 1]
        imm_x = None
        base_val = None
        if (br >> 21) == 0x120 and i >= 2:
            imm_x = (((br & 0xFFFF) ^ 0x8000) - 0x8000) & 0xFFFFFFFF
            reg_x = (br >> 16) & 31
            br = words[i + 2]
            if words[i + 3] != 0 or (br >> 26) not in (4, 5) or not (0xFFE0 <= (br & 0xFFFF) <= 0xFFFE):
                return None
            rs = (lw >> 21) & 31
            w_m2, w_m1 = words[i - 2], words[i - 1]
            if (w_m2 >> 16) == (0x3C00 | rs) and (w_m1 >> 16) == (0x3400 | (rs << 5) | rs):
                base_val = ((w_m2 & 0xFFFF) << 16) | (w_m1 & 0xFFFF)
        elif words[i + 2] != 0 or not (0xFFE0 <= (br & 0xFFFF) <= 0xFFFE) or (br >> 26) not in (4, 5):
            return None
        rs, rt, a, b = (lw >> 21) & 31, (lw >> 16) & 31, (br >> 21) & 31, (br >> 16) & 31
        if rt not in (a, b):
            return None
        other = b if a == rt else a
        if imm_x is not None and other != reg_x:
            return None
        if base_val is None:
            base_val = self._reg_read(self.gpr_map[rs])
        address = (base_val + ((lw & 0xFFFF) ^ 0x8000) - 0x8000) & 0xFFFFFFFF
        try:
            offset = self._mmio_offset(address)
        except ValueError:
            return None
        if address & 3 or offset not in self._MAILBOXES or not self._mailbox_peer():
            return None
        value = self._mmio_word(offset)
        x = imm_x if imm_x is not None else (self._reg_read(self.gpr_map[other]) if other else 0)
        return address if (value == x) == ((br >> 26) == 4) else None

    def _poll_until(self, max_vtime):
        """The emulation time a mailbox poll can skip to: with interrupts
        enabled as an idle loop's (_idle_until), else the end of the turn
        (batch_timeout_us on, max_vtime, the budget); None in an exception
        level or with nothing to skip."""
        if (self.cp0_status & 0x7) == 0x1:
            return self._idle_until(max_vtime)
        if self.cp0_status & 0x6:
            return None
        now = self._vtime()
        until = now + self.batch_timeout_us / 1e6
        if max_vtime is not None:
            until = min(until, max_vtime)
        budget = self._budget()
        if budget is not None:
            until = min(until, now + budget / self._insn_rate)
        return until if until > now else None

    _POLL_ORI_RE = re.compile(rb"[\x00\x04]\x02[\x00-\xff][\x34-\x37]")

    def _find_poll_loops(self, data, base, views):
        """Hook mailbox poll loops in `data` (code at physical offset `base`)
        whose base register is set up by `ori rS, rX, 0x200 / 0x204` nearby."""
        if not self.poll_skip:
            return
        data = data if isinstance(data, (bytes, bytearray)) else bytes(data)
        n = len(data)
        if n < 20:
            return
        unpack = struct.unpack_from
        hits = []
        for pat in (b"\x00\x02", b"\x04\x02"):
            pos = data.find(pat)
            while 0 <= pos <= n - 20:
                if (pos & 3) == 0 and 0x34 <= data[pos + 3] <= 0x37:
                    hits.append(pos)
                pos = data.find(pat, pos + 2)
        if len(hits) > 1:
            hits.sort()
        for p in hits:
            ori = unpack("<I", data, p)[0]
            rs = (ori >> 16) & 31
            end = min(n - 16, p + 36 * 4)
            for q in range(p + 4, end + 1, 4):
                lw = unpack("<I", data, q)[0]
                if (lw & 0xFC00FFFF) != 0x8C000000 or ((lw >> 21) & 31) != rs:
                    continue
                rt = (lw >> 16) & 31
                w1, w2, w3 = unpack("<3I", data, q + 4)
                if (w1 >> 21) == 0x120:
                    br, nop = w2, w3
                else:
                    br, nop = w1, w2
                if nop != 0 or (br >> 26) not in (4, 5) or not (0xFFE0 <= (br & 0xFFFF) <= 0xFFF8):
                    continue
                if rt not in ((br >> 21) & 31, (br >> 16) & 31):
                    continue
                for view in views:
                    start = view + base + q
                    if start not in self._poll_loops:
                        self._poll_loops[start] = self.mu.hook_add(UC_HOOK_CODE, self._hook_poll_loop,
                                                                   begin=start, end=start)
                        self._tb_flush_needed = True

    def _poll_start(self, pc):
        """The start (its load) of the mailbox poll whose load or branch is at
        pc, while it holds; its code hook is installed then.  None otherwise."""
        if not self.poll_skip:
            return None
        words = self._ram_words
        i = (pc & 0x1FFFFFFF) >> 2
        if words is None or (pc >> 29) not in (4, 5) \
                or not 0 <= i < self._ram_words_len - 4 or not self._mailbox_peer():
            return None
        w = words[i]
        op = w >> 26
        if op == 0x23:
            indices = (i,)
        elif op in (4, 5):
            indices = (i - 2 if i >= 2 and (words[i - 1] >> 21) == 0x120 else i - 1,)
        elif op == 9:
            indices = (i - 1,)
        elif op == 0x0D:
            indices = (i + 1,)
        elif op == 0x0F:
            indices = (i + 2,)
        elif op == 3 or (op == 0 and (w & 0x3F) == 0x23):
            indices = range(i + 8, min(i + 29, self._ram_words_len - 4))
        else:
            return None
        seg = pc & 0xE0000000
        for si in indices:
            if 0 <= si < self._ram_words_len - 4 and (words[si] >> 26) == 0x23:
                w1 = words[si + 1]
                if (w1 >> 21) == 0x120:
                    if words[si + 3] != 0 or (words[si + 2] >> 26) not in (4, 5):
                        continue
                elif words[si + 2] != 0 or (w1 >> 26) not in (4, 5):
                    continue
                start = seg | (si << 2)
                if self._poll_loop(start) is not None:
                    if start not in self._poll_loops:
                        self._poll_loops[start] = self.mu.hook_add(UC_HOOK_CODE, self._hook_poll_loop,
                                                                   begin=start, end=start)
                        self._tb_flush_needed = True
                    return start
        return None

    def _skip_poll(self, pc, max_vtime):
        """Fast mode, between slices: a mailbox poll's spin skipped as idle
        time (see poll_skip).  Returns whether the time moved."""
        if self._poll_start(pc) is None:
            return False
        until = self._poll_until(max_vtime)
        if until is None:
            return False
        skipped = until - self._vtime()
        self.poll_skipped += skipped
        self._advance_time(skipped)
        return True

    def _hook_poll_loop(self, uc, address, size, user_data):
        """A slice reached a mailbox poll (_skip_poll): end it there while the
        poll holds and the time can move on."""
        if self._code_hook_h is None and self._stop_reason is None and self._poll_loop(address) is not None \
                and self._poll_until(self._run_max_vtime) is not None:
            self._stop_reason = 'poll'
            self._orig_emu_stop()

    def _advance_time(self, seconds):
        """Between slices: move the emulation time on, and the estimated
        instruction count with it (at most to the budget); no CP0 rescan is
        due for that time, no code ran."""
        self._vt_accum += seconds
        counted = round(seconds * self._insn_rate)
        budget = self._budget()
        if budget is not None:
            counted = min(counted, budget)
        self.instruction_count += counted
        self._last_rescan_icount += counted

    def _skip_busy(self, max_vtime):
        """Fast mode, between slices: the emulation time the CPU still owes for
        work done in Python (busy_pending: the LZMA decoder), moved on in steps
        of at most batch_timeout_us (the slice services -- a SEE core -- see it
        pass), within run()'s limits.  Interrupts wait until it is paid, as
        if they had been masked meanwhile: the time charged is what the whole
        emulated call took, its interrupts included (lzma_insns_per_byte).
        Returns whether it moved."""
        now = self._vtime()
        step = self.busy_pending
        if self._irc_frames or any(
            (o.pending is not None if type(o).__name__ == 'SeeStart'
             else type(o).__name__ not in ('VideoOutput', 'VideoOutputM36F'))
            for s in self.slice_services if (o := getattr(s, '__self__', None)) is not None
        ):
            step = min(step, self.batch_timeout_us / 1e6)
        if max_vtime is not None:
            step = min(step, max_vtime - now)
        budget = self._budget()
        if budget is not None:
            step = min(step, budget / self._insn_rate)
        if step <= 0:
            return False
        self.busy_pending -= step
        self._advance_time(step)
        return True

    def _hook_idle_loop(self, uc, address, size, user_data):
        """A slice reached an idle loop (_skip_idle): with interrupts enabled
        only an interrupt leaves it, so end the slice there -- run() takes the
        interrupt, or moves the time on to it -- instead of spinning to the
        slice's end.  (Also when one is deliverable already: Cause.TI latches
        at CP0 hooks and slice boundaries, so a tick that came due in the
        slice's last task waited for the asynchronous backstop.)"""
        if self.idle_skip and self._code_hook_h is None and self._stop_reason is None \
                and (self.cp0_status & 0x7) == 0x1:
            self._stop_reason = 'idle'
            self._orig_emu_stop()

    # The ALi SDK bootloaders unpack the main code (and the SEE's) with the
    # LZMA SDK 4.0x LzmaDecode() of their boot library, compiled without
    # optimisation -- a function call per decoded bit: emulated, ~5 us per
    # output byte (the T750i's 3.4 MB SEE code took 23 s, its 8.6 MB main code
    # 48 s; Python's lzma module needs 0.1 s for each).  All but three of the
    # images carry that routine byte for byte (its first 43 instructions, up to
    # its first absolute jump: _LZMA_DECODE_SIG).  Found in the flash image and
    # by each RAM chunk's first-execution scan, its entry gets a code hook
    # (_hook_lzma) that decodes the stream with the lzma module, writes the
    # output and *outSizeProcessed, returns 0 (LZMA_RESULT_OK) to the caller and
    # charges the time the emulated decoder would have taken, as instructions
    # (lzma_insns_per_byte of the estimated count: 3.8-4.6 per output byte on
    # the T750i and dump_maciej; run() moves the emulation time on as
    # busy_pending), so instruction counts -- every test's timeline -- stay
    # what they were (0: no time, tv_gui).
    # Anything unexpected -- the arguments, a stream the module rejects or that
    # ends early, output outside the RAM, exact mode -- leaves the call to the
    # emulated decoder.  LzmaDecode(buffer, bufferSize, lc, lp, pb, inStream,
    # inSize, outStream, outSize, &outSizeProcessed): a0..a3, then the stack.
    lzma_hle = True
    lzma_insns_per_byte = 4.0
    _LZMA_DECODE_SIG = bytes.fromhex(
        "78ffbd278400bfaf8000beaf21f0a0038800c4af8c00c5af9000c6af9400c7af"
        "9000c38f9400c28f211862000003022404106200360742241000c2af8800c28f"
        "1400c2af3400c0af3800c0af3c00c0a3010002244000c2af4400c2af4800c2af"
        "4c00c2af5000c0af010003249800c28f04104300ffff42245400c2af9400c28f"
        "04104300ffff42245800c2af5c00c0af1000c28f401802008c00c28f2b104300"
        "040040100000000002000224")
    # -O2 MIPS32 build of LzmaDecode() in M3329C/M3329E bootloaders (39 words up
    # to its first J: identical C ABI a0..a3 + sp+16..36; inlines BitDecode, so
    # its emulated instruction cost per byte is ~0.3x the -O0 build's).
    _LZMA_DECODE_O2_SIG = bytes.fromhex(
        "98ffbd276400bfaf6000beaf5c00b7af5800b6af5400b5af5000b4af4c00b3af"
        "4800b2af4400b1af4000b0af7000a6af8400b78f2118c7000003022404306200"
        "3607c62421a0800021b000002800a0af21900000010011242c00b1af01001e24"
        "010002243000a2af219800007800a28f04105100ffff42243400a2af0438f100"
        "3800a7af2118e000ffff6324401006002b28a2000500a0103800a3af")
    # LZMA SDK 9.x LzmaDecode(dest, &destLen, src, &srcLen, propData, propSize,
    # finishMode, &status, alloc) in newer C3505/C3503D/M3821 bootloaders (29
    # position-independent words up to its first JAL; ~0.3x -O0 instruction cost).
    _LZMA_DECODE_9_SIG = bytes.fromhex(
        "50ffbd27a800bfafa400b7afa000b6af9c00b5af9800b4af9400b3af9000b2af"
        "8c00b1af8800b0af21b080002190a00021b8c0002180e000cc00b38fd000b58f"
        "0000b48c0000f18c0000e0ac0000a0ac000060ae0500222e2300401406000324"
        "2c00a0af2800a0af1800a427c000a58fc400a68f")
    # Same LZMA SDK 9.x LzmaDecode() in Libcore 17.x maincodes (saves $fp as well
    # as $ra and $s7..$s0 in the 0xB0-byte frame; identical 9-argument C ABI).
    _LZMA_DECODE_9B_SIG = bytes.fromhex(
        "50ffbd27ac00bfafa800beafa400b7afa000b6af9c00b5af9800b4af9400b3af"
        "9000b2af8c00b1af8800b0af21b080002198a00021f0c0002188e000cc00b78f"
        "d000b58f0000f28c0000b48c0000a0ac0000e0ac0500422e2300401406000324"
        "2c00a0af2800a0af1800a427c000a58fc400a68f")
    # MIPS16e build of the same LZMA SDK 4.0x LzmaDecode() in M3329 bootloaders
    # (54 halfwords / 108 bytes up to its first JAL: identical C ABI a0..a3 + sp+16..36).
    _LZMA_DECODE_M16_SIG = bytes.fromhex(
        "f363186217d116d01cd6ede600f3006ac267c4eb20f7164e0ad4006a0bd20cd2"
        "0dd20169016b0ed30fd310d311d21e92916784eaff4c12d4516744efff4a13d2"
        "c43243ed0460026a5111016a4f11006b092600f4006c64320a95a9e280ca014b"
        "c3ebf9619d67104c1f952096")
    # MIPS16e LZMA SDK 9.x LzmaDecode() entry (Ferguson Ariva 160 Combo bootloader
    # at 0x81C022A8: save $a0-$a2,56,$ra,$s0-$s1,s2-s4 -> sw $a3,56($sp) -> JAL LzmaDec_InitDicAndState).
    _LZMA_DECODE_9_M16_SIG = bytes.fromhex(
        "609d1cf0f464006c22d3609f80df80dd23d32f93066a80db2393055b2c61256707672c952d9630970bd40ad4")
    # MIPS16e LZMA SDK 9.x LzmaDecode() entry in "DVBS2---0.1.0" bootloaders
    # (Openbox V8S / V8Se / V5S / X3, Skybox F4 / A3: save $a0-$a2,0xa0,$ra,$s0-$s4 at entry).
    _LZMA_DECODE_9B_M16_SIG = bytes.fromhex(
        "1cf0f4642767409f22d2609d23d3006a40dd40df2292055a0260066a2d10006a0bd20ad206042c952d96")
    # MIPS16e lzo1x_decompress_safe(src, src_len, dst, &dst_len, wrkmem) entry in "390xx"
    # bootloaders (Opticum AX 502 Combo, Ferguson Ariva 103, Ferguson Ariva 153 Combo).
    _LZO1X_DECODE_M16_SIG = bytes.fromhex(
        "0ef0b1642667a1e4409f49e63a65006a40df40a4125a1761a267ef4d8144045d")
    # MIPS16e LZMA SDK 9.x LzmaDec_DecodeToBuf(CLzmaDec *p, Byte *dest, SizeT *destLen,
    # const Byte *src, SizeT *srcLen, ELzmaFinishMode finishMode, ELzmaStatus *status)
    # entry in "DVBS2---0.1.0" bootloaders (Openbox V8S / V8Se / X3, Skybox F4 / A3).
    _LZMA_DEC_TOBUF_M16_SIG = bytes.fromhex(
        "0ef0f764409e07d21293609b08d3006a40de129440dc089206d20e93499b6a9b6eea022a")

    def _find_lzma_decoders(self, data, base, views):
        """Hook LzmaDecode() / lzo1x_decompress_safe() wherever data -- code at
        physical offset `base` -- holds it, at that offset in each view (segment base)."""
        if not self.lzma_hle:
            return
        data = data if isinstance(data, (bytes, bytearray)) else bytes(data)
        for sig, align, head_len in ((self._LZMA_DECODE_SIG, 4, 4), (self._LZMA_DECODE_O2_SIG, 4, 4),
                                     (self._LZMA_DECODE_9_SIG, 4, 4), (self._LZMA_DECODE_9B_SIG, 4, 4),
                                     (self._LZMA_DECODE_M16_SIG, 2, 12), (self._LZMA_DECODE_9_M16_SIG, 2, 12),
                                     (self._LZMA_DECODE_9B_M16_SIG, 2, 12), (self._LZO1X_DECODE_M16_SIG, 2, 12),
                                     (self._LZMA_DEC_TOBUF_M16_SIG, 2, 12)):
            head = sig[:head_len]
            n = len(sig)
            i = data.find(head)
            while i >= 0:
                if i % align == 0 and data[i:i + n] == sig:
                    for view in views:
                        a = view + base + i
                        if a not in self._lzma_hooks:
                            self._lzma_hooks[a] = self.mu.hook_add(UC_HOOK_CODE, self._hook_lzma, begin=a, end=a)
                            self._tb_flush_needed = True
                i = data.find(head, i + 1)

    def _guest_bytes(self, address, size):
        """Up to `size` bytes of guest memory from `address`, as many as are
        mapped there (RAM straight from its buffer)."""
        phys = address & 0x1FFFFFFF
        if (address >> 29) in (0, 4, 5) and phys < self._mapped_ram_size:
            return bytes(self._ram_view[phys:min(phys + size, self._mapped_ram_size)])
        out = bytearray()
        while len(out) < size:
            try:
                out += self.mu.mem_read(address + len(out), min(0x10000, size - len(out)))
            except UcError:
                break
        return bytes(out)

    @staticmethod
    def _lzo1x_decompress_py(src, max_out):
        """Pure-Python fallback for lzo1x_decompress_safe(src, len(src), dst, &max_out)."""
        ip, ip_end = 0, len(src)
        out = bytearray()
        gt_first_literal_run = False
        gt_match = False
        if ip < ip_end and src[ip] > 17:
            t = src[ip] - 17
            ip += 1
            if len(out) + t > max_out or ip + t + 1 > ip_end:
                return None
            out.extend(src[ip:ip + t])
            ip += t
            if t < 4:
                t = src[ip]
                ip += 1
                gt_match = True
            else:
                gt_first_literal_run = True
        while ip < ip_end or gt_match or gt_first_literal_run:
            if not gt_match:
                if not gt_first_literal_run:
                    t = src[ip]
                    ip += 1
                    if t >= 16:
                        gt_match = True
                    else:
                        if t == 0:
                            while src[ip] == 0:
                                t += 255
                                ip += 1
                            t += 15 + src[ip]
                            ip += 1
                        n = t + 3
                        if len(out) + n > max_out or ip + n + 1 > ip_end:
                            return None
                        out.extend(src[ip:ip + n])
                        ip += n
                        gt_first_literal_run = True
                if gt_first_literal_run:
                    gt_first_literal_run = False
                    t = src[ip]
                    ip += 1
                    if t >= 16:
                        gt_match = True
                    else:
                        m_pos = len(out) - 0x801 - (t >> 2) - (src[ip] << 2)
                        ip += 1
                        if m_pos < 0 or len(out) + 3 > max_out:
                            return None
                        for _ in range(3):
                            out.append(out[m_pos])
                            m_pos += 1
            while True:
                if gt_match:
                    gt_match = False
                    if t >= 64:
                        m_pos = len(out) - 1 - ((t >> 2) & 7) - (src[ip] << 3)
                        ip += 1
                        m_len = (t >> 5) + 1
                    elif t >= 32:
                        t &= 31
                        if t == 0:
                            while src[ip] == 0:
                                t += 255
                                ip += 1
                            t += 31 + src[ip]
                            ip += 1
                        m_pos = len(out) - 1 - (src[ip] >> 2) - (src[ip + 1] << 6)
                        ip += 2
                        m_len = t + 2
                    elif t >= 16:
                        m_pos = len(out) - ((t & 8) << 11)
                        t &= 7
                        if t == 0:
                            while src[ip] == 0:
                                t += 255
                                ip += 1
                            t += 7 + src[ip]
                            ip += 1
                        m_pos -= (src[ip] >> 2) + (src[ip + 1] << 6)
                        ip += 2
                        if m_pos == len(out):
                            return bytes(out) if ip == ip_end else None
                        m_pos -= 0x4000
                        m_len = t + 2
                    else:
                        m_pos = len(out) - 1 - (t >> 2) - (src[ip] << 2)
                        ip += 1
                        m_len = 2
                    if m_pos < 0 or len(out) + m_len > max_out:
                        return None
                    if len(out) - m_pos >= m_len:
                        out.extend(out[m_pos:m_pos + m_len])
                    else:
                        for _ in range(m_len):
                            out.append(out[m_pos])
                            m_pos += 1
                t = src[ip - 2] & 3
                if t == 0:
                    break
                if len(out) + t > max_out or ip + t + 1 > ip_end:
                    return None
                for _ in range(t):
                    out.append(src[ip])
                    ip += 1
                t = src[ip]
                ip += 1
                gt_match = True
        return None

    def _hook_lzma(self, uc, address, size, user_data):
        """LzmaDecode() / lzo1x_decompress_safe() entry: decode the stream in
        Python/C++ and return to the caller, or leave the call to the emulated decoder."""
        rate_scale = 1.0
        sdk9 = False
        lzo1x = False
        tobuf = False
        if size in (2, 4):
            head12 = self._guest_bytes(address, 12)
            if head12[:4] == self._LZMA_DECODE_O2_SIG[:4]:
                sig = self._LZMA_DECODE_O2_SIG
                rate_scale = 0.3
            elif head12[:8] == self._LZMA_DECODE_9_SIG[:8]:
                sig = self._LZMA_DECODE_9_SIG
                rate_scale = 0.3
                sdk9 = True
            elif head12[:8] == self._LZMA_DECODE_9B_SIG[:8]:
                sig = self._LZMA_DECODE_9B_SIG
                rate_scale = 0.0
                sdk9 = True
            elif head12 == self._LZMA_DECODE_9_M16_SIG[:12]:
                sig = self._LZMA_DECODE_9_M16_SIG
                rate_scale = 0.3
                sdk9 = True
            elif head12 == self._LZMA_DECODE_9B_M16_SIG[:12]:
                sig = self._LZMA_DECODE_9B_M16_SIG
                rate_scale = 0.3
                sdk9 = True
            elif head12 == self._LZO1X_DECODE_M16_SIG[:12]:
                sig = self._LZO1X_DECODE_M16_SIG
                rate_scale = 0.08
                lzo1x = True
            elif head12 == self._LZMA_DEC_TOBUF_M16_SIG[:12]:
                sig = self._LZMA_DEC_TOBUF_M16_SIG
                rate_scale = 0.0
                tobuf = True
            elif size == 2:
                sig = self._LZMA_DECODE_M16_SIG
            else:
                sig = self._LZMA_DECODE_SIG
        else:
            return
        if not self.lzma_hle or self._code_hook_h is not None or self.is_stepping:
            return
        near = range(address - 0x1000, address + 0x1000)    # (the decoder's functions: a breakpoint
        if self.stop_instr in near or any(b in near for b in self.breakpoints):     # there is honoured)
            return
        import lzma
        import struct
        try:
            if self._guest_bytes(address, len(sig)) != sig:
                return                              # (code changed since the scan)
            sp, ra = self._reg_read(UC_MIPS_REG_SP), self._reg_read(UC_MIPS_REG_RA)
            if tobuf:
                p_addr, out_addr, done_ptr, in_addr = (
                    self._reg_read(self.gpr_map[n]) for n in (4, 5, 6, 7))
                src_len_ptr, _finish_mode, status_ptr = struct.unpack("<3I", uc.mem_read(sp + 16, 12))
                out_size = struct.unpack("<I", uc.mem_read(done_ptr, 4))[0]
                in_size = struct.unpack("<I", uc.mem_read(src_len_ptr, 4))[0]
                uc.mem_read(status_ptr, 4)          # (mapped)
                lc, lp, pb, raw_dict = struct.unpack("<4I", uc.mem_read(p_addr, 16))
                need_flush = struct.unpack("<I", uc.mem_read(p_addr + 0x4C, 4))[0]
                out_phys = out_addr & 0x1FFFFFFF
                if lc > 8 or lp > 4 or pb > 4 or raw_dict > (1 << 27) \
                        or (out_addr >> 29) not in (0, 4, 5) or out_phys + out_size > self._mapped_ram_size:
                    return
                decs = self.__dict__.setdefault("_lzma_tobuf_decs", {})
                if need_flush or p_addr not in decs:
                    dict_size = max(1 << 12, raw_dict)
                    dec = lzma.LZMADecompressor(lzma.FORMAT_RAW, filters=[{
                        "id": lzma.FILTER_LZMA1, "lc": lc, "lp": lp, "pb": pb, "dict_size": dict_size}])
                    decs[p_addr] = [dec, in_addr, out_addr, 0]
                else:
                    dec = decs[p_addr][0]
                if dec.needs_input:
                    raw_in = self._guest_bytes(in_addr, min(in_size, 1 << 26))
                    out = dec.decompress(raw_in, max_length=out_size)
                else:
                    out = dec.decompress(b"", max_length=out_size)
                finished = dec.eof or (_finish_mode == 1 and len(out) == out_size)
                consumed = (in_size - len(dec.unused_data)) if dec.eof else (in_size if (finished or dec.needs_input) else 0)
                status = 1 if dec.eof else (4 if finished else (3 if dec.needs_input else 2))
                if need_flush:
                    uc.mem_write(p_addr + 0x4C, b"\x00\x00\x00\x00")
                decs[p_addr][3] += len(out)
                self._ram_view[out_phys:out_phys + len(out)] = out
                uc.mem_write(done_ptr, struct.pack("<I", len(out)))
                uc.mem_write(src_len_ptr, struct.pack("<I", consumed))
                uc.mem_write(status_ptr, struct.pack("<I", status))
                self._reg_write(self.gpr_map[2], 0)
                if not finished:
                    if getattr(self, "engine", None) == "cpp":
                        self._write_pc(ra)
                    else:
                        if self._stop_reason is None:
                            self._stop_reason = 'lzma'
                        self._orig_emu_stop()
                        self._reg_write(UC_MIPS_REG_PC, ra)
                    return
                _, stream_in, stream_out, stream_len = decs.pop(p_addr)
                if self._stop_reason is None:
                    self._stop_reason = 'lzma'
                self._orig_emu_stop()
                self._reg_write(UC_MIPS_REG_PC, ra)
                stream_phys = stream_out & 0x1FFFFFFF
                in_code_range = stream_phys < self._RAM_CODE_LIMIT or any(
                    (s & 0x1FFFFFFF) <= stream_phys < (s & 0x1FFFFFFF) + length
                    for s, length in self.chip.code_ranges()
                )
                if in_code_range:
                    self._tb_flush_needed = True
                    self._rescan_cp0_sites([(0x80000000 | stream_phys, stream_len)])
                    self._update_short_block_hook()
                    chunk = self._VIRGIN_CHUNK
                    c_lo = 0 if stream_phys <= 0x1000 else ((stream_phys + chunk - 1) & ~(chunk - 1))
                    c_hi = (stream_phys + stream_len) & ~(chunk - 1)
                    for c in range(c_lo, c_hi, chunk):
                        cb = zlib.crc32(self._ram_view[c:c + chunk])
                        self._scanned_ram_chunks[(c, chunk)] = cb
                        self._scanned_ram_chunks[(c, chunk, False)] = cb
                self.log(f"[LZMA] LzmaDec_DecodeToBuf at 0x{address:08X} (from 0x{ra:08X}): "
                         f"0x{stream_in:08X} -> 0x{stream_out:08X}, {stream_len} bytes decoded in Python "
                         f"(lc {lc}, lp {lp}, pb {pb})")
                return
            if lzo1x:
                in_addr, in_size, out_addr, done_ptr = (
                    self._reg_read(self.gpr_map[n]) for n in (4, 5, 6, 7))
                out_size = struct.unpack("<I", uc.mem_read(done_ptr, 4))[0]
                out_phys = out_addr & 0x1FFFFFFF
                if in_size < 4 or (out_addr >> 29) not in (0, 4, 5) or out_phys >= self._mapped_ram_size:
                    return
                cap = min(out_size, self._mapped_ram_size - out_phys)
                out_len = None
                ret_v0 = 0
                try:
                    import cpp_core
                    in_phys = in_addr & 0x1FFFFFFF
                    if (in_addr >> 29) in (0, 4, 5) and in_phys + in_size <= self._mapped_ram_size:
                        in_ptr = ctypes.addressof(self.ram_buffer) + in_phys
                        raw_keep = None
                    else:
                        raw_keep = self._guest_bytes(in_addr, min(in_size, 1 << 26))
                        if len(raw_keep) < in_size:
                            return
                        in_ptr = raw_keep
                    c_len = ctypes.c_uint32(cap)
                    out_ptr = ctypes.addressof(self.ram_buffer) + out_phys
                    rc = int(cpp_core.lib().ali_lzo1x_decompress_safe(in_ptr, in_size, out_ptr, ctypes.byref(c_len)))
                    if rc in (0, -8) and c_len.value > 0:
                        out_len = int(c_len.value)
                        ret_v0 = rc & 0xFFFFFFFF
                except Exception:
                    raw_in = self._guest_bytes(in_addr, min(in_size, 1 << 26))
                    out = self._lzo1x_decompress_py(raw_in, cap)
                    if out is not None:
                        out_len = len(out)
                        self._ram_view[out_phys:out_phys + out_len] = out
                if out_len is None:
                    return
                if self._stop_reason is None:
                    self._stop_reason = 'lzma'
                self._orig_emu_stop()
                uc.mem_write(done_ptr, struct.pack("<I", out_len))
                self._reg_write(self.gpr_map[2], ret_v0)
                self._reg_write(UC_MIPS_REG_PC, ra)
                in_code_range = out_phys < self._RAM_CODE_LIMIT or any(
                    (s & 0x1FFFFFFF) <= out_phys < (s & 0x1FFFFFFF) + length
                    for s, length in self.chip.code_ranges()
                )
                if in_code_range:
                    self._tb_flush_needed = True
                    self._rescan_cp0_sites([(0x80000000 | out_phys, out_len)])
                    self._update_short_block_hook()
                    chunk = self._VIRGIN_CHUNK
                    c_lo = 0 if out_phys <= 0x1000 else ((out_phys + chunk - 1) & ~(chunk - 1))
                    c_hi = (out_phys + out_len) & ~(chunk - 1)
                    for c in range(c_lo, c_hi, chunk):
                        cb = zlib.crc32(self._ram_view[c:c + chunk])
                        self._scanned_ram_chunks[(c, chunk)] = cb
                        self._scanned_ram_chunks[(c, chunk, False)] = cb
                if rate_scale > 0:
                    self.busy_pending += out_len * (self.lzma_insns_per_byte * rate_scale) / self._insn_rate
                self.__dict__.setdefault("lzo1x_decodes", []).append((address, in_addr, out_addr, out_len))
                self.log(f"[LZO1X] lzo1x_decompress_safe at 0x{address:08X} (from 0x{ra:08X}): "
                         f"0x{in_addr:08X} -> 0x{out_addr:08X}, {out_len} bytes decoded")
                return
            if sdk9:
                out_addr, done_ptr, in_addr, src_len_ptr = (
                    self._reg_read(self.gpr_map[n]) for n in (4, 5, 6, 7))
                prop_ptr, prop_size, _finish_mode, status_ptr = struct.unpack("<4I", uc.mem_read(sp + 16, 16))
                out_size = struct.unpack("<I", uc.mem_read(done_ptr, 4))[0]
                in_size = struct.unpack("<I", uc.mem_read(src_len_ptr, 4))[0]
                uc.mem_read(status_ptr, 4)          # (mapped)
                if prop_size < 5 or in_size < 5:
                    return
                prop = bytes(uc.mem_read(prop_ptr, 5))
                d = prop[0]
                raw_dict = int.from_bytes(prop[1:5], "little")
                out_phys = out_addr & 0x1FFFFFFF
                if d >= 9 * 5 * 5 or raw_dict > (1 << 27) \
                        or (out_addr >> 29) not in (0, 4, 5) or out_phys + out_size > self._mapped_ram_size:
                    return
                lc, d = d % 9, d // 9
                lp, pb = d % 5, d // 5
                dict_size = max(1 << 12, min(raw_dict, out_size))
            else:
                buf_size, lc, lp = (self._reg_read(self.gpr_map[n]) for n in (5, 6, 7))
                pb, in_addr, in_size, out_addr, out_size, done_ptr = struct.unpack("<6I", uc.mem_read(sp + 16, 24))
                uc.mem_read(done_ptr, 4)            # (mapped)
                out_phys = out_addr & 0x1FFFFFFF
                if lc > 8 or lp > 4 or pb > 4 or buf_size < (0x736 + (0x300 << (lc + lp))) * 2 \
                        or (out_addr >> 29) not in (0, 4, 5) or out_phys + out_size > self._mapped_ram_size:
                    return
                dict_size = max(1 << 12, out_size)
            raw_in = self._guest_bytes(in_addr, min(in_size, 1 << 26))
            small_key = (lc, lp, pb, out_size, len(raw_in), zlib.crc32(raw_in)) if len(raw_in) <= 0x40000 and out_size <= 0x40000 else None
            small_cache = self.__dict__.setdefault("_lzma_small_cache", {}) if small_key is not None else None
            if small_cache is not None and small_key in small_cache:
                out, consumed_len, is_eof = small_cache[small_key]
            else:
                dec = lzma.LZMADecompressor(lzma.FORMAT_RAW, filters=[{
                    "id": lzma.FILTER_LZMA1, "lc": lc, "lp": lp, "pb": pb, "dict_size": dict_size}])
                out = dec.decompress(raw_in, max_length=out_size)
                consumed_len = len(raw_in) - len(dec.unused_data)
                is_eof = dec.eof
                if small_cache is not None and (len(out) >= out_size or is_eof):
                    if len(small_cache) >= 16:
                        small_cache.clear()
                    small_cache[small_key] = (out, consumed_len, is_eof)
        except (lzma.LZMAError, UcError, ValueError, struct.error):
            return
        if len(out) < out_size and not is_eof:
            return                                  # (the input ran out: the decoder's error)
        if self._stop_reason is None:
            self._stop_reason = 'lzma'
        self._orig_emu_stop()                       # (what follows is host time)
        # The output is written behind Unicorn's back (its buffer): the next
        # slice starts with its translations dropped (_sync_hooks).  It is code:
        # scanned for CP0 sites now (the emulated decoder took long enough for
        # the periodic rescans to see it appear).
        self._ram_view[out_phys:out_phys + len(out)] = out
        uc.mem_write(done_ptr, struct.pack("<I", len(out)))
        if sdk9:
            uc.mem_write(src_len_ptr, struct.pack("<I", consumed_len))
            uc.mem_write(status_ptr, struct.pack("<I", 1 if is_eof else 4))
        self._reg_write(self.gpr_map[2], 0)
        self._reg_write(UC_MIPS_REG_PC, ra)
        in_code_range = out_phys < self._RAM_CODE_LIMIT or any(
            (s & 0x1FFFFFFF) <= out_phys < (s & 0x1FFFFFFF) + length
            for s, length in self.chip.code_ranges()
        )
        if in_code_range:
            self._tb_flush_needed = True
            self._rescan_cp0_sites([(0x80000000 | out_phys, len(out))])
            self._update_short_block_hook()
            chunk = self._VIRGIN_CHUNK
            c_lo = 0 if out_phys <= 0x1000 else ((out_phys + chunk - 1) & ~(chunk - 1))
            c_hi = (out_phys + len(out)) & ~(chunk - 1)
            for c in range(c_lo, c_hi, chunk):
                cb = zlib.crc32(self._ram_view[c:c + chunk])
                self._scanned_ram_chunks[(c, chunk)] = cb
                self._scanned_ram_chunks[(c, chunk, False)] = cb
        if rate_scale > 0:
            self.busy_pending += len(out) * (self.lzma_insns_per_byte * rate_scale) / self._insn_rate
        self.lzma_decodes.append((address, in_addr, out_addr, len(out)))
        self.log(f"[LZMA] LzmaDecode at 0x{address:08X} (from 0x{ra:08X}): 0x{in_addr:08X} -> 0x{out_addr:08X}, "
                 f"{len(out)} bytes decoded in Python (lc {lc}, lp {lp}, pb {pb})")

    # The TDS RTOS's microsecond delay -- delay(us): start = get_count(); wait
    # until get_count() - start >= (us & 0xFFFF) * (cpu_clock * 0x431BDE83 >>
    # 51), Count ticks per microsecond from the CPU clock variable at gp +
    # offset -- polls get_count() (mfc0 v0, Count; jr ra): two hooked MFC0 Count
    # or more per call, ~25 us of host time, for a wait of a few microseconds.
    # The drivers' polling loops call delay(1) hundreds of thousands of times
    # (dump_maciej: 327,000 times in its first 150 M instructions, the S60
    # 436,000), and a few hundred calls wait milliseconds (1.6 s of the 118 s
    # of emulation time either took).  Found by its 24 words (the two calls'
    # target and the gp offset masked: _DELAY_SIG_RE) in each RAM chunk scan,
    # it gets two hooks.  At its entry (_hook_delay) the wait, computed as the
    # routine does, is moved on in emulation time inside the hook -- the caller
    # goes on after it as after the loop --, v0 / v1 are set as the loop leaves
    # them and the call returns to $ra, if the wait ends before the running
    # slice does (the next tick, run()'s limits).  Otherwise the routine runs,
    # and at its loop's get_count() call (_hook_delay_loop) the time moves on
    # to the end of the slice, which ends there for run() to take the tick --
    # inside the wait, as on the hardware --, and then to the end of the wait,
    # where get_count() ends the loop.  Outside a timed slice (a counted one,
    # emu_start() called directly) only waits up to delay_hle_max_s are
    # skipped; none in exact mode or over a breakpoint.
    # The newer SDK's build (the C3505 T760i's: delay(4) 115,000 times in its
    # first 150 M instructions, a third of its hooked CP0 instructions) waits
    # (us * per_us) ticks, the whole argument, until get_count() - start
    # passes them (one tick more), keeps them in s2 and returns v0 = 1; its
    # get_count() has an EHB among the NOPs.  Its bootloader's reads the ticks
    # per microsecond from a variable of their own (a delay_ms() calls it with
    # 1000 as often as it waits milliseconds) and leaves v1 alone; its SEE
    # program's divides the clock by 2,000,000 (DIVU) and keeps the ticks in
    # s0 (98,000 calls of the SEE core's 184,000 get_count() calls).
    delay_hle = True
    delay_hle_max_s = 200e-6
    _JAL = rb"[\x00-\xff]{3}[\x0c-\x0f]"
    _DELAY_TAIL = bytes.fromhex("00000000" "23105100" "2b105000" "fbff4014" "1800bf8f" "1400b18f" "1000b08f"
                                "0800e003" "2000bd27")     # (nop; subu; sltu; bnez loop; lw ra / s1 / s0; jr ra)
    _DELAY_TAIL_RE = (re.escape(bytes.fromhex("00000000" "23105100" "2b105000" "fbff4014")) + rb"(?:\x00{4})?" +
                      re.escape(bytes.fromhex("1800bf8f" "1400b18f" "1000b08f" "0800e003" "2000bd27")))
    # Each build: its words (the calls' target and the clock's gp offset
    # masked), the offsets of its first and its loop's get_count() call, the
    # loop's registers holding the ticks to wait and the Count it started at,
    # the argument's mask, how the variable at gp gives the ticks per
    # microsecond (the CPU clock "mul"tiplied by 0x431BDE83 >> 51 or "div"ided
    # by 2,000,000, an int constant when compiled in, or None: they are its value), whether the loop ends only
    # past the ticks, v0 at its end and v1 ("per_us", the last "count" or
    # None: untouched).
    _DELAYS = (
        dict(sig=re.compile(re.escape(bytes.fromhex("e0ffbd27" "1800bfaf" "1400b1af" "1000b0af")) + _JAL +
                            re.escape(bytes.fromhex("ffff9030" "21884000")) + rb"([\x00-\xff]{2})\x83\x8f" +
                            re.escape(bytes.fromhex("1b43023c" "83de4234" "19006200" "10180000" "c21c0300"
                                                    "02800372")) + _JAL + _DELAY_TAIL_RE),
             first=16, loop=56, ticks=16, start=17, mask=0xFFFF, clock="mul", past=False, v0=0, v1="per_us"),
        dict(sig=re.compile(re.escape(bytes.fromhex("e0ffbd27" "1c00bfaf" "1800b2af" "1400b1af" "1000b0af")) +
                            _JAL + re.escape(bytes.fromhex("21808000" "21884000")) + rb"([\x00-\xff]{2})\x83\x8f" +
                            re.escape(bytes.fromhex("1b43023c" "83de4234" "19006200" "10180000" "c2940300"
                                                    "02905072")) + _JAL +
                            re.escape(bytes.fromhex("00000000" "21184000" "2b102202" "06004010" "23107100"
                                                    "2b104202" "07004014" "1c00bf8f" "f6ff0010" "00000000"
                                                    "ffff4224" "2b104202" "f2ff4010" "1c00bf8f" "1800b28f"
                                                    "1400b18f" "1000b08f" "0800e003" "2000bd27"))),
             first=20, loop=60, ticks=18, start=17, mask=0xFFFFFFFF, clock="mul", past=True, v0=1, v1="count"),
        dict(sig=re.compile(re.escape(bytes.fromhex("e0ffbd27" "1800bfaf" "1400b1af" "1000b0af")) + _JAL +
                            re.escape(bytes.fromhex("ffff9030" "21884000")) + rb"([\x00-\xff]{2})\x82\x8f" +
                            re.escape(bytes.fromhex("02800272")) + _JAL + _DELAY_TAIL_RE),
             first=16, loop=36, ticks=16, start=17, mask=0xFFFF, clock=None, past=False, v0=0, v1=None),
        dict(sig=re.compile(re.escape(bytes.fromhex("e0ffbd27" "1800bfaf" "1400b1af" "1000b0af")) + _JAL +
                            re.escape(bytes.fromhex("21808000" "21884000")) + rb"([\x00-\xff]{2})\x83\x8f" +
                            re.escape(bytes.fromhex("1e00023c" "80844234" "1b006200" "f4014000" "12180000"
                                                    "00000000" "00000000" "18007000" "12800000")) + _JAL +
                            re.escape(bytes.fromhex("00000000" "21184000" "2b102202" "06004010" "23107100"
                                                    "2b100202" "07004014" "1800bf8f" "f6ff0010" "00000000"
                                                    "ffff4224" "2b100202" "f2ff4010" "1800bf8f" "1400b18f"
                                                    "1000b08f" "0800e003" "2000bd27"))),
             first=16, loop=68, ticks=16, start=17, mask=0xFFFFFFFF, clock="div", past=True, v0=1, v1="count"),
        dict(sig=re.compile(re.escape(bytes.fromhex("e0ffbd27" "1800bfaf" "1400b1af" "1000b0af" "21808000")) + _JAL +
                            re.escape(bytes.fromhex("ffff1032" "21884000" "c0101000" "23105000" "80100200"
                                                    "23105000" "80800200")) + _JAL + _DELAY_TAIL_RE),
             first=20, loop=52, ticks=16, start=17, mask=0xFFFF, clock=108, past=False, v0=0, v1=None),
    )

    def _find_delay_routines(self, data, base, views):
        """Hook the RTOS's delay() wherever data -- code at physical offset `base`
        -- holds one of its builds (calling a get_count()), at that offset in
        each view."""
        if not self.delay_hle:
            return
        data = data if isinstance(data, (bytes, bytearray)) else bytes(data)
        for kind, build in enumerate(self._DELAYS):
            first, loop_at = build["first"], build["loop"]
            for m in build["sig"].finditer(data):
                call = data[m.start() + first:m.start() + first + 4]
                if m.start() % 4 or data[m.start() + loop_at:m.start() + loop_at + 4] != call:
                    continue                        # (both calls go to the same get_count())
                gp_off = 0 if isinstance(build["clock"], int) else int.from_bytes(m.group(1), 'little', signed=True)
                for view in views:
                    a = view + base + m.start()
                    target = (a & 0xF0000000) | (int.from_bytes(call, 'little') & 0x03FFFFFF) << 2
                    if not self._is_get_count(target):
                        continue
                    code_bytes = bytes(data[m.start():m.end()])
                    phys = a & 0x1FFFFFFF
                    self._delay_code_views[a] = (self._ram_view[phys:phys + len(code_bytes)]
                                                 if (a >> 29) in (4, 5) and phys + len(code_bytes) <= self._mapped_ram_size else None)
                    self._delay_routines[a] = (code_bytes, gp_off, target, kind)
                    self._delay_loops[a + loop_at] = a
                    if a not in self._delay_hooks:
                        loop = a + loop_at
                        self._delay_hooks[a] = (
                            self.mu.hook_add(UC_HOOK_CODE, self._hook_delay, begin=a, end=a),
                            self.mu.hook_add(UC_HOOK_CODE, self._hook_delay_loop, begin=loop, end=loop))
                        self._tb_flush_needed = True
        sig = self._SFLASH_READ_SIG
        sig_len = len(sig)
        pos = 0
        while True:
            idx = data.find(sig, pos)
            if idx < 0:
                break
            pos = idx + 4
            if idx % 4:
                continue
            for view in views:
                a = view + base + idx
                phys = a & 0x1FFFFFFF
                self._sflash_read_views[a] = (self._ram_view[phys:phys + sig_len]
                                              if (a >> 29) in (4, 5) and phys + sig_len <= self._mapped_ram_size else None)
                if a not in self._sflash_read_hooks:
                    self._sflash_read_hooks[a] = self.mu.hook_add(UC_HOOK_CODE, self._hook_sflash_read, begin=a, end=a)
                    self._tb_flush_needed = True
        sbox_sig = self._SBOX16_SIG
        sbox_len = len(sbox_sig)
        pos = 0
        while True:
            idx = data.find(sbox_sig, pos)
            if idx < 0:
                break
            pos = idx + 2
            if idx % 2:
                continue
            for view in views:
                a = view + base + idx
                phys = a & 0x1FFFFFFF
                self._sflash_read_views[a] = (self._ram_view[phys:phys + sbox_len]
                                              if (a >> 29) in (4, 5) and phys + sbox_len <= self._mapped_ram_size else None)
                if a not in self._sflash_read_hooks:
                    self._sflash_read_hooks[a] = self.mu.hook_add(UC_HOOK_CODE, self._hook_sbox16, begin=a, end=a)
                    self._tb_flush_needed = True
        xor13_sig = self._XOR13_M16_SIG
        xor13_len = len(xor13_sig)
        pos = 0
        while True:
            idx = data.find(xor13_sig, pos)
            if idx < 0:
                break
            pos = idx + 2
            if idx % 2:
                continue
            for view in views:
                a = view + base + idx
                phys = a & 0x1FFFFFFF
                self._sflash_read_views[a] = (self._ram_view[phys:phys + xor13_len]
                                              if (a >> 29) in (4, 5) and phys + xor13_len <= self._mapped_ram_size else None)
                if a not in self._sflash_read_hooks:
                    self._sflash_read_hooks[a] = self.mu.hook_add(UC_HOOK_CODE, self._hook_xor13, begin=a, end=a)
                    self._tb_flush_needed = True
        copy16u_sig = self._COPY16U_M16_SIG
        copy16u_len = len(copy16u_sig)
        pos = 0
        while True:
            idx = data.find(copy16u_sig, pos)
            if idx < 0:
                break
            pos = idx + 2
            if idx % 2:
                continue
            for view in views:
                a = view + base + idx
                phys = a & 0x1FFFFFFF
                self._sflash_read_views[a] = (self._ram_view[phys:phys + copy16u_len]
                                              if (a >> 29) in (4, 5) and phys + copy16u_len <= self._mapped_ram_size else None)
                if a not in self._sflash_read_hooks:
                    self._sflash_read_hooks[a] = self.mu.hook_add(UC_HOOK_CODE, self._hook_copy16u, begin=a, end=a)
                    self._tb_flush_needed = True
        memset16_sig = self._MEMSET16_M16_SIG
        memset16_len = len(memset16_sig)
        pos = 0
        while True:
            idx = data.find(memset16_sig, pos)
            if idx < 0:
                break
            pos = idx + 2
            if idx % 2:
                continue
            for view in views:
                a = view + base + idx
                phys = a & 0x1FFFFFFF
                self._sflash_read_views[a] = (self._ram_view[phys:phys + memset16_len]
                                              if (a >> 29) in (4, 5) and phys + memset16_len <= self._mapped_ram_size else None)
                if a not in self._sflash_read_hooks:
                    self._sflash_read_hooks[a] = self.mu.hook_add(UC_HOOK_CODE, self._hook_memset16, begin=a, end=a)
                    self._tb_flush_needed = True
        crc32_sig = self._CRC32_SIG
        crc32_len = len(crc32_sig)
        pos = 0
        while True:
            idx = data.find(crc32_sig, pos)
            if idx < 0:
                break
            pos = idx + 4
            if idx % 4:
                continue
            for view in views:
                a = view + base + idx
                phys = a & 0x1FFFFFFF
                self._sflash_read_views[a] = (self._ram_view[phys:phys + crc32_len]
                                              if (a >> 29) in (4, 5) and phys + crc32_len <= self._mapped_ram_size else None)
                if a not in self._sflash_read_hooks:
                    self._sflash_read_hooks[a] = self.mu.hook_add(UC_HOOK_CODE, self._hook_crc32, begin=a, end=a)
                    self._tb_flush_needed = True
        bzero32_sig = self._BZERO32_SIG
        bzero32_len = len(bzero32_sig)
        pos = 0
        while True:
            idx = data.find(bzero32_sig, pos)
            if idx < 0:
                break
            pos = idx + 4
            if idx % 4:
                continue
            for view in views:
                a = view + base + idx
                phys = a & 0x1FFFFFFF
                self._sflash_read_views[a] = (self._ram_view[phys:phys + bzero32_len]
                                              if (a >> 29) in (4, 5) and phys + bzero32_len <= self._mapped_ram_size else None)
                if a not in self._sflash_read_hooks:
                    self._sflash_read_hooks[a] = self.mu.hook_add(UC_HOOK_CODE, self._hook_bzero32, begin=a, end=a)
                    self._tb_flush_needed = True

    _CRC32_SIG = bytes.fromhex(
        "0000829026104700ff0042308010020021104900021a0700"
        "0000428c26386200010008252a100501f5ff401401008424"
    )

    def _hook_crc32(self, uc, address, size, user_data):
        """MIPS32 12-instruction reflected CRC32 table lookup loop (`0x8006115C..0x80061188`,
        ~3M instructions per boot)."""
        if size != 4 or not self.delay_hle or self._code_hook_h is not None or self.is_stepping:
            return
        if self.breakpoints or self._stop_instr is not None:
            stops = set(self.breakpoints) | {self._stop_instr}
            if any(s is not None and address <= s < address + 48 for s in stops):
                return
        code_view = self._sflash_read_views.get(address)
        if code_view is not None:
            if code_view != self._CRC32_SIG:
                return
        elif self._guest_bytes(address, 48) != self._CRC32_SIG:
            return
        u32 = self._env_u32
        if u32 is not None:
            buf_addr, i_end, crc, i_cur, tab_base = u32[4], u32[5], u32[7], u32[8], u32[9]
        else:
            buf_addr, i_end, crc, i_cur, tab_base = (
                self._reg_read(self.gpr_map[n]) for n in (4, 5, 7, 8, 9))
        s_cur = i_cur - 0x100000000 if i_cur & 0x80000000 else i_cur
        s_end = i_end - 0x100000000 if i_end & 0x80000000 else i_end
        if s_cur >= s_end:
            return
        ln = s_end - s_cur
        pb = buf_addr & 0x1FFFFFFF
        pt = tab_base & 0x1FFFFFFF
        if ((buf_addr >> 29) not in (4, 5) or (tab_base >> 29) not in (4, 5) or (tab_base & 3)
                or pb + ln > self._mapped_ram_size or pt + 1024 > self._mapped_ram_size):
            return
        if int.from_bytes(self._ram_view[pt:pt + 8], 'little') != 0x7707309600000000:
            return
        init = (~crc) & 0xFFFFFFFF
        if ln > 1:
            prev_crc = (~zlib.crc32(self._ram_view[pb:pb + ln - 1], init)) & 0xFFFFFFFF
        else:
            prev_crc = crc
        last_shifted = prev_crc >> 8
        final_crc = (~zlib.crc32(self._ram_view[pb:pb + ln], init)) & 0xFFFFFFFF
        new_a0 = (buf_addr + ln) & 0xFFFFFFFF
        if u32 is not None:
            u32[2], u32[3], u32[4], u32[7], u32[8] = 0, last_shifted, new_a0, final_crc, i_end
        else:
            self._reg_write(self.gpr_map[2], 0)
            self._reg_write(self.gpr_map[3], last_shifted)
            self._reg_write(self.gpr_map[4], new_a0)
            self._reg_write(self.gpr_map[7], final_crc)
            self._reg_write(self.gpr_map[8], i_end)
        self._write_pc(address + 48)

    _BZERO32_SIG = bytes.fromhex(
        "000080ac040080ac080080ac0c0080ac100084242b088500f9ff201400000000"
    )

    def _hook_bzero32(self, uc, address, size, user_data):
        """MIPS32 CRT0 16-byte .bss zeroing loop (`sw $zero, 0..12($a0); addiu $a0, 16; sltu $at, $a0, $a1; bnez`)."""
        if size != 4 or not self.delay_hle or self._code_hook_h is not None or self.is_stepping:
            return
        if self.breakpoints or self._stop_instr is not None:
            stops = set(self.breakpoints) | {self._stop_instr}
            if any(s is not None and address <= s < address + 32 for s in stops):
                return
        code_view = self._sflash_read_views.get(address)
        if code_view is not None:
            if code_view != self._BZERO32_SIG:
                return
        elif self._guest_bytes(address, 32) != self._BZERO32_SIG:
            return
        u32 = self._env_u32
        if u32 is not None:
            a0_cur, a1_end = u32[4], u32[5]
        else:
            a0_cur = self._reg_read(UC_MIPS_REG_A0)
            a1_end = self._reg_read(UC_MIPS_REG_A1)
        if (a0_cur & 3) or a0_cur >= a1_end:
            return
        k = (a1_end - a0_cur + 15) // 16
        total_bytes = 16 * k
        pa = a0_cur & 0x1FFFFFFF
        if (a0_cur >> 29) not in (4, 5) or pa + total_bytes > self._mapped_ram_size:
            return
        self._ram_view[pa:pa + total_bytes] = b"\x00" * total_bytes
        new_a0 = (a0_cur + total_bytes) & 0xFFFFFFFF
        if u32 is not None:
            u32[1], u32[4] = 0, new_a0
        else:
            self._reg_write(self.gpr_map[1], 0)
            self._reg_write(self.gpr_map[4], new_a0)
        self._write_pc(address + 32)

    _MEMSET16_M16_SIG = bytes.fromhex("69e7a0c26143c3ebfb61")

    def _hook_memset16(self, uc, address, size, user_data):
        """MIPS16 5-instruction memset byte-fill loop (`dst[i] = val` for `i = v1..a2-1`,
        850K+ instructions per boot across DVBS2---0.1.0 bootloaders)."""
        if size != 2 or not self.delay_hle or self._code_hook_h is not None or self.is_stepping:
            return
        if self.breakpoints or self._stop_instr is not None:
            stops = set(self.breakpoints) | {self._stop_instr}
            if any(s is not None and address <= s < address + 10 for s in stops):
                return
        code_view = self._sflash_read_views.get(address)
        if code_view is not None:
            if code_view != self._MEMSET16_M16_SIG:
                return
        elif self._guest_bytes(address, 10) != self._MEMSET16_M16_SIG:
            return
        u32 = self._env_u32
        if u32 is not None:
            i_cur, val, i_end, dst_base = u32[3], u32[5] & 0xFF, u32[6], u32[7]
        else:
            i_cur = self._reg_read(UC_MIPS_REG_V1)
            val = self._reg_read(UC_MIPS_REG_A1) & 0xFF
            i_end = self._reg_read(UC_MIPS_REG_A2)
            dst_base = self._reg_read(UC_MIPS_REG_A3)
        if i_cur >= i_end:
            return
        ln = i_end - i_cur
        da = (dst_base + i_cur) & 0xFFFFFFFF
        pd = da & 0x1FFFFFFF
        if (da >> 29) not in (4, 5) or pd + ln > self._mapped_ram_size:
            return
        self._ram_view[pd:pd + ln] = bytes([val]) * ln
        last_v0 = (dst_base + i_end - 1) & 0xFFFFFFFF
        if u32 is not None:
            u32[2], u32[3], u32[24] = last_v0, i_end, 0
        else:
            self._reg_write(self.gpr_map[2], last_v0)
            self._reg_write(self.gpr_map[3], i_end)
            self._reg_write(self.gpr_map[24], 0)
        self._write_pc((address + 10) | 1)

    _COPY16U_M16_SIG = bytes.fromhex("a9e1809a0a92ade280c3823241c3423242c300f6823243c3a445c3edf161")

    def _hook_copy16u(self, uc, address, size, user_data):
        """MIPS16 unaligned 4-byte flash-to-RAM copy loop (`0x81E8BC32..0x81E8BC4E`,
        9M instructions per boot across DVBS2---0.1.0 bootloaders)."""
        if size != 2 or not self.delay_hle or self._code_hook_h is not None or self.is_stepping:
            return
        if (self._spi_dump_enabled or self._rom_dirty or self.flash_device is not None
                or self._flash_read_hooks or (self._spi_stream is not None and self._spi_stream.active)):
            return
        if self.breakpoints or self._stop_instr is not None:
            stops = set(self.breakpoints) | {self._stop_instr}
            if any(s is not None and address <= s < address + 30 for s in stops):
                return
        code_view = self._sflash_read_views.get(address)
        if code_view is not None:
            if code_view != self._COPY16U_M16_SIG:
                return
        elif self._guest_bytes(address, 30) != self._COPY16U_M16_SIG:
            return
        u32 = self._env_u32
        if u32 is not None:
            i_cur, i_end, src_base, sp = u32[5], u32[6], u32[17], u32[29]
        else:
            i_cur = self._reg_read(UC_MIPS_REG_A1)
            i_end = self._reg_read(UC_MIPS_REG_A2)
            src_base = self._reg_read(UC_MIPS_REG_S1)
            sp = self._reg_read(UC_MIPS_REG_SP)
        if (src_base & 3) or (i_cur & 3) or (i_end & 3) or i_cur >= i_end:
            return
        sp_a = (sp + 0x28) & 0xFFFFFFFF
        psp = sp_a & 0x1FFFFFFF
        if (sp_a >> 29) not in (4, 5) or (psp & 3) or psp + 4 > self._mapped_ram_size:
            return
        dst_base = int.from_bytes(self._ram_view[psp:psp + 4], 'little')
        ln = i_end - i_cur
        sa = (src_base + i_cur) & 0xFFFFFFFF
        da = (dst_base + i_cur) & 0xFFFFFFFF
        pd = da & 0x1FFFFFFF
        fl = (sa + 0x50400000) & 0xFFFFFFFF
        if (da >> 29) not in (4, 5) or pd + ln > self._mapped_ram_size or fl + ln > self.rom_size:
            return
        if pd < psp + 4 and psp < pd + ln:
            return
        self._ram_view[pd:pd + ln] = self._rom_view[fl:fl + ln]
        last_w = int.from_bytes(self._rom_view[fl + ln - 4:fl + ln], 'little')
        last_da = (da + ln - 4) & 0xFFFFFFFF
        if u32 is not None:
            u32[2], u32[3], u32[4] = last_w >> 24, last_da, last_w
            u32[5], u32[24] = i_end, 0
        else:
            self._reg_write(self.gpr_map[2], last_w >> 24)
            self._reg_write(self.gpr_map[3], last_da)
            self._reg_write(self.gpr_map[4], last_w)
            self._reg_write(self.gpr_map[5], i_end)
            self._reg_write(self.gpr_map[24], 0)
        self._write_pc((address + 30) | 1)

    _XOR13_M16_SIG = bytes.fromhex(
        "04f0b16405673e652767006f17250d500260d06701100d6e006dc2ed0d60"
        "5967f1e20293e9e3ade140a260a36eea40c4e147a145c2edf361c3e0e9283164a0e8"
    )

    def _hook_xor13(self, uc, address, size, user_data):
        """MIPS16 13-byte rolling XOR unscramble function (`dst[i] = src[i] ^ key[i % 13]`,
        64 KB per call / 46M instructions per boot in DVBS2---0.1.0 bootloaders)."""
        if size != 4 or not self.delay_hle or self._code_hook_h is not None or self.is_stepping:
            return
        if self.breakpoints or self._stop_instr is not None:
            stops = set(self.breakpoints) | {self._stop_instr}
            if any(s is not None and address <= s < address + 64 for s in stops):
                return
        code_view = self._sflash_read_views.get(address)
        if code_view is not None:
            if code_view != self._XOR13_M16_SIG:
                return
        elif self._guest_bytes(address, 64) != self._XOR13_M16_SIG:
            return
        u32 = self._env_u32
        if u32 is not None:
            src, ln, dst, key_a, ra = u32[4], u32[5], u32[6], u32[7], u32[31]
        else:
            src = self._reg_read(UC_MIPS_REG_A0)
            ln = self._reg_read(UC_MIPS_REG_A1)
            dst = self._reg_read(UC_MIPS_REG_A2)
            key_a = self._reg_read(UC_MIPS_REG_A3)
            ra = self._reg_read(UC_MIPS_REG_RA)
        if ln == 0:
            if u32 is not None:
                u32[25], u32[7] = dst, 0
            else:
                self._reg_write(self.gpr_map[25], dst)
                self._reg_write(self.gpr_map[7], 0)
            self._write_pc(ra)
            return
        ps, pd, pk = src & 0x1FFFFFFF, dst & 0x1FFFFFFF, key_a & 0x1FFFFFFF
        if ((src >> 29) not in (4, 5) or (dst >> 29) not in (4, 5) or (key_a >> 29) not in (4, 5)
                or ps + ln > self._mapped_ram_size or pd + ln > self._mapped_ram_size
                or pk + 13 > self._mapped_ram_size):
            return
        k13 = bytes(self._ram_view[pk:pk + 13])
        rep = (k13 * ((ln // 13) + 2))[:ln]
        s_bytes = bytes(self._ram_view[ps:ps + ln])
        out = (int.from_bytes(s_bytes, 'little') ^ int.from_bytes(rep, 'little')).to_bytes(ln, 'little')
        self._ram_view[pd:pd + ln] = out
        rem = ((ln - 1) % 13) + 1
        last_v0 = out[-1]
        last_v1 = k13[rem - 1]
        last_a0 = (dst + ln - 1) & 0xFFFFFFFF
        if u32 is not None:
            u32[2], u32[3], u32[4] = last_v0, last_v1, last_a0
            u32[5], u32[6], u32[7] = rem, rem, ln
            u32[24], u32[25] = 0, dst
        else:
            self._reg_write(self.gpr_map[2], last_v0)
            self._reg_write(self.gpr_map[3], last_v1)
            self._reg_write(self.gpr_map[4], last_a0)
            self._reg_write(self.gpr_map[5], rem)
            self._reg_write(self.gpr_map[6], rem)
            self._reg_write(self.gpr_map[7], ln)
            self._reg_write(self.gpr_map[24], 0)
            self._reg_write(self.gpr_map[25], dst)
        self._write_pc(ra)

    _SBOX16_SIG = bytes.fromhex("8de540a3c9e240a240c3814403ecf861")

    def _hook_sbox16(self, uc, address, size, user_data):
        """MIPS16 S-box byte-substitution loop (`buf[i] = sbox[buf[i]]`, 1.6 MB /
        12.8M instructions in SMT---1.0.0 bootloaders): translate the slice in
        place with `bytes.translate`."""
        if size != 2 or not self.delay_hle or self._code_hook_h is not None or self.is_stepping:
            return
        if self.breakpoints or self._stop_instr is not None:
            stops = set(self.breakpoints) | {self._stop_instr}
            if any(s is not None and address <= s < address + 16 for s in stops):
                return
        code_view = self._sflash_read_views.get(address)
        if code_view is not None:
            if code_view != self._SBOX16_SIG:
                return
        elif self._guest_bytes(address, 16) != self._SBOX16_SIG:
            return
        u32 = self._env_u32
        if u32 is not None:
            i_cur, buf_base, sbox_base, i_lim = u32[4], u32[5], u32[6], u32[16]
        else:
            i_cur = self._reg_read(UC_MIPS_REG_A0)
            buf_base = self._reg_read(UC_MIPS_REG_A1)
            sbox_base = self._reg_read(UC_MIPS_REG_A2)
            i_lim = self._reg_read(UC_MIPS_REG_S0)
        if i_cur >= i_lim:
            return
        ln = i_lim - i_cur
        buf_a = (buf_base + i_cur) & 0xFFFFFFFF
        phys_buf = buf_a & 0x1FFFFFFF
        phys_sbox = sbox_base & 0x1FFFFFFF
        if ((buf_a >> 29) not in (4, 5) or (sbox_base >> 29) not in (4, 5)
                or phys_buf + ln > self._mapped_ram_size or phys_sbox + 256 > self._mapped_ram_size):
            return
        tbl = bytes(self._ram_view[phys_sbox:phys_sbox + 256])
        out = bytes(self._ram_view[phys_buf:phys_buf + ln]).translate(tbl)
        self._ram_view[phys_buf:phys_buf + ln] = out
        last_v0 = out[-1]
        last_v1 = (buf_base + i_lim - 1) & 0xFFFFFFFF
        if u32 is not None:
            u32[2], u32[3], u32[4] = last_v0, last_v1, i_lim
        else:
            self._reg_write(self.gpr_map[2], last_v0)
            self._reg_write(self.gpr_map[3], last_v1)
            self._reg_write(self.gpr_map[4], i_lim)
        self._write_pc((address + 16) | 1)

    _SFLASH_READ_SIG = bytes.fromhex(
        "d0ffbd272c00bfaf2800b6af2400b5af2000b4af1c00b3af1800b2af1400b1af"
        "1000b0af21a0800021a8c000c0af113c4050023c2190a200d400c01021100000")

    def _hook_sflash_read(self, uc, address, size, user_data):
        """sflash_read(buffer, flash_addr, len) in flash_raw_sl_c.c: copy `len`
        bytes from the SPI flash image at `flash_addr - 0xAFC00000` into RAM at
        `buffer` and return 0 (SUCCESS), skipping the per-read mutex lock/unlock
        and 28 SPI controller MMIO accesses (52,600+ calls on Skybox S12)."""
        if size != 4 or not self.delay_hle or self._code_hook_h is not None or self.is_stepping:
            return
        if (self._spi_dump_enabled or self._rom_dirty or self.flash_device is not None
                or self._flash_read_hooks or (self._spi_stream is not None and self._spi_stream.active)):
            return
        if self.breakpoints or self._stop_instr is not None:
            stops = set(self.breakpoints) | {self._stop_instr}
            if any(s is not None and address <= s < address + 0x3B4 for s in stops):
                return
        code_view = self._sflash_read_views.get(address)
        if code_view is not None:
            if code_view != self._SFLASH_READ_SIG:
                return
        elif self._guest_bytes(address, len(self._SFLASH_READ_SIG)) != self._SFLASH_READ_SIG:
            return
        u32 = self._env_u32
        if u32 is not None:
            buf, a1, ln, ra = u32[4], u32[5], u32[6], u32[31]
        else:
            buf = self._reg_read(UC_MIPS_REG_A0)
            a1 = self._reg_read(UC_MIPS_REG_A1)
            ln = self._reg_read(UC_MIPS_REG_A2)
            ra = self._reg_read(UC_MIPS_REG_RA)
        fl = (a1 + 0x50400000) & 0xFFFFFFFF
        phys = buf & 0x1FFFFFFF
        if (buf >> 29) not in (4, 5) or phys + ln > self._mapped_ram_size or fl + ln > self.rom_size:
            return
        if ln:
            self._ram_view[phys:phys + ln] = self._rom_view[fl:fl + ln]
        if u32 is not None:
            u32[2] = 0
        else:
            self._reg_write(self.gpr_map[2], 0)
        self._write_pc(ra)

    def _is_get_count(self, address):
        """Whether a get_count() is at address: mfc0 v0, Count, NOPs / EHBs,
        jr ra, nop."""
        code = self._guest_bytes(address, 48)
        if len(code) < 48 or struct.unpack_from("<I", code)[0] != 0x40024800:
            return False
        for k in range(1, 11):
            w = struct.unpack_from("<I", code, 4 * k)[0]
            if w == 0x03E00008:
                return struct.unpack_from("<I", code, 4 * k + 4)[0] == 0
            if w not in (0, 0xC0):
                return False
        return False

    def _delay_routine(self, entry):
        """The delay() found at `entry` if the shortcut may take it now (fast
        mode, no breakpoint or stop address in it or in its get_count(), the
        code found there still there), or None."""
        routine = self._delay_routines.get(entry)
        if routine is None or not self.delay_hle or self._code_hook_h is not None or self.is_stepping:
            return None
        code, gp_off, get_count, kind = routine
        if self.breakpoints or self._stop_instr is not None:
            stops = set(self.breakpoints) | {self._stop_instr}
            if any(s is not None and (entry <= s < entry + len(code) or get_count <= s < get_count + 48)
                   for s in stops):
                return None
        code_view = self._delay_code_views.get(entry)
        if code_view is not None:
            if code_view != code:                                   # (in place: no copy, no slice alloc)
                return None
        elif self._guest_bytes(entry, len(code)) != code:
            return None
        return routine

    def _delay_jump(self, wait):
        """Move the emulation time on by `wait` seconds inside a slice."""
        self._vt_accum += wait
        self.delay_skipped += wait
        if self._slice_cap_end is not None and self._slice_armed_end is not None:
            # The slice's deadlines are host times: the hooked CP0 instructions'
            # moves with the jump, the stopper's once the jumps add up to 500 us
            if self._slice_deadline is not None:
                self._slice_deadline -= wait
            self._slice_jumped += wait
            if self._slice_jumped > 500e-6 and self._slice_uses_stopper:
                self._arm_deadline(max(0.0, self._slice_armed_end - self._vtime()))

    def _hook_delay(self, uc, address, size, user_data):
        """delay()'s entry: the wait moved on in emulation time and a return to
        the caller, if it ends within the slice (see delay_hle)."""
        routine = self._delay_routine(address) if size == 4 else None
        if routine is None:
            return
        code, gp_off, get_count, kind = routine
        build = self._DELAYS[kind]
        u32 = self._env_u32
        if isinstance(build["clock"], int):
            per_us = build["clock"]
        else:
            gp = u32[28] if u32 is not None else self._reg_read(UC_MIPS_REG_GP)
            a = (gp + gp_off) & 0xFFFFFFFF
            words = self._ram_words
            if words is not None and not a & 3 and (a >> 29) in (4, 5) and (a & 0x1FFFFFFF) < self._mapped_ram_size:
                clock = words[(a & 0x1FFFFFFF) >> 2]
            else:
                clock = int.from_bytes(self._guest_bytes(a, 4), 'little')
            per_us = (((clock * 0x431BDE83) >> 51) & 0xFFFFFFFF if build["clock"] == "mul" else
                      clock // 2_000_000 if build["clock"] == "div" else clock)
        a0 = u32[4] if u32 is not None else self._reg_read(UC_MIPS_REG_A0)
        ticks = ((a0 & build["mask"]) * per_us) & 0xFFFFFFFF
        if build["past"]:
            if ticks == 0xFFFFFFFF:
                return                              # (it never ends)
            ticks += 1
        wait = ticks / self.count_hz
        in_slice = self._slice_cap_end is not None and self._slice_armed_end is not None
        if in_slice:
            vt = self._vtime()
            room = self._slice_armed_end - vt
        else:
            vt = None
            room = self.delay_hle_max_s
        if wait > room:
            return                                  # (the routine runs: _hook_delay_loop)
        v1_kind = build["v1"]
        if u32 is not None:
            u32[2] = build["v0"]
            if v1_kind == "per_us":
                u32[3] = per_us
            elif v1_kind == "count":
                if self._code_hook_h is None:
                    if vt is None:
                        vt = self._vtime()
                    cnt = (self.cp0_count + int((vt - self._count_t0) * self.count_hz)) & 0xFFFFFFFF
                else:
                    cnt = self._cp0_count_now()
                u32[3] = (cnt + ticks) & 0xFFFFFFFF
            self._write_pc(u32[31])
        else:
            self._reg_write(self.gpr_map[2], build["v0"])          # v0: the loop's last sltu
            if v1_kind == "per_us":
                self._reg_write(self.gpr_map[3], per_us)
            elif v1_kind == "count":
                self._reg_write(self.gpr_map[3], (self._cp0_count_now() + ticks) & 0xFFFFFFFF)
            self._write_pc(self._reg_read(UC_MIPS_REG_RA))
        self.delay_calls += 1
        self._vt_accum += wait
        self.delay_skipped += wait
        if in_slice:
            if self._slice_deadline is not None:
                self._slice_deadline -= wait
            self._slice_jumped += wait
            if self._slice_jumped > 500e-6 and self._slice_uses_stopper:
                rem = self._slice_armed_end - (vt + wait)
                self._arm_deadline(rem if rem > 0.0 else 0.0)

    def _hook_delay_loop(self, uc, address, size, user_data):
        """delay()'s loop at its get_count() call -- the Count ticks to wait and
        the Count it started at in the build's registers --, in a timed slice:
        the emulation time moved on to the end of the wait (the call then ends
        the loop), or to the end of the slice, which ends there (see
        delay_hle)."""
        entry = self._delay_loops.get(address)
        routine = self._delay_routine(entry) if size == 4 and entry is not None else None
        if routine is None or self._slice_cap_end is None or self._slice_armed_end is None:
            return
        build = self._DELAYS[routine[3]]
        ticks, start = self._reg_read(self.gpr_map[build["ticks"]]), self._reg_read(self.gpr_map[build["start"]])
        if build["past"]:
            if ticks == 0xFFFFFFFF:
                return
            ticks += 1
        waited = (self._cp0_count_now() - start) & 0xFFFFFFFF
        if waited >= ticks:
            return
        wait, room = (ticks - waited) / self.count_hz, self._slice_armed_end - self._vtime()
        self.delay_jumps += 1
        if wait <= room:
            self._delay_jump(wait)
            return
        self._delay_jump(max(0.0, room))
        if self._stop_reason is None:
            self._stop_reason = 'deadline'          # (run() takes the tick, then the loop goes on)
        self._orig_emu_stop()

    def run(self, max_instructions=None, max_vtime=None):
        """Run until max_instructions (an instruction count; estimated in fast
        mode) or, with max_vtime, until the emulation time (_vtime) reaches
        that -- a second core's turn between the first core's slices is a
        stretch of emulation time (chips/see.py SeeCore), which the estimated
        counts would not bound reliably."""
        if max_instructions is not None:
            self.max_instructions = max_instructions

        cur_pc = self._reg_read(UC_MIPS_REG_PC)
        if (self.cp0_ebase & 0x3FF) == 0:
            note = "" if self._want_full_hook() else " [fast mode: instruction counts are estimates, no per-instruction history]"
            self.log(f"Starting emulation at {hex(cur_pc)} ({'MIPS16' if self.is_mips16_mode() else 'MIPS32'})...{note}")
        end_addr = self.base_addr + self.rom_size

        self._in_run = True
        self._run_tid = threading.get_ident()
        self._external_stop = False
        self._run_max_vtime = max_vtime
        _last_progress = None
        _stall_slices = 0
        try:
            while True:
                if self._external_stop:
                    break   # emu_stop() from another thread between slices
                if self.max_instructions and self.instruction_count >= self.max_instructions:
                    break
                if max_vtime is not None and self._vtime() >= max_vtime:
                    break
                _prog = (self.instruction_count, self._vtime(), cur_pc)
                if _prog == _last_progress:
                    _stall_slices += 1
                    if _stall_slices >= 64:
                        raise RuntimeError(
                            f"Emulation stalled with zero progress at PC=0x{cur_pc:08X} "
                            f"(stop_reason={self._stop_reason!r})"
                        )
                else:
                    _last_progress = _prog
                    _stall_slices = 0

                # Sitting on a breakpoint / stop address: step over it first,
                # otherwise emu_start would stop on it immediately.
                if cur_pc in self.breakpoints or (self.stop_instr is not None and cur_pc == self.stop_instr):
                    self.step()
                    cur_pc = self._reg_read(UC_MIPS_REG_PC)
                    if self.max_instructions and self.instruction_count >= self.max_instructions:
                        break
                    if (cur_pc & ~1) == 0:
                        break

                self._sync_hooks()
                full = self._code_hook_h is not None

                # Remote-control frames queued by ir_send_nec() / press_key()
                if self._irc_frames:
                    self._irc_service()
                for service in self.slice_services:      # e.g. the demultiplexer's transport stream
                    service()

                # Interrupts that could not be injected inside the previous slice
                # (fast mode: all of them; exact mode: MIPS16 branch self-loops).
                if self.busy_pending > 1e-9 and not full and self._skip_busy(max_vtime):
                    continue
                if not full and self.idle_skip:
                    # (a slice that the tick ended in an idle loop or a mailbox
                    # poll: its hook now, so that the loop is caught when the
                    # handler returns into it)
                    self._idle_start(cur_pc)
                    if self.poll_skip:
                        self._poll_start(cur_pc)
                    if self._tb_flush_needed:
                        self._flush_tb()
                cur_pc = self._take_interrupt_at_boundary(cur_pc)
                if self.idle_skip and not full and (self._skip_idle(cur_pc, max_vtime) or
                                                    self._skip_poll(cur_pc, max_vtime)):
                    continue

                if full:
                    # Exact mode: _hook_code counts instructions, delivers IRQs,
                    # emulates CP0 and stops on breakpoints / max_instructions.
                    self._stop_reason = None
                    self.mu.emu_start(self._start_pc(cur_pc), end_addr)
                    executed = None
                    if self._stop_reason == 'flashhooks':
                        # the SF_INS store was counted and runs again on resume
                        self.instruction_count -= 1
                else:
                    # Fast mode: native batches, interrupts are taken at their boundaries.
                    # Exact (counted) slice when close to a limit, otherwise a
                    # wall-clock slice whose instruction count is estimated.
                    budget = self._budget()
                    small_budget = budget is not None and budget <= self.exact_count_threshold
                    calibrating = self._counted_slices < self.calibration_slices
                    if self._timeout_slices == 0 and (small_budget or calibrating):
                        batch = self.batch_size if budget is None else min(self.batch_size, budget)
                        batch = max(1, batch)
                        dt = self._run_slice(cur_pc, end_addr, None, count=batch)
                        if self._stop_reason is None:
                            executed = batch
                            ran = dt - self._slice_delayed      # (delay() waits: no instructions)
                            if ran > 0 and batch >= 10_000:
                                self._insn_rate = batch / ran
                        elif self._stop_reason == 'rescan':
                            executed = 0    # stopped before the first instruction of a new RAM chunk
                        elif self._stop_reason == 'flashhooks':
                            # stopped right after an SF_INS store, typically a few
                            # instructions in: the (uncalibrated) rate estimate would
                            # overcount a lot; count 1 so a run() budget still ends
                            executed = 1
                        else:
                            # a hook stopped the slice early; Unicorn does not say how
                            # many instructions ran, so use the rate estimate
                            executed = min(batch, int(self._insn_rate * dt))
                        self._counted_slices += 1
                    else:
                        slice_us = self.batch_timeout_us
                        if budget is not None:
                            # aim the slice length at the remaining budget
                            slice_us = min(slice_us, budget / self._insn_rate * 1e6)
                        if max_vtime is not None:
                            slice_us = min(slice_us, max(0.0, max_vtime - self._vtime()) * 1e6)
                        dt = self._run_slice(cur_pc, end_addr, slice_us)
                        executed = 0 if self._stop_reason == 'rescan' else int(self._insn_rate * dt)
                        if budget is not None:
                            executed = min(executed, budget)
                        self._timeout_slices += 1

                if executed is not None:
                    self.instruction_count += executed
                if self._rom_dirty:
                    self._rom_restore()
                cur_pc = self._reg_read(UC_MIPS_REG_PC)
                if not full and self.force_erl:
                    native = self._reg_read(UC_MIPS_REG_CP0_STATUS)
                    if not native & 0x4:
                        # The forced ERL is gone: a CP0 instruction ran natively,
                        # its hook skipped by Unicorn under an asynchronous stop
                        # (stopper or user / GUI emu_stop; see async_stop_margin_us).
                        # Only a native ERET or MTC0 Status is visible this way.
                        self.native_cp0_repairs += 1
                        if (cur_pc & ~1) == 0:
                            # An ERET went to ErrorEPC (0) (possibly after a native
                            # 'mtc0 Status' that set EXL): redo it to the shadow EPC.
                            self.cp0_status = (native & ~0x4) | 0x2
                            target = self._eret(self.mu)
                            self._reg_write(UC_MIPS_REG_PC, target)
                            cur_pc = target & ~1
                            if self._stop_reason == 'null':
                                self._stop_reason = None
                            what = f"ERET (redone to 0x{target:08X})"
                        else:
                            # An MTC0 Status: the guest's value is in the native register.
                            self.cp0_status = native & 0xFFFFFFFF
                            what = f"MTC0 Status 0x{native:08X} (adopted)"
                        if self.native_cp0_repairs <= 8:
                            self.log(f"[WARN] native {what} after an asynchronous stop")
                    self._write_native_status(self.mu, self.cp0_status)
                elif not full:
                    # Native Status: the CPU's own register is the guest's (its
                    # MTC0 Status ran natively, followed by the hook -- or not, its
                    # hook skipped under an asynchronous stop).  An ERET that ran
                    # natively went to the native EPC, 0: redo it to the shadow EPC.
                    native = self._reg_read(UC_MIPS_REG_CP0_STATUS)
                    if (cur_pc & ~1) == 0 and self.cp0_status & 0x2 \
                            and not native & 0x2:
                        self.native_cp0_repairs += 1
                        self.cp0_status = native | 0x2
                        target = self._eret(self.mu)
                        self._reg_write(UC_MIPS_REG_PC, target)
                        cur_pc = target & ~1
                        if self._stop_reason == 'null':
                            self._stop_reason = None
                        if self.native_cp0_repairs <= 8:
                            self.log(f"[WARN] native ERET (redone to 0x{target:08X}) after an asynchronous stop")
                    else:
                        self.cp0_status = native

                if (cur_pc & ~1) == 0 or self._stop_reason == 'null':
                    self.log("[!] Stopped: Jump to NULL")
                    break
                if cur_pc in self.breakpoints or (self.stop_instr is not None and cur_pc == self.stop_instr):
                    break
                if self._stop_reason in ('breakpoint', 'stop_instr'):
                    # The breakpoint sat in a branch delay slot or on a compact jump:
                    # Unicorn completes the branch first, so PC is now at its target.
                    self.log(f"    (stopped after the branch, PC=0x{cur_pc:08X})")
                    break
                if self._stop_reason == 'external' or self._external_stop:
                    break   # emu_stop() from user code / the GUI
                if full and self._stop_reason is None:
                    break   # end address reached
                # 'max_instructions' -> loop re-checks the limit; 'rescan' / batch
                # exhausted -> continue with the next batch.

        except UcError as e:
            self._log_unicorn_error(e)
            raise  # Re-raise so GUI can break
        except Exception as e:
            import traceback
            self.log(f"Error: {e}")
            self.log(traceback.format_exc())
            raise  # Re-raise so GUI can break
        finally:
            self._in_run = False
            self._run_max_vtime = None

    def _exec_one(self, pc):
        """Execute exactly one instruction at pc in the current ISA mode.

        Single steps always use the exact per-instruction hook (it counts the
        instruction, emulates CP0 and stops before the next one); fast-mode
        hooks are re-installed by the next run()."""
        end_addr = self.base_addr + self.rom_size
        self._step_full_hook = True
        try:
            self._sync_hooks()
            self._step_count = 0
            self._stop_reason = None
            self.is_stepping = True
            try:
                # No instruction count here: _hook_code stops before the second
                # instruction, and Unicorn's count hook after wall-clock slices
                # has been seen to stall for a long time.
                self.mu.emu_start(self._start_pc(pc), end_addr)
            finally:
                self.is_stepping = False
                if self._rom_dirty:
                    self._rom_restore()
        finally:
            self._step_full_hook = False

    def runStep(self):
        cur_pc = self.mu.reg_read(UC_MIPS_REG_PC)
        try:
            self._exec_one(cur_pc)
            new_pc = self.mu.reg_read(UC_MIPS_REG_PC)
            if (new_pc & ~1) == 0:
                self.log("[!] Stopped: Jump to NULL")
        except UcError as e:
            self._log_unicorn_error(e)
            raise  # Re-raise so GUI can break
        except Exception as e:
            self.log(f"Error: {e}")
            raise  # Re-raise so GUI can break

    # NEW: Unified Stepping APIs

    def step(self) -> StepResult:
        """
        Execute one instruction in the current ISA mode

        Returns:
            StepResult with execution details
        """
        pc = self.mu.reg_read(UC_MIPS_REG_PC)
        m16_before = self.is_mips16_mode()
        mode_before = 'mips16' if m16_before else 'mips32'
        mnemonic, operands, insn_size = self._decode_for_display(pc, m16_before)

        if self.debug_enabled:
            self.log(f"[DEBUG] step() at PC=0x{pc:08X}, mode={mode_before}")
            if mnemonic == 'jalx':
                self.log(f"[DEBUG] Executing JALX at 0x{pc:08X} -> target {operands}")

        try:
            self._exec_one(pc)
        except UcError as e:
            self.log(f"[step] Unicorn error at 0x{pc:08X}: {e}")  # continue even on error

        next_pc = self.mu.reg_read(UC_MIPS_REG_PC)
        m16_after = self.is_mips16_mode()
        mode_after = 'mips16' if m16_after else 'mips32'
        mode_switched = (m16_after != m16_before)

        # Detect and stop on jump to NULL (0x0)
        if (next_pc & ~1) == 0:
            self.log(f"\n[!] STOPPED: Program is about to jump to 0x0 from 0x{pc:08X}")
            self.log(f"    Instruction: {mnemonic} {operands}")
            raise Exception(f"Jump to NULL (0x0) detected at 0x{pc:08X}: {mnemonic} {operands}")

        if mode_switched:
            if m16_after and not self.debug_enabled:
                self.debug_enabled = True
                self.log("[DEBUG] MIPS16 mode entered - enabling debug logging")
            if self.debug_enabled:
                self.log(f"[DEBUG] Mode switched: {mode_before} -> {mode_after}")

        # Determine instruction type
        is_call = mnemonic in ['jal', 'jalr', 'jalx', 'jalrc', 'bal']
        is_return = mnemonic in ['jr', 'jrc'] and 'ra' in operands
        is_branch = mnemonic.startswith('b') or mnemonic.startswith('j')

        result = StepResult(
            address=pc,
            instruction=mnemonic,
            operands=operands,
            next_pc=next_pc,
            mode_before=mode_before,
            mode_after=mode_after,
            is_branch=is_branch,
            is_call=is_call,
            is_return=is_return,
            mode_switched=mode_switched,
            instruction_size=insn_size
        )

        # Track call stack for step_out
        if result.is_call:
            self.call_stack.append(result.address)
        elif result.is_return and self.call_stack:
            self.call_stack.pop()

        return result

    def step_into(self) -> StepResult:
        """
        Step into function calls (same as step())
        
        Returns:
            StepResult with execution details
        """
        return self.step()
    
    def step_over(self) -> StepResult:
        """
        Step over function calls (execute entire function if next instruction is a call)
        
        Returns:
            StepResult with execution details
        """
        # Execute one step
        result = self.step()
        
        # If it's a call, keep executing until we return
        if result.is_call:
            return_address = result.next_pc
            max_steps = 100000  # Safety limit
            steps = 0
            
            while steps < max_steps:
                current_pc = self.mu.reg_read(UC_MIPS_REG_PC)
                if current_pc == return_address:
                    # We've returned from the call
                    break
                
                step_result = self.step()
                steps += 1
                
                # If we hit a breakpoint or stop condition, return immediately
                if self.stop_instr and current_pc == self.stop_instr:
                    break
        
        return result
    
    def step_out(self) -> StepResult:
        """
        Step out of current function (execute until return)
        
        Returns:
            StepResult with execution details
        """
        initial_stack_depth = len(self.call_stack)
        max_steps = 100000  # Safety limit
        steps = 0
        last_result = None
        
        while steps < max_steps:
            last_result = self.step()
            steps += 1
            
            # Check if we've returned from the function
            if len(self.call_stack) < initial_stack_depth:
                break
            
            # If we hit a stop condition, break
            current_pc = self.mu.reg_read(UC_MIPS_REG_PC)
            if self.stop_instr and current_pc == self.stop_instr:
                break
        
        return last_result if last_result else StepResult(
            address=self.mu.reg_read(UC_MIPS_REG_PC),
            instruction="???",
            operands="",
            next_pc=self.mu.reg_read(UC_MIPS_REG_PC),
            mode_before=self.isa_mode.value,
            mode_after=self.isa_mode.value
        )
    
    def skipInstruction(self):
        """Skip the current instruction (advance PC by its size in the current ISA mode)"""
        try:
            cur_pc = self.mu.reg_read(UC_MIPS_REG_PC)
            m16 = self.is_mips16_mode()
            _, _, incr = self._decode_for_display(cur_pc, m16)
            self.mu.reg_write(UC_MIPS_REG_PC, (cur_pc + incr) | (1 if m16 else 0))
            self.log(f"Skipped instruction at 0x{cur_pc:08X} (size {incr})")
        except Exception as e:
            self.log(f"Error skipping instruction: {e}")

    def _instr_row(self, addr, code, mnemonic, operands, pc, breakpoints):
        """One entry of get_instructions_around_pc()."""
        return {'address': addr, 'bytes': ' '.join(f'{b:02x}' for b in code), 'mnemonic': mnemonic,
                'operands': operands, 'loop_count': self.visit_counts.get(addr, 0),
                'is_current': addr == pc, 'is_breakpoint': addr in breakpoints}

    def _mips16_row(self, addr, pc, breakpoints):
        """(entry, size) of the MIPS16 instruction at addr for get_instructions_around_pc()."""
        code = self._mips16_bytes(addr)
        mnemonic, operands = MIPS16Decoder.decode(code, addr)
        return self._instr_row(addr, code, mnemonic, operands, pc, breakpoints), len(code)

    def get_instructions_around_pc(self, pc, before=10, after=10, forced_mips16_addresses=None, breakpoints=None):
        if not self.mu: return []
        instructions = []
        forced_mips16_addresses = forced_mips16_addresses or set()
        breakpoints = breakpoints or {}
        
        # Backward scan (Tricky with variable length)
        # Strategy: Go back 'before * 4' bytes (approx), then disassemble forward.
        # If we desync at PC, adjust start point.
        
        start_attempts = [pc - (before * 4), pc - (before * 4) + 2]
        best_instrs = []
        
        for start_addr in start_attempts:
            if start_addr < 0: continue
            
            # Check if PC is a JALX target before scanning
            pc_is_jalx_target = False
            prev_exec = getattr(self, 'prev_executed_pc', None)
            if prev_exec:
                try:
                    prev_bytes = self.mu.mem_read(prev_exec, 4)
                    prev_disasm = list(self.md.disasm(prev_bytes, prev_exec))
                    if prev_disasm and prev_disasm[0].mnemonic == 'jalx':
                        pc_is_jalx_target = True
                        print(f"[DEBUG] PC 0x{pc:08X} is JALX target from 0x{prev_exec:08X}")
                except: pass
            
            temp_instrs = []
            curr = start_addr
            valid_sequence = False
            
            # Track if we're in a MIPS16 region (entered via JALX)
            in_mips16_region = False
            
            # Limit scan to reasonable amount to avoid infinite loops if something is wrong
            while curr <= pc + (after * 4): 
                # Decode one
                try:
                    # Check known size or Forced MIPS16
                    is_mips16 = False
                    
                    # 1. Execution History (exact ISA when the instruction was executed
                    #    with the per-instruction hook; otherwise its size)
                    known_size = self.instruction_sizes.get(curr)
                    known_isa = self.instruction_isa.get(curr)
                    if known_isa is not None:
                        is_mips16 = known_isa
                        if is_mips16:
                            in_mips16_region = True
                        known_size = 4 if not is_mips16 else known_size
                    elif known_size == 2:
                        is_mips16 = True
                        # print(f"[DEBUG] 0x{curr:08X} is MIPS16 from execution history")
                    
                    # 2. Forced Address (Manual Toggle)
                    if curr in forced_mips16_addresses:
                        is_mips16 = True
                    # 2b. The instruction at PC: exact current CPU mode
                    if curr == pc and known_isa is None and self._hflags_off is not None:
                        is_mips16 = self.is_mips16_mode()
                        if is_mips16:
                            in_mips16_region = True
                        # print(f"[DEBUG] 0x{curr:08X} is MIPS16 from forced addresses")
                    
                    # 3. JALX target detection
                    if not is_mips16 and curr == pc and pc_is_jalx_target:
                        is_mips16 = True
                        in_mips16_region = True  # Enter MIPS16 region
                        print(f"[DEBUG] 0x{curr:08X} is MIPS16 as JALX target - entering MIPS16 region")
                    
                    # 4. If we're in a MIPS16 region (and no execution history says otherwise), assume MIPS16
                    if not is_mips16 and in_mips16_region and known_size != 4:
                        is_mips16 = True
                        # print(f"[DEBUG] 0x{curr:08X} is MIPS16 from region continuation")

                    # 5. Check Simulator Heuristic (New)
                    if not is_mips16 and self.is_mips16_addr(curr):
                        is_mips16 = True
                        in_mips16_region = True

                    if is_mips16:
                        row, instr_size = self._mips16_row(curr, pc, breakpoints)
                        temp_instrs.append(row)
                        curr += instr_size
                        if curr == pc: valid_sequence = True
                        if curr > pc and not valid_sequence: break
                        if valid_sequence:
                             # check after count
                             count_after = sum(1 for i in temp_instrs if i['address'] > pc)
                             if count_after >= after: break
                        continue

                    # Try to disassemble as MIPS32 first
                    code = self.mu.mem_read(curr, 4)
                    disasm = list(self.md.disasm(code, curr))
                    
                    if not disasm:
                        # Fallback: treat as MIPS16 instruction
                        try:
                            row, instr_size = self._mips16_row(curr, pc, breakpoints)
                            temp_instrs.append(row)
                            curr += instr_size
                        except:
                            curr += 4  # Skip if read fails
                        continue
                        
                    instr = disasm[0]
                    temp_instrs.append(self._instr_row(curr, instr.bytes, instr.mnemonic, instr.op_str,
                                                       pc, breakpoints))
                    
                    if curr == pc:
                        valid_sequence = True
                        
                    curr += instr.size
                    
                    # If we passed PC
                    if curr > pc and not valid_sequence:
                         break # Desync
                         
                    # Stop if we have enough "after" instructions
                    if valid_sequence:
                        # Count how many after PC
                        count_after = 0
                        for i in reversed(temp_instrs):
                            if i['address'] > pc: count_after += 1
                            else: break
                        if count_after >= after: break
                        
                except:
                    curr += 4 # Fallback
            
            if valid_sequence:
                best_instrs = temp_instrs
                break
        
        if not best_instrs:
            # Ultimate fallback: Show raw hex dump around PC (suppress repeated prints)
            if not hasattr(self, '_last_fallback_pc') or self._last_fallback_pc != pc:
                print(f"[DEBUG] No valid disassembly found, using hex dump fallback at PC=0x{pc:08X}")
                self._last_fallback_pc = pc
            curr = max(0, pc - 20)  # Show a bit before PC
            for i in range(25):  # Show ~50 bytes
                try:
                    row, instr_size = self._mips16_row(curr, pc, breakpoints)
                    best_instrs.append(row)
                    curr += instr_size
                except:
                    curr += 2
                 
        # Filter to requested window
        # Find index of PC
        pc_idx = -1
        for i, item in enumerate(best_instrs):
            if item['address'] == pc: 
                pc_idx = i
                break
                
        if pc_idx != -1:
            start_idx = max(0, pc_idx - before)
            end_idx = min(len(best_instrs), pc_idx + after + 1)
            instructions = best_instrs[start_idx:end_idx]
        else:
            instructions = best_instrs[:before+after] # Fallback
            
        return instructions


