#!/usr/bin/env python3
"""Verify that Amiko CHD8270+ (System ID 14000A88, v2.4.22 EMU) (AMIKO_CHD8270_2.4.22_emu.abs) boots and starts its application and SEE co-processor."""
import see_regression
from front_panel import make_panel

DUMP = "AMIKO CHD8270+/AMIKO_CHD8270_2.4.22_emu.abs"
_HOLDER = {}


def _setup(sim):
    panel, _keys, _desc = make_panel(DUMP, log_handler=lambda m: None)
    panel.dump_enabled = False
    sim.setGpioHandler(panel.on_gpio_write)
    sim.attach_tuner()
    _HOLDER["panel"] = panel

see_regression.run(
    DUMP,
    "the Amiko CHD8270+ (System ID 14000A88, v2.4.22 EMU) runs its application and SEE co-processor",
    family="M3503",
    starts=[(0xA14187DC, "parked"), (0xAE000200, "run on the SEE core")],
    calls=20,
    see_calls=15,
    limit=100_000_000,
    uart=("CH455 panel init OK!", "check_program finish."),
    setup=_setup,
    ebase=0x80002000,
    see_ebase=0x8E002001,
    wait_for=lambda r: (
        r.sim.chip.see.doorbells.taken["SEE"][0] >= 20
        and r.sim.chip.see.doorbells.taken["main"][0] >= 15
        and _HOLDER["panel"].get_display_text() == " on "
    ),
    checks=[
        lambda r: (
            _HOLDER["panel"].get_display_text() == " on ",
            f"front panel updated to {_HOLDER['panel'].get_display_text()!r}",
        ),
    ],
)
